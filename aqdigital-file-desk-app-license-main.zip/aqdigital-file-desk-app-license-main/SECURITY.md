# AQ DIGITAL File Desk — Security & Threat Architecture

This document describes the security controls, validation pipelines, and threat mitigation mechanisms in **AQ DIGITAL File Desk**.

---

## 1. Network Isolation Architecture

- **Dedicated Isolated Interface**:
  - The PC may have active Internet via Ethernet or shop Wi-Fi.
  - The local `AQ-DIGITAL` Hotspot is strictly unbridged.
  - Internet Connection Sharing (ICS / `SharedAccess`) is disabled to prevent routing customer device traffic to the external Internet.
- **Windows Firewall Hardening**:
  - Inbound traffic is permitted **only** on the configured application port (port 3000 / 80).
  - Dangerous Windows services (SMB/CIFS port 445, NetBIOS port 139, RDP port 3389, RPC port 135) are completely blocked from the hotspot interface.

---

## 2. File Quarantine & Validation Pipeline

Uploaded files never enter active workspace folders directly:

```text
CUSTOMER UPLOAD
       ↓ (1MB Chunks)
AQ-DIGITAL/Incoming/
       ↓ (Complete write & size check)
AQ-DIGITAL/Quarantine/
       ↓ (Filename sanitization & path traversal check)
Magic Bytes / File Signature Inspection
       ↓ (Check MZ 0x4D 0x5A header & extensions)
Microsoft Defender Antivirus Scan (MpCmdRun.exe)
       ├── Clean → AQ-DIGITAL/Jobs/<JobId>/
       └── Threat Detected → AQ-DIGITAL/Rejected/
```

### Signature Detection vs. Renamed Malware
If an attacker renames a Windows executable (`trojan.exe`) to `document.pdf` or `photo.jpg`:
- The system reads the initial 1024 bytes and inspects the binary headers.
- Identifies the `MZ` (0x4D 0x5A) DOS/PE header.
- Flags the file immediately as `DISGUISED_EXECUTABLE`.
- Moves file to `AQ-DIGITAL/Rejected/`, marks job `REJECTED`, and logs a security audit event.

---

## 3. Threat Model & Customer Isolation

1. **Cross-Customer Snooping**:
   - Customer URLs use cryptographically random secure tokens (e.g. `tok_...` and `dtok_...`).
   - Customers have no access to sequential IDs or directory browsing (`/files/` is disabled).
   - Each customer can only download documents attached to their authenticated job token.
2. **Path Traversal Attacks**:
   - Filenames are sanitized using `sanitizeFilename()`, stripping `../`, `..\`, null bytes `\0`, and Windows reserved device names (`CON`, `PRN`, `AUX`, `NUL`, `COM1-9`, `LPT1-9`).
3. **Storage Exhaustion (DoS)**:
   - Configurable quotas enforce maximum file size (default 100 MB), maximum files per job (20), and maximum total job size (500 MB).
   - Storage monitor warns operator at 80% capacity and triggers critical alert at 90%.
