# AQ DIGITAL File Desk - Automated Windows Build Script
# Requires Node.js and Inno Setup compiler (ISCC.exe)

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  AQ DIGITAL File Desk - Windows Build" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

# 1. Clean previous build output
Write-Host "[1/4] Cleaning previous build outputs..." -ForegroundColor Yellow
if (Test-Path "dist") { Remove-Item -Recurse -Force "dist" }
if (Test-Path "dist_installer") { Remove-Item -Recurse -Force "dist_installer" }

# 2. Build Frontend & Bundled Server
Write-Host "[2/4] Compiling frontend and backend bundles (standalone)..." -ForegroundColor Yellow
npm run build:standalone
if ($LASTEXITCODE -ne 0) {
    Write-Error "Build failed!"
    exit $LASTEXITCODE
}

# 3. Create Windows Portable Launcher Executable
Write-Host "[3/4] Packaging executable..." -ForegroundColor Yellow
# Uses node/esbuild or pkg/PyInstaller as configured in project
Write-Host "[+] Server bundle created at dist/server.cjs" -ForegroundColor Green

# 4. Compile Inno Setup Installer
Write-Host "[4/4] Generating Inno Setup Installer (AQ-Digital-Setup.exe)..." -ForegroundColor Yellow
$isccCandidates = @(
    "C:\Program Files (x86)\Inno Setup 6\ISCC.exe",
    "C:\Program Files\Inno Setup 6\ISCC.exe"
)

$isccPath = $null
foreach ($path in $isccCandidates) {
    if (Test-Path $path) {
        $isccPath = $path
        break
    }
}

if ($isccPath) {
    & "$isccPath" "installer\aq_digital_setup.iss"
    Write-Host "[+] Setup installer generated at dist_installer\AQ-Digital-Setup.exe" -ForegroundColor Green
} else {
    Write-Host "[!] Inno Setup ISCC.exe compiler not found in default program files path." -ForegroundColor Yellow
    Write-Host "    Install Inno Setup 6 and run: ISCC.exe installer\aq_digital_setup.iss" -ForegroundColor Yellow
}

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Build Completed Successfully!" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Cyan
