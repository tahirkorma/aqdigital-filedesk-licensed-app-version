-- Cloudflare D1 Schema for AQ DIGITAL FileDesk Licensing
-- Table: trial_devices
-- Structure matching existing production database with customer_email column:
CREATE TABLE IF NOT EXISTS trial_devices (
  device_id TEXT PRIMARY KEY,
  customer_email TEXT,
  trial_start_at TEXT NOT NULL,
  trial_expires_at TEXT NOT NULL,
  trial_days INTEGER NOT NULL DEFAULT 14
);

-- Migration query that was run to add customer_email:
-- ALTER TABLE trial_devices ADD COLUMN customer_email TEXT;

-- Table: licenses (commercial paid licenses)
CREATE TABLE IF NOT EXISTS licenses (
  license_key TEXT PRIMARY KEY,
  license_type TEXT NOT NULL DEFAULT 'pro',
  bound_device_id TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  expires_at TEXT
);

-- Optional index for customer email lookups
CREATE INDEX IF NOT EXISTS idx_trial_customer_email ON trial_devices(customer_email);
