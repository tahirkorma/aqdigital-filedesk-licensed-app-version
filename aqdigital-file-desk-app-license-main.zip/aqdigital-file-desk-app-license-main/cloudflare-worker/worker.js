/**
 * Cloudflare Worker for AQ DIGITAL FileDesk Licensing
 * Bound to Cloudflare D1 Database via env.DB
 */

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      ...CORS_HEADERS,
    },
  });
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: CORS_HEADERS });
    }

    if (request.method !== 'POST') {
      return jsonResponse({ error: 'Method not allowed' }, 405);
    }

    try {
      const body = await request.json().catch(() => ({}));
      const action = body.action;

      if (!action) {
        return jsonResponse({ error: 'Action is required' }, 400);
      }

      // ==========================================
      // ACTION: TRIAL
      // ==========================================
      if (action === 'trial') {
        const deviceId = (body.device_id || body.deviceId || '').trim();
        // Support all email parameter variations sent by client or API
        const email = (body.customer_email || body.email || body.customerEmail || '').trim().toLowerCase();

        if (!deviceId) {
          return jsonResponse({ success: false, error: 'Device ID is required' }, 400);
        }

        // Query existing trial record for this Device ID in D1
        const existing = await env.DB.prepare(
          'SELECT device_id, customer_email, trial_start_at, trial_expires_at, trial_days FROM trial_devices WHERE device_id = ?'
        ).bind(deviceId).first();

        const now = new Date();

        if (existing) {
          // Device already has an established trial.
          // Rule: Do NOT create a new trial and do NOT reset existing trial expiry.
          // If customer_email was previously missing in D1 and is now provided, update it.
          if (email && (!existing.customer_email || existing.customer_email !== email)) {
            await env.DB.prepare(
              'UPDATE trial_devices SET customer_email = ? WHERE device_id = ?'
            ).bind(email, deviceId).run();
            existing.customer_email = email;
          }

          const expTime = new Date(existing.trial_expires_at).getTime();
          const isExpired = now.getTime() >= expTime;

          return jsonResponse({
            success: true,
            trial_active: !isExpired,
            trial_expired: isExpired,
            trial_days: existing.trial_days || 14,
            trial_start_at: existing.trial_start_at,
            trial_expires_at: existing.trial_expires_at,
            customer_email: existing.customer_email || email || undefined,
          });
        }

        // Brand-new PC / Device ID:
        // Rule: The customer must enter a valid email address before starting the trial.
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email || !emailRegex.test(email)) {
          return jsonResponse({
            success: false,
            error: 'Please enter your email address to start your free trial.',
          }, 400);
        }

        // Create new 14-day trial for this Device ID and store customer_email
        const trialDays = 14;
        const startIso = now.toISOString();
        const expiresDate = new Date(now.getTime() + trialDays * 24 * 60 * 60 * 1000);
        const expiresIso = expiresDate.toISOString();

        // Exact 5-column INSERT matching production table schema
        await env.DB.prepare(
          'INSERT INTO trial_devices (device_id, customer_email, trial_start_at, trial_expires_at, trial_days) VALUES (?, ?, ?, ?, ?)'
        ).bind(deviceId, email, startIso, expiresIso, trialDays).run();

        return jsonResponse({
          success: true,
          trial_active: true,
          trial_expired: false,
          trial_days: trialDays,
          trial_start_at: startIso,
          trial_expires_at: expiresIso,
          customer_email: email,
        });
      }

      // ==========================================
      // ACTION: VALIDATE (PAID LICENSE)
      // ==========================================
      if (action === 'validate') {
        const licenseKey = (body.license_key || body.licenseKey || '').trim();
        const deviceId = (body.device_id || body.deviceId || '').trim();

        if (!licenseKey || !deviceId) {
          return jsonResponse({ success: false, valid: false, error: 'License key and Device ID are required' }, 400);
        }

        const lic = await env.DB.prepare(
          'SELECT license_key, license_type, bound_device_id, is_active, expires_at FROM licenses WHERE license_key = ?'
        ).bind(licenseKey).first();

        if (!lic) {
          return jsonResponse({ success: false, valid: false, error: 'License key not found' });
        }

        if (!lic.is_active) {
          return jsonResponse({ success: false, valid: false, error: 'License disabled by administrator' });
        }

        if (lic.bound_device_id && lic.bound_device_id !== deviceId) {
          return jsonResponse({ success: false, valid: false, error: 'License key is already activated on another computer' });
        }

        if (lic.expires_at && new Date().getTime() >= new Date(lic.expires_at).getTime()) {
          return jsonResponse({ success: false, valid: false, error: 'License has expired' });
        }

        return jsonResponse({
          success: true,
          valid: true,
          license_type: lic.license_type || 'paid',
          expires_at: lic.expires_at,
        });
      }

      // ==========================================
      // ACTION: ACTIVATE (PAID LICENSE)
      // ==========================================
      if (action === 'activate') {
        const licenseKey = (body.license_key || body.licenseKey || '').trim();
        const deviceId = (body.device_id || body.deviceId || '').trim();

        if (!licenseKey || !deviceId) {
          return jsonResponse({ success: false, error: 'License key and Device ID are required' }, 400);
        }

        const lic = await env.DB.prepare(
          'SELECT license_key, license_type, bound_device_id, is_active, expires_at FROM licenses WHERE license_key = ?'
        ).bind(licenseKey).first();

        if (!lic) {
          return jsonResponse({ success: false, error: 'License key not found' }, 400);
        }

        if (!lic.is_active) {
          return jsonResponse({ success: false, error: 'License has been disabled.' }, 400);
        }

        if (lic.bound_device_id && lic.bound_device_id !== deviceId) {
          return jsonResponse({ success: false, error: 'This license key is already registered to a different computer.' }, 400);
        }

        if (lic.expires_at && new Date().getTime() >= new Date(lic.expires_at).getTime()) {
          return jsonResponse({ success: false, error: 'This license key has expired.' }, 400);
        }

        // Bind license to this device
        await env.DB.prepare(
          'UPDATE licenses SET bound_device_id = ? WHERE license_key = ?'
        ).bind(deviceId, licenseKey).run();

        return jsonResponse({
          success: true,
          valid: true,
          license_type: lic.license_type || 'paid',
          expires_at: lic.expires_at,
        });
      }

      // ==========================================
      // ACTION: ADMIN GET TRIAL (VERIFY D1 TRIAL RECORD)
      // ==========================================
      if (action === 'admin_get_trial') {
        const deviceId = (body.device_id || body.deviceId || '').trim();
        if (!deviceId) {
          return jsonResponse({ success: false, error: 'Device ID is required' }, 400);
        }

        const trial = await env.DB.prepare(
          'SELECT device_id, customer_email, trial_start_at, trial_expires_at, trial_days FROM trial_devices WHERE device_id = ?'
        ).bind(deviceId).first();

        return jsonResponse({
          success: true,
          trial: trial || null,
        });
      }

      // ==========================================
      // ACTION: ADMIN LIST TRIALS (FUTURE ADMIN PANEL)
      // ==========================================
      if (action === 'admin_list_trials') {
        const rows = await env.DB.prepare(
          'SELECT device_id, customer_email, trial_start_at, trial_expires_at, trial_days FROM trial_devices'
        ).all();

        return jsonResponse({
          success: true,
          trials: rows.results || [],
        });
      }

      return jsonResponse({ success: false, error: 'Unknown action' }, 400);
    } catch (err) {
      return jsonResponse({ success: false, error: err.message || 'Internal server error' }, 500);
    }
  },
};
