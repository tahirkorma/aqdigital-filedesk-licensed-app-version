; Inno Setup Script for AQ DIGITAL FileDesk
; Produces AQ-Digital-Setup.exe for Windows 10/11 64-bit

#define MyAppName "AQ DIGITAL FileDesk"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "AQ DIGITAL"
#define MyAppExeName "AQ-Digital.exe"

[Setup]
AppId={{E0FBB1C1-EC13-48E3-90DE-78BB929B49FC}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\AQ-DIGITAL
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
OutputDir=..\dist_installer
OutputBaseFilename=AQ-Digital-Setup
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"
Name: "startupicon"; Description: "Start AQ DIGITAL with Windows"; GroupDescription: "Startup Options:"; Flags: unchecked

[Files]
Source: "..\dist\*"; DestDir: "{app}\dist"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\Start-AQ-Digital.vbs"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Stop-AQ-Digital.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\scripts\*"; DestDir: "{app}\scripts"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "wscript.exe"; Parameters: """{app}\Start-AQ-Digital.vbs"""
Name: "{group}\Stop {#MyAppName}"; Filename: "{app}\Stop-AQ-Digital.bat"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "wscript.exe"; Parameters: """{app}\Start-AQ-Digital.vbs"""; Tasks: desktopicon
Name: "{userstartup}\{#MyAppName}"; Filename: "wscript.exe"; Parameters: """{app}\Start-AQ-Digital.vbs"""; Tasks: startupicon

[Run]
; Configure Windows Firewall rule during installation
Filename: "powershell.exe"; Parameters: "-ExecutionPolicy Bypass -File ""{app}\scripts\firewall\setup_firewall.ps1"""; Flags: runhidden
; Run application after setup
Filename: "wscript.exe"; Parameters: """{app}\Start-AQ-Digital.vbs"""; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

[UninstallRun]
; Remove firewall rules during uninstallation
Filename: "netsh.exe"; Parameters: "advfirewall firewall delete rule name=""AQ DIGITAL Local Server"""; Flags: runhidden

[UninstallDelete]
Type: filesandordirs; Name: "{localappdata}\AQ-DIGITAL\Temp"
Type: filesandordirs; Name: "{localappdata}\AQ-DIGITAL\Incoming"
