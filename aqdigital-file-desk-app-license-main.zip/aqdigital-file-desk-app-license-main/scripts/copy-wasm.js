import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const src = path.join(__dirname, '../node_modules/sql.js/dist/sql-wasm.wasm');
const dest = path.join(__dirname, '../dist/sql-wasm.wasm');

if (fs.existsSync(src)) {
  fs.copyFileSync(src, dest);
  console.log('[+] Copied sql-wasm.wasm to dist/');
}
