# AQ DIGITAL File Desk - Windows Firewall Setup Script
# Restricts incoming connections to the AQ DIGITAL server port

param (
    [int]$Port = 3000
)

Write-Host "[*] Configuring Windows Defender Firewall for AQ DIGITAL..." -ForegroundColor Cyan

# Remove old rule if exists
netsh advfirewall firewall delete rule name="AQ DIGITAL Local Server" | Out-Null

# Add inbound rule allowing local customer traffic on the configured port
netsh advfirewall firewall add rule name="AQ DIGITAL Local Server" `
    dir=in `
    action=allow `
    protocol=TCP `
    localport=$Port `
    profile=private `
    description="Allows local customer devices connected to AQ-DIGITAL Wi-Fi to reach document transfer service."

Write-Host "[+] Firewall rule added successfully for Port $Port (Private/Hotspot Profile only)." -ForegroundColor Green
