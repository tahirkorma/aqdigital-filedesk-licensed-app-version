# AQ DIGITAL File Desk - Hotspot Setup Script
# Requires Administrator privileges on Windows 10/11

param (
    [string]$SSID = "AQ-DIGITAL",
    [string]$Password = "12345678",
    [switch]$DisableInternetSharing = $true
)

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  AQ DIGITAL Hotspot Configuration Tool" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

# 1. Verify Wi-Fi Adapter Hosted Network Capability
Write-Host "[*] Inspecting Wi-Fi adapter hosted network support..." -ForegroundColor Yellow
$wlanDrivers = netsh wlan show drivers
if ($wlanDrivers -match "Hosted network supported\s*:\s*Yes") {
    Write-Host "[+] Hosted network is supported by this Wi-Fi card." -ForegroundColor Green
} else {
    Write-Host "[!] Note: Hosted network may need Windows 10/11 Mobile Hotspot API." -ForegroundColor Yellow
}

# 2. Configure Hosted Network
Write-Host "[*] Setting SSID: $SSID" -ForegroundColor Yellow
netsh wlan set hostednetwork mode=allow ssid="$SSID" key="$Password"

# 3. Start the Hotspot
Write-Host "[*] Starting Wi-Fi Hotspot..." -ForegroundColor Yellow
netsh wlan start hostednetwork

# 4. Ensure Local DHCP / Hotspot Routing Service (SharedAccess) is Running
# NOTE: SharedAccess must run so Windows can assign IP addresses (192.168.137.x) to connecting phones.
Write-Host "[*] Ensuring Hotspot DHCP Service (SharedAccess) is running..." -ForegroundColor Yellow
Set-Service -Name "SharedAccess" -StartupType Manual -ErrorAction SilentlyContinue
Start-Service -Name "SharedAccess" -ErrorAction SilentlyContinue
Write-Host "[+] Local DHCP service is active (Assigns IP 192.168.137.x to phones)." -ForegroundColor Green

# 5. Set up Port Proxy (Port 80 -> Port 3000) for Captive Portal
Write-Host "[*] Configuring Port 80 to Port 3000 redirection..." -ForegroundColor Yellow
netsh interface portproxy delete v4tov4 listenport=80 listenaddress=0.0.0.0 >$null 2>&1
netsh interface portproxy add v4tov4 listenport=80 listenaddress=0.0.0.0 connectport=3000 connectaddress=127.0.0.1

# 6. Windows Firewall Rules
Write-Host "[*] Configuring Windows Firewall..." -ForegroundColor Yellow
netsh advfirewall firewall delete rule name="AQ DIGITAL File Desk Ingress" >$null 2>&1
netsh advfirewall firewall add rule name="AQ DIGITAL File Desk Ingress" dir=in action=allow protocol=TCP localport=3000,80 >$null 2>&1
netsh advfirewall firewall add rule name="AQ DIGITAL DNS Ingress" dir=in action=allow protocol=UDP localport=53 >$null 2>&1

Write-Host "[+] Hotspot configuration complete!" -ForegroundColor Green
Write-Host "    Network SSID: $SSID"
Write-Host "    Password:     $Password"
Write-Host "    Customer URL: http://192.168.137.1:3000/upload" -ForegroundColor Cyan
