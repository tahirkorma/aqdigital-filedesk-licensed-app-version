import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { exec } from 'child_process';
import {
  initStorageDirectories,
  DIRS,
  getStorageUsage,
  setBaseDataDir,
  getBaseDataDir,
  getDefaultDataDir
} from './server/storage';
import {
  getDb,
  getDbFilePath,
  getShopSettings,
  saveShopSettings,
  resetShopSettings,
  getAllJobs,
  getJobById,
  getJobByToken,
  getJobByPublicId,
  clearCompletedJobHistory,
  createJob,
  updateJobStatus,
  addJobFile,
  updateFileScanStatus,
  saveFinalDocument,
  getFinalDocumentByToken,
  saveJobCharges,
  addAuditLog,
  getAuditLogs
} from './server/db';
import {
  sanitizeFilename,
  validateFileSignature,
  scanFileWithDefender,
  DANGEROUS_EXTENSIONS
} from './server/security';
import { getNetworkStatus, getReachableIp } from './server/network';
import { startCaptiveDnsServer } from './server/dns';
import { processAndSaveFinalPdf, saveDirectPortalPdf } from './server/pdf';
import { startCleanupScheduler, runCleanupCycle } from './server/cleanup';
import { getLicenseStatus, activateLicense, getDeviceId, startTrialWithEmail } from './server/license';
import { DashboardStats, EnvironmentReport, LicenseInfo } from './src/types';

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // Initialize storage directories, SQLite database, and cleanup scheduler
  initStorageDirectories();
  await getDb();

  // Load custom storage path if previously configured
  try {
    const startupSettings = await getShopSettings();
    if (startupSettings.storagePath && startupSettings.storagePath.trim()) {
      setBaseDataDir(startupSettings.storagePath.trim());
    }
  } catch (e) {
    // default storage
  }

  startCleanupScheduler();

  // Background check: Auto-cancel jobs awaiting acceptance only if explicitly enabled
  setInterval(async () => {
    try {
      const settings = await getShopSettings();
      // If autoRejectMinutes is 0 or undefined, jobs stay active indefinitely until operator acts
      if (!settings.autoRejectMinutes || settings.autoRejectMinutes <= 0) {
        return;
      }
      const maxWaitMs = settings.autoRejectMinutes * 60 * 1000;
      const allJobs = await getAllJobs();
      const now = Date.now();
      for (const j of allJobs) {
        if (j.status === 'WAITING_ACCEPTANCE') {
          const waitingSince = new Date(j.updated_at).getTime();
          if (now - waitingSince >= maxWaitMs) {
            await updateJobStatus(j.id, 'REJECTED', {
              rejection_reason: `Auto-cancelled: Operator did not accept within ${settings.autoRejectMinutes} minute(s).`
            });
            await addAuditLog('WARN', 'JOB_TIMEOUT', `Job ${j.public_job_id} auto-cancelled after ${settings.autoRejectMinutes}m without operator response`);
          }
        }
      }
    } catch (e) {
      // ignore
    }
  }, 5000);

  await addAuditLog('INFO', 'SYSTEM', 'AQ DIGITAL FileDesk server initialized successfully.');

  // Find reachable local IP and start captive DNS server on UDP 53
  const localReachableIp = getReachableIp();
  startCaptiveDnsServer(localReachableIp);

  app.use(express.json({ limit: '100mb' }));
  app.use(express.urlencoded({ extended: true, limit: '100mb' }));

  // Helper to compute direct customer upload URL for captive redirects
  const getCustomerPortalRedirectUrl = (req: Request) => {
    const forwardedHost = req.headers['x-forwarded-host'] as string | undefined;
    const hostHeader = (forwardedHost || req.headers.host || '').split(',')[0].trim();
    const forwardedProto = (req.headers['x-forwarded-proto'] as string | undefined)?.split(',')[0].trim();
    const proto = forwardedProto || (req.protocol === 'https' ? 'https' : 'http');

    const isWebEnvironment = hostHeader &&
      !hostHeader.startsWith('172.17.') &&
      !hostHeader.startsWith('127.0.0.1') &&
      !hostHeader.startsWith('localhost') &&
      !hostHeader.startsWith('192.168.');

    if (isWebEnvironment && process.platform !== 'win32') {
      return `${proto}://${hostHeader}/upload`;
    }

    const rawHost = hostHeader.split(':')[0];
    const isIpOrLocal = /^(\d{1,3}\.){3}\d{1,3}$/.test(rawHost) || rawHost === 'localhost' || rawHost === '127.0.0.1';
    const targetHost = isIpOrLocal ? rawHost : localReachableIp;
    const portPart = hostHeader.includes(':') ? `:${hostHeader.split(':')[1]}` : `:${PORT}`;
    return `http://${targetHost}${portPart}/upload`;
  };

  // Health check
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({ status: 'ok', product: 'AQ DIGITAL FileDesk', version: '1.0.0' });
  });

  // ==========================================
  // CUSTOMER ENDPOINTS
  // ==========================================

  // Customer Shop Info
  app.get('/api/customer/shop-info', async (req: Request, res: Response) => {
    try {
      const settings = await getShopSettings();
      res.json({
        shopName: 'AQ DIGITAL',
        productName: 'FileDesk',
        hotspotSsid: settings.hotspotSsid,
        customerHostname: settings.customerHostname,
        receivingPaused: settings.receivingPaused,
        maxFileSizeMb: settings.maxFileSizeMb,
        maxFilesPerJob: settings.maxFilesPerJob,
        maxTotalJobSizeMb: settings.maxTotalJobSizeMb,
        allowedExtensions: settings.allowedExtensions,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Captive Portal Auto-Detect Handlers (Apple iOS CNA, Android, Windows)
  // When a phone connects to the shop Wi-Fi, it probes these URLs.
  // Responding with proper captive redirects causes the phone OS to automatically open the upload screen!
  app.get([
    '/hotspot-detect.html',
    '/library/test/success.html',
    '/generate_204',
    '/gen_204',
    '/connecttest.txt',
    '/ncsi.txt',
    '/canonical.html',
    '/kindle-wifi/wifiredirect.html',
    '/check_network_status.txt'
  ], (req: Request, res: Response) => {
    const redirectUrl = getCustomerPortalRedirectUrl(req);

    // Android probe trigger: 302 Found redirect causes Android to trigger the "Sign in to network" sheet / browser auto-open
    if (req.path.includes('generate_204') || req.path.includes('gen_204')) {
      return res.redirect(302, redirectUrl);
    }

    // iOS and Windows probe: Return HTML with immediate redirect to direct upload URL
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.status(200).send(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="refresh" content="0; url=${redirectUrl}">
  <title>AQ DIGITAL FileDesk</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; text-align: center; padding: 40px 20px; background: #f8fafc; color: #0f172a;">
  <div style="max-width: 400px; margin: 0 auto; background: white; padding: 24px; border-radius: 16px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);">
    <h2 style="margin: 0 0 8px 0; color: #1d4ed8; font-size: 20px;">AQ DIGITAL FileDesk</h2>
    <p style="color: #64748b; font-size: 14px; margin-bottom: 20px;">Opening your secure document upload desk...</p>
    <a href="${redirectUrl}" style="display: inline-block; background: #2563eb; color: white; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px;">Tap here if not redirected</a>
  </div>
  <script>window.location.href = "${redirectUrl}";</script>
</body>
</html>`);
  });

  // Customer Job Initialization
  app.post('/api/customer/jobs/init', async (req: Request, res: Response) => {
    try {
      const settings = await getShopSettings();
      if (settings.receivingPaused) {
        return res.status(503).json({
          error: 'RECEIVING PAUSED',
          message: 'New uploads are temporarily unavailable. Please speak with the shop operator.'
        });
      }

      const { customerName, notes, fileCount, totalSize, existingToken } = req.body;

      // If customer is uploading more files to an existing active session/job, reuse it
      if (existingToken) {
        const existingJob = (await getJobByToken(existingToken)) || (await getJobByPublicId(existingToken)) || (await getJobById(existingToken));
        if (existingJob && existingJob.status !== 'TERMINATED' && existingJob.status !== 'REJECTED') {
          const newFileCount = (existingJob.file_count || 0) + (fileCount || 0);
          const newTotalSize = (existingJob.total_size || 0) + (totalSize || 0);
          // If status was PUBLISHED or COMPLETED, keep it accessible while noting extra uploads
          const nextStatus = existingJob.status === 'PUBLISHED' ? 'WAITING_ACCEPTANCE' : existingJob.status;
          await updateJobStatus(existingJob.id, nextStatus, {
            file_count: newFileCount,
            total_size: newTotalSize,
            notes: notes ? (existingJob.notes ? `${existingJob.notes} | ${notes}` : notes) : existingJob.notes
          });
          await addAuditLog('INFO', 'CUSTOMER_UPLOAD', `Additional files added to job: ${existingJob.public_job_id} (+${fileCount} files)`);
          return res.json({
            job_id: existingJob.id,
            public_job_id: existingJob.public_job_id,
            secure_token: existingJob.secure_token
          });
        }
      }

      // Validate counts
      if (fileCount && fileCount > settings.maxFilesPerJob) {
        return res.status(400).json({
          error: 'LIMIT_EXCEEDED',
          message: `Maximum ${settings.maxFilesPerJob} files allowed per job.`
        });
      }
      if (totalSize && totalSize > settings.maxTotalJobSizeMb * 1024 * 1024) {
        return res.status(400).json({
          error: 'LIMIT_EXCEEDED',
          message: `Total job size cannot exceed ${settings.maxTotalJobSizeMb} MB.`
        });
      }

      const job = await createJob({
        customer_name: customerName,
        notes: notes,
        status: 'NEW',
        file_count: fileCount || 0,
        total_size: totalSize || 0
      });

      await addAuditLog('INFO', 'CUSTOMER_UPLOAD', `New upload job initiated: ${job.public_job_id}`);

      res.json({
        job_id: job.id,
        public_job_id: job.public_job_id,
        secure_token: job.secure_token
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Customer Chunked Upload
  app.post('/api/customer/jobs/:token/upload-chunk', async (req: Request, res: Response) => {
    try {
      const { token } = req.params;
      const job = await getJobByToken(token);
      if (!job) {
        return res.status(404).json({ error: 'Job not found or invalid token' });
      }

      // STRICT REQUIREMENT: Operator termination stops processing chunks immediately
      if (job.status === 'TERMINATED') {
        return res.status(410).json({
          error: 'TERMINATED',
          message: 'Upload was stopped and terminated by the shop operator.'
        });
      }

      const settings = await getShopSettings();
      const {
        fileName,
        chunkIndex,
        totalChunks,
        chunkBase64,
        fileIndex,
        totalFiles
      } = req.body;

      if (!fileName || chunkBase64 === undefined || chunkIndex === undefined || !totalChunks) {
        return res.status(400).json({ error: 'Missing chunk payload parameters' });
      }

      // Filename sanitization
      const { safeName, extension } = sanitizeFilename(fileName);

      // Check dangerous extensions blocklist
      const extLower = extension.toLowerCase().replace(/^\./, '');
      if (settings.blockDangerousTypes && DANGEROUS_EXTENSIONS.has(extLower)) {
        await updateJobStatus(job.id, 'REJECTED', { rejection_reason: `Dangerous executable file type: .${extension}` });
        await addAuditLog('SECURITY', 'FILE_VALIDATION', `Blocked dangerous file upload: ${fileName} in job ${job.public_job_id}`);
        return res.status(400).json({
          error: 'BLOCKED_FILE_TYPE',
          message: `File type .${extension} is blocked by shop security policy.`
        });
      }

      // Check allowed extensions
      if (settings.allowedExtensions && settings.allowedExtensions.length > 0) {
        const allowed = settings.allowedExtensions.map((e) => e.toLowerCase().replace(/^\./, ''));
        if (!allowed.includes(extLower)) {
          return res.status(400).json({
            error: 'UNSUPPORTED_EXTENSION',
            message: `Extension .${extension} is not in the shop allowed incoming types (${allowed.join(', ')}).`
          });
        }
      }

      // Update job state to UPLOADING if currently NEW
      if (job.status === 'NEW') {
        await updateJobStatus(job.id, 'UPLOADING');
      }

      // Write chunk into Incoming/
      const incomingPartName = `${job.public_job_id}_file${fileIndex || 0}_${safeName}.part`;
      const incomingPartPath = path.join(DIRS.incoming, incomingPartName);

      const chunkBuffer = Buffer.from(chunkBase64, 'base64');
      fs.appendFileSync(incomingPartPath, chunkBuffer);

      // Check if file is fully uploaded
      const isFileComplete = chunkIndex === totalChunks - 1;

      if (isFileComplete) {
        // Move from Incoming to Quarantine
        const quarantineName = `${job.public_job_id}_${safeName}`;
        const quarantinePath = path.join(DIRS.quarantine, quarantineName);

        if (fs.existsSync(quarantinePath)) {
          fs.unlinkSync(quarantinePath);
        }
        fs.renameSync(incomingPartPath, quarantinePath);

        const fileSize = fs.statSync(quarantinePath).size;

        // Size check
        if (fileSize > settings.maxFileSizeMb * 1024 * 1024) {
          fs.unlinkSync(quarantinePath);
          return res.status(400).json({
            error: 'FILE_TOO_LARGE',
            message: `File exceeds maximum allowed size of ${settings.maxFileSizeMb} MB.`
          });
        }

        // STEP 1: Magic Bytes / File Signature Validation
        const sigResult = validateFileSignature(quarantinePath, extension);
        if (sigResult.isThreat || sigResult.isExecutable) {
          // Disguised executable or malicious structure
          const rejectedPath = path.join(DIRS.rejected, quarantineName);
          fs.renameSync(quarantinePath, rejectedPath);

          await addJobFile({
            job_id: job.id,
            original_filename: fileName,
            safe_filename: safeName,
            extension,
            size: fileSize,
            signature_type: sigResult.detectedType,
            storage_state: 'REJECTED',
            scan_status: 'THREAT_DETECTED',
            threat_name: sigResult.reason || 'Malicious File Signature / Disguised Executable'
          });

          await updateJobStatus(job.id, 'REJECTED', {
            rejection_reason: `Security Threat: ${sigResult.reason || 'Disguised executable'}`
          });

          await addAuditLog('SECURITY', 'THREAT_DETECTED', `Disguised threat detected: ${fileName} in job ${job.public_job_id} (${sigResult.detectedType})`);

          return res.status(400).json({
            error: 'THREAT_DETECTED',
            message: sigResult.reason || 'Security threat detected in uploaded file.'
          });
        }

        // STEP 2: Microsoft Defender Scan
        let scanStatus: 'CLEAN' | 'THREAT_DETECTED' | 'SCAN_UNAVAILABLE' | 'SCAN_ERROR' | 'WAITING_FOR_SCAN' = 'WAITING_FOR_SCAN';
        let threatName: string | undefined;

        if (settings.requireDefenderScan) {
          await updateJobStatus(job.id, 'SCANNING');
          const defenderResult = await scanFileWithDefender(quarantinePath, settings.allowEmergencyBypass);
          scanStatus = defenderResult.status as any;
          threatName = defenderResult.threatName;

          if (scanStatus === 'THREAT_DETECTED') {
            const rejectedPath = path.join(DIRS.rejected, quarantineName);
            fs.renameSync(quarantinePath, rejectedPath);

            await addJobFile({
              job_id: job.id,
              original_filename: fileName,
              safe_filename: safeName,
              extension,
              size: fileSize,
              signature_type: sigResult.detectedType,
              storage_state: 'REJECTED',
              scan_status: 'THREAT_DETECTED',
              threat_name: threatName || 'Microsoft Defender Threat'
            });

            await updateJobStatus(job.id, 'REJECTED', {
              rejection_reason: `Defender threat detected: ${threatName || 'Malware'}`
            });

            await addAuditLog('SECURITY', 'DEFENDER_THREAT', `Defender threat: ${fileName} in ${job.public_job_id}`);

            return res.status(400).json({
              error: 'DEFENDER_THREAT',
              message: `Microsoft Defender detected a security threat: ${threatName}`
            });
          }
        } else {
          scanStatus = 'CLEAN';
        }

        // Move to Clean Job Storage
        let finalStorageState: 'CLEAN' | 'QUARANTINE' = 'QUARANTINE';
        if (scanStatus === 'CLEAN' || scanStatus === 'SCAN_UNAVAILABLE') {
          const jobStorageDir = path.join(DIRS.jobs, job.public_job_id);
          if (!fs.existsSync(jobStorageDir)) {
            fs.mkdirSync(jobStorageDir, { recursive: true });
          }
          const cleanFilePath = path.join(jobStorageDir, safeName);
          if (fs.existsSync(quarantinePath)) {
            if (fs.existsSync(cleanFilePath)) {
              fs.unlinkSync(cleanFilePath);
            }
            fs.renameSync(quarantinePath, cleanFilePath);
          }
          finalStorageState = 'CLEAN';
          scanStatus = 'CLEAN';
        }

        await addJobFile({
          job_id: job.id,
          original_filename: fileName,
          safe_filename: safeName,
          extension,
          size: fileSize,
          signature_type: sigResult.detectedType,
          storage_state: finalStorageState,
          scan_status: scanStatus,
          threat_name: threatName,
          scan_timestamp: new Date().toISOString()
        });

        // If this is the last file in the job, update status to WAITING_ACCEPTANCE
        const isJobComplete = (fileIndex === undefined) || (totalFiles && fileIndex === totalFiles - 1);
        if (isJobComplete) {
          const newStatus = 'WAITING_ACCEPTANCE';
          await updateJobStatus(job.id, newStatus);
          await addAuditLog('INFO', 'JOB_COMPLETE', `Job upload completed: ${job.public_job_id} (Status: ${newStatus}, Ready for operator review)`);
        }
      }

      res.json({
        success: true,
        chunkIndex,
        totalChunks,
        fileComplete: isFileComplete
      });
    } catch (err: any) {
      console.error('Error in upload-chunk:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // Customer Active Session (Allows already-open /upload pages to auto-reconnect to in-progress uploads)
  app.get('/api/customer/active-session', async (req: Request, res: Response) => {
    try {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      const allJobs = await getAllJobs();
      // Look for latest in-flight, unfinished job active in last 6 hours
      const inFlightStatuses = ['NEW', 'UPLOADING', 'UPLOAD_COMPLETE', 'WAITING_ACCEPTANCE', 'ACCEPTED', 'PROCESSING', 'SCANNING', 'CLEAN'];
      const sixHoursAgo = new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString();
      const activeJob = allJobs.find(
        (j) => j.created_at >= sixHoursAgo && inFlightStatuses.includes(j.status)
      );
      if (activeJob) {
        return res.json({
          hasActiveSession: true,
          public_job_id: activeJob.public_job_id,
          secure_token: activeJob.secure_token,
          status: activeJob.status
        });
      }
      res.json({ hasActiveSession: false });
    } catch {
      res.json({ hasActiveSession: false });
    }
  });

  // Customer Job Status (Single-Job Polling / Waiting Page)
  app.get('/api/customer/jobs/:token/status', async (req: Request, res: Response) => {
    try {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');

      const { token } = req.params;
      const job = (await getJobByToken(token)) || (await getJobByPublicId(token)) || (await getJobById(token));
      if (!job) {
        return res.status(404).json({ error: 'Job not found' });
      }

      const hasFinalDoc = !!job.final_document || job.status === 'PUBLISHED';
      let docPayload = null;
      if (job.final_document) {
        docPayload = {
          filename: job.final_document.generated_filename,
          size: job.final_document.file_size,
          published_at: job.final_document.published_at,
          download_url: `/api/job/${job.secure_token}/document/${job.final_document.secure_document_token}`
        };
      } else if (job.status === 'PUBLISHED') {
        const safePublic = job.public_job_id.replace(/[^a-zA-Z0-9_-]/g, '_');
        docPayload = {
          filename: `${safePublic}_final.pdf`,
          size: 0,
          published_at: job.published_at || new Date().toISOString(),
          download_url: `/api/job/${job.secure_token}/document/latest`
        };
      }

      // Return customer-facing safe details with charges breakdown
      res.json({
        public_job_id: job.public_job_id,
        status: job.status,
        customer_name: job.customer_name,
        notes: job.notes,
        file_count: job.files?.length || job.file_count,
        total_size: job.total_size,
        time_remaining_seconds: job.time_remaining_seconds,
        created_at: job.created_at,
        updated_at: job.updated_at,
        rejection_reason: job.rejection_reason,
        has_final_document: hasFinalDoc,
        final_document: docPayload,
        charges: job.charges || [],
        total_charges: (job.charges || []).reduce((sum, c) => sum + (Number(c.amount) || 0), 0)
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // SECURE CUSTOMER DOCUMENT ACCESS
  // /api/job/:jobToken/document/:docToken
  app.get('/api/job/:jobToken/document/:docToken', async (req: Request, res: Response) => {
    try {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      const { jobToken, docToken } = req.params;
      const job = (await getJobByToken(jobToken)) || (await getJobByPublicId(jobToken)) || (await getJobById(jobToken));
      if (!job) {
        return res.status(403).json({ error: 'Unauthorized: invalid job token' });
      }

      let doc = await getFinalDocumentByToken(docToken);
      if (!doc || doc.job_id !== job.id) {
        if (docToken === 'latest' || job.final_document) {
          doc = job.final_document || null;
        }
      }

      // Verify file exists in FinalDocuments/
      let filePath = doc ? path.join(DIRS.finalDocs, doc.generated_filename) : '';
      if (!doc || !fs.existsSync(filePath)) {
        // Fallback: search for public_job_id match in FinalDocuments
        const safePublic = job.public_job_id.replace(/[^a-zA-Z0-9_-]/g, '_');
        if (fs.existsSync(DIRS.finalDocs)) {
          const match = fs.readdirSync(DIRS.finalDocs).find((f) => f.startsWith(safePublic));
          if (match) {
            filePath = path.join(DIRS.finalDocs, match);
            doc = {
              id: 'doc_' + safePublic,
              job_id: job.id,
              original_source: 'PORTAL_AUTO',
              generated_filename: match,
              file_size: fs.statSync(filePath).size,
              secure_document_token: 'latest',
              created_at: job.updated_at || new Date().toISOString(),
              published_at: job.updated_at || new Date().toISOString(),
            };
          }
        }
      }

      if (!doc || !fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'Document file not found' });
      }

      await addAuditLog('INFO', 'DOCUMENT_DOWNLOAD', `Customer downloaded final document for ${job.public_job_id}`);

      const ext = path.extname(doc.generated_filename).toLowerCase();
      const mimeTypes: Record<string, string> = {
        '.pdf': 'application/pdf',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.webp': 'image/webp',
        '.bmp': 'image/bmp',
        '.gif': 'image/gif'
      };
      res.setHeader('Content-Type', mimeTypes[ext] || 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(doc.generated_filename)}"`);
      const fileStream = fs.createReadStream(filePath);
      fileStream.pipe(res);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // OPERATOR ENDPOINTS
  // ==========================================

  // Operator Overview (Unified Bootstrap & Polling Endpoint)
  app.get('/api/operator/overview', async (req: Request, res: Response) => {
    try {
      const today = new Date().toISOString().slice(0, 10);
      const [allJobs, settings, netStatus, license] = await Promise.all([
        getAllJobs(),
        getShopSettings(),
        getNetworkStatus(),
        getLicenseStatus(false)
      ]);

      const todayJobs = allJobs.filter((j) => j.created_at.startsWith(today));
      const storage = getStorageUsage(settings.storageWarningPercent, settings.storageCriticalPercent);

      let filesReceivedCount = 0;
      let pendingCount = 0;
      let completedCount = 0;
      let rejectedCount = 0;
      let terminatedCount = 0;
      let todayRevenue = 0;

      for (const j of todayJobs) {
        filesReceivedCount += j.file_count || 0;
        if (['NEW', 'UPLOADING', 'UPLOAD_COMPLETE', 'SCANNING', 'CLEAN', 'WAITING_ACCEPTANCE', 'ACCEPTED', 'PROCESSING'].includes(j.status)) {
          pendingCount++;
        } else if (['COMPLETED', 'PUBLISHED'].includes(j.status)) {
          completedCount++;
        } else if (j.status === 'REJECTED') {
          rejectedCount++;
        } else if (j.status === 'TERMINATED') {
          terminatedCount++;
        }

        if (j.charges) {
          for (const c of j.charges) {
            todayRevenue += c.amount;
          }
        }
      }

      const stats: DashboardStats = {
        todayJobsCount: todayJobs.length,
        filesReceivedCount,
        pendingCount,
        completedCount,
        rejectedCount,
        terminatedCount,
        todayRevenue,
        storage,
        receivingPaused: settings.receivingPaused
      };

      res.json({
        jobs: allJobs,
        stats,
        network: netStatus,
        settings,
        license,
        storagePaths: {
          jobsDir: DIRS.jobs,
          quarantineDir: DIRS.quarantine,
          finalDocsDir: DIRS.finalDocs,
          dbPath: getDbFilePath()
        }
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator License Status Check
  app.get('/api/operator/license/status', async (req: Request, res: Response) => {
    try {
      const force = req.query.force === 'true';
      const license = await getLicenseStatus(force);
      res.json(license);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator License Activation
  app.post('/api/operator/license/activate', async (req: Request, res: Response) => {
    try {
      const { licenseKey } = req.body;
      if (!licenseKey || typeof licenseKey !== 'string') {
        return res.status(400).json({ success: false, error: 'License key is required.' });
      }

      const result = await activateLicense(licenseKey);
      if (result.success) {
        await addAuditLog('INFO', 'LICENSE', `License activated successfully (${result.license.licenseType || 'paid'})`);
        res.json(result);
      } else {
        await addAuditLog('WARN', 'LICENSE', `License activation failed: ${result.error}`);
        res.status(400).json(result);
      }
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Operator Start Trial with Email
  app.post('/api/operator/license/start-trial', async (req: Request, res: Response) => {
    try {
      const email = req.body?.email || req.body?.customer_email || req.body?.customerEmail;
      if (!email || typeof email !== 'string') {
        return res.status(400).json({
          success: false,
          error: 'Please enter your email address to start your free trial.',
        });
      }

      const result = await startTrialWithEmail(email);
      if (result.success) {
        await addAuditLog('INFO', 'LICENSE', `Free trial initiated with customer email: ${email}`);
        res.json(result);
      } else {
        await addAuditLog('WARN', 'LICENSE', `Trial initiation failed: ${result.error}`);
        res.status(400).json(result);
      }
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Operator Force License Validation with Cloudflare Worker
  app.post('/api/operator/license/validate', async (req: Request, res: Response) => {
    try {
      const email = req.body?.email || req.body?.customer_email || req.body?.customerEmail;
      const license = await getLicenseStatus(true, email);
      res.json(license);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Stats
  app.get('/api/operator/stats', async (req: Request, res: Response) => {
    try {
      const today = new Date().toISOString().slice(0, 10);
      const allJobs = await getAllJobs();
      const todayJobs = allJobs.filter((j) => j.created_at.startsWith(today));
      const settings = await getShopSettings();
      const storage = getStorageUsage(settings.storageWarningPercent, settings.storageCriticalPercent);

      let filesReceivedCount = 0;
      let pendingCount = 0;
      let completedCount = 0;
      let rejectedCount = 0;
      let terminatedCount = 0;
      let todayRevenue = 0;

      for (const j of todayJobs) {
        filesReceivedCount += j.file_count || 0;
        if (['NEW', 'UPLOADING', 'UPLOAD_COMPLETE', 'SCANNING', 'CLEAN', 'ACCEPTED', 'PROCESSING'].includes(j.status)) {
          pendingCount++;
        } else if (['COMPLETED', 'PUBLISHED'].includes(j.status)) {
          completedCount++;
        } else if (j.status === 'REJECTED') {
          rejectedCount++;
        } else if (j.status === 'TERMINATED') {
          terminatedCount++;
        }

        if (j.charges) {
          for (const c of j.charges) {
            todayRevenue += c.amount;
          }
        }
      }

      const stats: DashboardStats = {
        todayJobsCount: todayJobs.length,
        filesReceivedCount,
        pendingCount,
        completedCount,
        rejectedCount,
        terminatedCount,
        todayRevenue,
        storage,
        receivingPaused: settings.receivingPaused
      };

      res.json(stats);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Jobs List
  app.get('/api/operator/jobs', async (req: Request, res: Response) => {
    try {
      const { date, search } = req.query;
      const jobs = await getAllJobs(date as string, search as string);
      res.json(jobs);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Single Job Details
  app.get('/api/operator/jobs/:id', async (req: Request, res: Response) => {
    try {
      const job = await getJobById(req.params.id);
      if (!job) return res.status(404).json({ error: 'Job not found' });
      res.json(job);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Download Clean File
  app.get('/api/operator/jobs/:id/files/:fileId/download', async (req: Request, res: Response) => {
    try {
      const job = await getJobById(req.params.id);
      if (!job) return res.status(404).json({ error: 'Job not found' });

      const file = job.files?.find((f) => f.id === req.params.fileId);
      if (!file) return res.status(404).json({ error: 'File not found in job' });

      // Check both clean jobs dir and quarantine as fallback
      let cleanFilePath = path.join(DIRS.jobs, job.public_job_id, file.safe_filename);
      if (!fs.existsSync(cleanFilePath)) {
        const quarantinePath = path.join(DIRS.quarantine, `${job.public_job_id}_${file.safe_filename}`);
        if (fs.existsSync(quarantinePath)) {
          cleanFilePath = quarantinePath;
        } else {
          return res.status(404).json({ error: 'File on disk not found.' });
        }
      }

      await addAuditLog('INFO', 'FILE_DOWNLOAD', `Operator downloaded file ${file.original_filename} (${job.public_job_id})`);

      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(file.original_filename)}"`);
      const fileStream = fs.createReadStream(cleanFilePath);
      fileStream.pipe(res);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Preview / View File Inline in Browser Tab
  app.get('/api/operator/jobs/:id/files/:fileId/view', async (req: Request, res: Response) => {
    try {
      const job = await getJobById(req.params.id);
      if (!job) return res.status(404).json({ error: 'Job not found' });

      const file = job.files?.find((f) => f.id === req.params.fileId);
      if (!file) return res.status(404).json({ error: 'File not found in job' });

      let cleanFilePath = path.join(DIRS.jobs, job.public_job_id, file.safe_filename);
      if (!fs.existsSync(cleanFilePath)) {
        const quarantinePath = path.join(DIRS.quarantine, `${job.public_job_id}_${file.safe_filename}`);
        if (fs.existsSync(quarantinePath)) {
          cleanFilePath = quarantinePath;
        } else {
          return res.status(404).json({ error: 'File on disk not found.' });
        }
      }

      const ext = path.extname(file.original_filename).toLowerCase();
      const mimeTypes: Record<string, string> = {
        '.pdf': 'application/pdf',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.webp': 'image/webp',
        '.bmp': 'image/bmp',
        '.gif': 'image/gif',
        '.txt': 'text/plain',
        '.csv': 'text/csv',
      };

      res.setHeader('Content-Type', mimeTypes[ext] || 'application/octet-stream');
      res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(file.original_filename)}"`);
      const fileStream = fs.createReadStream(cleanFilePath);
      fileStream.pipe(res);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Open File via Local Host Application (Windows Shell Start / Open)
  app.post('/api/operator/open-file', async (req: Request, res: Response) => {
    try {
      const { filePath, jobId, fileId } = req.body;
      let targetPath = filePath;

      if (!targetPath && jobId && fileId) {
        const job = await getJobById(jobId);
        const file = job?.files?.find((f) => f.id === fileId);
        if (job && file) {
          targetPath = path.join(DIRS.jobs, job.public_job_id, file.safe_filename);
        }
      }

      if (!targetPath || !fs.existsSync(targetPath)) {
        return res.status(404).json({ error: 'File does not exist on disk', path: targetPath });
      }

      const normalized = path.resolve(targetPath);
      if (process.platform === 'win32') {
        exec(`start "" "${normalized}"`);
      } else if (process.platform === 'darwin') {
        exec(`open "${normalized}"`);
      } else {
        exec(`xdg-open "${normalized}"`);
      }

      await addAuditLog('INFO', 'FILE_OPEN', `Operator opened file in local application: ${path.basename(normalized)}`);
      res.json({ success: true, opened: normalized });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Open Folder in Windows File Explorer / OS File Manager
  app.post('/api/operator/open-folder', async (req: Request, res: Response) => {
    try {
      const { folderPath, filePath, jobId } = req.body;
      let targetFolder = folderPath;

      if (jobId && !targetFolder) {
        const job = await getJobById(jobId);
        if (job) {
          targetFolder = path.join(DIRS.jobs, job.public_job_id);
          if (!fs.existsSync(targetFolder)) {
            fs.mkdirSync(targetFolder, { recursive: true });
          }
        }
      }

      if (filePath && fs.existsSync(filePath)) {
        const normalizedFile = path.resolve(filePath);
        if (process.platform === 'win32') {
          // Open Explorer and highlight the specific file!
          exec(`explorer.exe /select,"${normalizedFile}"`);
          return res.json({ success: true, highlighted: normalizedFile });
        }
        targetFolder = path.dirname(normalizedFile);
      }

      if (!targetFolder || !fs.existsSync(targetFolder)) {
        // Fallback to main Jobs root if specific folder does not exist yet
        targetFolder = DIRS.jobs;
        if (!fs.existsSync(targetFolder)) {
          fs.mkdirSync(targetFolder, { recursive: true });
        }
      }

      const normalizedDir = path.resolve(targetFolder);
      if (process.platform === 'win32') {
        exec(`explorer.exe "${normalizedDir}"`);
      } else if (process.platform === 'darwin') {
        exec(`open "${normalizedDir}"`);
      } else {
        exec(`xdg-open "${normalizedDir}"`);
      }

      await addAuditLog('INFO', 'FOLDER_OPEN', `Operator opened local folder in Explorer: ${normalizedDir}`);
      res.json({ success: true, opened: normalizedDir });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Accept Job - Reliably Moves Files into the Job Storage Directory
  app.post('/api/operator/jobs/:id/accept', async (req: Request, res: Response) => {
    try {
      const job = await getJobById(req.params.id);
      if (!job) return res.status(404).json({ error: 'Job not found' });

      // Guarantee the Job storage folder exists on disk
      const jobStorageDir = path.join(DIRS.jobs, job.public_job_id);
      if (!fs.existsSync(jobStorageDir)) {
        fs.mkdirSync(jobStorageDir, { recursive: true });
      }

      // Move any quarantined or incoming files to the clean job directory
      if (job.files && job.files.length > 0) {
        for (const file of job.files) {
          const destPath = path.join(jobStorageDir, file.safe_filename);
          const sourceQuarantine = path.join(DIRS.quarantine, `${job.public_job_id}_${file.safe_filename}`);
          const altQuarantine = path.join(DIRS.quarantine, file.safe_filename);

          if (fs.existsSync(sourceQuarantine)) {
            if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
            fs.renameSync(sourceQuarantine, destPath);
          } else if (fs.existsSync(altQuarantine)) {
            if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
            fs.renameSync(altQuarantine, destPath);
          }

          await updateFileScanStatus(file.id, 'CLEAN', 'CLEAN');
        }
      }

      // Create a readable job manifest summary text file in the folder for operator convenience
      try {
        const summaryContent = [
          `AQ DIGITAL FILE DESK - JOB DETAILS`,
          `========================================`,
          `Job ID:        ${job.public_job_id}`,
          `Customer:      ${job.customer_name || 'Walk-in'}`,
          `Received At:   ${new Date(job.created_at).toLocaleString()}`,
          `Instructions:  ${job.notes || 'None'}`,
          `Total Files:   ${job.files?.length || job.file_count}`,
          `Total Size:    ${job.total_size} bytes`,
          `Storage Path:  ${jobStorageDir}`,
          `========================================`,
          `Files:`,
          ...(job.files || []).map((f, idx) => `  [${idx + 1}] ${f.original_filename} (${f.safe_filename}) - ${f.size} bytes`),
        ].join('\r\n');
        fs.writeFileSync(path.join(jobStorageDir, '_JOB_DETAILS.txt'), summaryContent, 'utf-8');
      } catch (err) {
        // ignore manifest write failure
      }

      const updated = await updateJobStatus(req.params.id, 'ACCEPTED');
      await addAuditLog('INFO', 'JOB_ACTION', `Operator accepted job ${updated.public_job_id} - Files verified in ${jobStorageDir}`);
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Reject Job
  app.post('/api/operator/jobs/:id/reject', async (req: Request, res: Response) => {
    try {
      const { reason } = req.body;
      const job = await updateJobStatus(req.params.id, 'REJECTED', {
        rejection_reason: reason || 'Rejected by shop operator'
      });
      await addAuditLog('WARN', 'JOB_ACTION', `Operator rejected job ${job.public_job_id}: ${reason}`);
      res.json(job);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Terminate Job
  app.post('/api/operator/jobs/:id/terminate', async (req: Request, res: Response) => {
    try {
      const job = await updateJobStatus(req.params.id, 'TERMINATED');
      await addAuditLog('WARN', 'JOB_ACTION', `Operator terminated job ${job.public_job_id}`);
      res.json(job);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Pause / Unpause Receiving Toggle
  app.post('/api/operator/receiving/toggle', async (req: Request, res: Response) => {
    try {
      const current = await getShopSettings();
      const updated = await saveShopSettings({ receivingPaused: !current.receivingPaused });
      await addAuditLog(
        'INFO',
        'SETTINGS',
        `Customer receiving status changed to: ${updated.receivingPaused ? 'PAUSED' : 'ACTIVE'}`
      );
      res.json({ receivingPaused: updated.receivingPaused });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Network Status
  app.get('/api/operator/network', async (req: Request, res: Response) => {
    try {
      const netStatus = await getNetworkStatus(req);
      res.json(netStatus);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Settings
  app.get('/api/operator/settings', async (req: Request, res: Response) => {
    try {
      const settings = await getShopSettings();
      res.json(settings);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/operator/settings', async (req: Request, res: Response) => {
    try {
      const incoming = req.body;

      // Validation
      if (incoming.hotspotSsid && incoming.hotspotSsid.length < 2) {
        return res.status(400).json({ error: 'Hotspot SSID must be at least 2 characters.' });
      }
      if (incoming.hotspotPassword && incoming.hotspotPassword.length < 8) {
        return res.status(400).json({ error: 'Hotspot password must be at least 8 characters.' });
      }
      if (incoming.serverPort && (incoming.serverPort < 1 || incoming.serverPort > 65535)) {
        return res.status(400).json({ error: 'Server port must be between 1 and 65535.' });
      }

      if (incoming.storagePath !== undefined) {
        if (typeof incoming.storagePath === 'string' && incoming.storagePath.trim()) {
          setBaseDataDir(incoming.storagePath.trim());
        }
      }

      const updated = await saveShopSettings(incoming);
      await addAuditLog('INFO', 'SETTINGS', 'Shop configuration updated by operator');
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Reset Settings to Factory Defaults
  app.post('/api/operator/settings/reset', async (req: Request, res: Response) => {
    try {
      const reset = await resetShopSettings();
      setBaseDataDir(getDefaultDataDir());
      await addAuditLog('WARN', 'SETTINGS', 'Operator reset all settings to factory defaults');
      res.json(reset);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Close/Exit App
  app.post('/api/operator/shutdown', async (req: Request, res: Response) => {
    try {
      await addAuditLog('WARN', 'SYSTEM', 'Operator initiated app shutdown');
      res.json({ success: true, message: 'Server shutting down' });
      setTimeout(() => {
        process.exit(0);
      }, 500);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Upload Return Document (PDF or Image: Receipt / online form return)
  app.post('/api/operator/portal-pdf/upload', async (req: Request, res: Response) => {
    try {
      const { jobId, base64Pdf, originalFilename } = req.body;
      const job = await getJobById(jobId);
      if (!job) return res.status(404).json({ error: 'Job not found' });

      if (!base64Pdf) return res.status(400).json({ error: 'Missing document data' });

      const ext = originalFilename ? path.extname(originalFilename).toLowerCase() || '.pdf' : '.pdf';
      const tempFileName = `portal_${job.public_job_id}_${Date.now()}${ext}`;
      const tempPath = path.join(DIRS.temp, tempFileName);
      fs.writeFileSync(tempPath, Buffer.from(base64Pdf, 'base64'));

      res.json({
        tempPath,
        filename: originalFilename || `document${ext}`,
        isImage: ['.png', '.jpg', '.jpeg', '.webp', '.bmp'].includes(ext)
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Stage Existing Customer File for Return Document editing
  app.post('/api/operator/portal-pdf/stage-job-file', async (req: Request, res: Response) => {
    try {
      const { jobId, fileId } = req.body;
      const job = (await getJobById(jobId)) || (await getJobByPublicId(jobId));
      if (!job) return res.status(404).json({ error: 'Job not found' });

      const targetFile = job.files?.find((f) => f.id === fileId || f.safe_filename === fileId || f.original_filename === fileId);
      if (!targetFile || !targetFile.storage_path || !fs.existsSync(targetFile.storage_path)) {
        return res.status(404).json({ error: 'File not found on storage' });
      }

      const ext = path.extname(targetFile.safe_filename).toLowerCase() || '.pdf';
      const tempFileName = `portal_${job.public_job_id}_${Date.now()}${ext}`;
      const tempPath = path.join(DIRS.temp, tempFileName);
      fs.copyFileSync(targetFile.storage_path, tempPath);
      const fileBuffer = fs.readFileSync(tempPath);
      const base64Data = fileBuffer.toString('base64');
      const mime = ext === '.pdf' ? 'application/pdf' : 'image/' + ext.replace('.', '');
      const dataUrl = `data:${mime};base64,${base64Data}`;

      res.json({
        tempPath,
        filename: targetFile.original_filename,
        isImage: ['.png', '.jpg', '.jpeg', '.webp', '.bmp'].includes(ext),
        dataUrl,
        size: targetFile.size
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Portal Document: Send Directly (original unedited PDF or Image)
  app.post('/api/operator/portal-pdf/send-direct', async (req: Request, res: Response) => {
    try {
      const { jobId, tempPath, originalFilename } = req.body;
      const job = (await getJobById(jobId)) || (await getJobByPublicId(jobId));
      if (!job) return res.status(404).json({ error: 'Job not found' });

      const result = await saveDirectPortalPdf(tempPath, job.public_job_id, originalFilename);

      const finalDoc = await saveFinalDocument({
        job_id: job.id,
        original_source: 'PORTAL_DIRECT',
        generated_filename: result.filename,
        file_size: result.size
      });

      await updateJobStatus(job.id, 'PUBLISHED');
      await addAuditLog('INFO', 'PORTAL_RETURN', `Published direct return document (${result.filename}) to customer for ${job.public_job_id}`);

      res.json({
        success: true,
        finalDoc,
        downloadUrl: `/api/job/${job.secure_token}/document/${finalDoc.secure_document_token}`
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Portal PDF: Edit & Send (crop, text annotations, charges)
  app.post('/api/operator/portal-pdf/process', async (req: Request, res: Response) => {
    try {
      const { jobId, tempPath, editOptions, charges } = req.body;
      const job = (await getJobById(jobId)) || (await getJobByPublicId(jobId));
      if (!job) return res.status(404).json({ error: 'Job not found' });

      const effectiveCharges = charges || editOptions?.charges || [];

      const result = await processAndSaveFinalPdf(tempPath, job.public_job_id, {
        ...editOptions,
        charges: effectiveCharges
      });

      // Save charges in DB
      if (effectiveCharges && Array.isArray(effectiveCharges)) {
        await saveJobCharges(job.id, effectiveCharges);
      }

      const finalDoc = await saveFinalDocument({
        job_id: job.id,
        original_source: 'PORTAL_EDITED',
        generated_filename: result.filename,
        file_size: result.size
      });

      await updateJobStatus(job.id, 'PUBLISHED');
      await addAuditLog('INFO', 'PORTAL_RETURN', `Published edited portal PDF with charges to customer for ${job.public_job_id}`);

      res.json({
        success: true,
        finalDoc,
        downloadUrl: `/api/job/${job.secure_token}/document/${finalDoc.secure_document_token}`
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Clear Completed Job History (Safely clears old/completed jobs while active jobs are untouched)
  app.post('/api/operator/jobs/clear-history', async (req: Request, res: Response) => {
    try {
      const result = await clearCompletedJobHistory();
      await addAuditLog('INFO', 'HISTORY_CLEARED', `Operator cleared ${result.deletedCount} completed/old jobs from history`);
      res.json({
        success: true,
        clearedCount: result.deletedCount,
        clearedJobIds: result.deletedJobIds
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Manual Cleanup Run
  app.post('/api/operator/cleanup/run', async (req: Request, res: Response) => {
    try {
      const result = await runCleanupCycle();
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Audit Logs
  app.get('/api/operator/logs', async (req: Request, res: Response) => {
    try {
      const limit = Number(req.query.limit) || 100;
      const logs = await getAuditLogs(limit);
      res.json(logs);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Operator Environment Inspection Report (Phase 85)
  app.get('/api/operator/environment', async (req: Request, res: Response) => {
    try {
      const isWin = process.platform === 'win32';
      const storage = getStorageUsage();
      const report: EnvironmentReport = {
        os: `${os.type()} ${os.release()}`,
        platform: process.platform,
        arch: process.arch,
        nodeVersion: process.version,
        pythonVersion: 'Python 3.10',
        gitVersion: 'Git 2.34.1',
        isWindows: isWin,
        defenderAvailable: isWin,
        firewallAvailable: isWin,
        wifiAdapterAvailable: true,
        hotspotSupported: true,
        isAdmin: false,
        diskFreeGb: Math.round(storage.freeBytes / (1024 * 1024 * 1024)),
        diskTotalGb: Math.round(storage.totalBytes / (1024 * 1024 * 1024)),
        canBuildWindowsExe: isWin,
        packagingTools: isWin ? ['PyInstaller', 'Inno Setup', 'esbuild'] : ['Inno Setup script included', 'esbuild']
      };
      res.json(report);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // In development, mount Vite dev middleware; in production, serve built static files
  if (process.env.NODE_ENV !== 'production') {
    try {
      const devViteModule = './server/viteDev.ts';
      const { setupVite } = await import(devViteModule);
      await setupVite(app);
    } catch (devErr: any) {
      console.warn('[AQ DIGITAL FileDesk] Vite dev server not loaded, falling back to static dist:', devErr?.message);
      const distPath = path.join(process.cwd(), 'dist');
      if (fs.existsSync(distPath)) {
        app.use(express.static(distPath));
        app.get('*', (req: Request, res: Response) => {
          res.sendFile(path.join(distPath, 'index.html'));
        });
      }
    }
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[AQ DIGITAL FileDesk] Server listening on http://0.0.0.0:${PORT}`);
  });

  // Windows / Production Captive Portal Port 80 Redirector (Option A Single-Scan)
  if (process.platform === 'win32' || process.env.ENABLE_PORT_80 === 'true') {
    try {
      const port80 = express();
      port80.use((req, res) => {
        const redirectUrl = getCustomerPortalRedirectUrl(req);
        res.redirect(302, redirectUrl);
      });
      const server80 = port80.listen(80, '0.0.0.0', () => {
        console.log(`[Captive Portal] Port 80 redirector active -> Redirecting to http://${localReachableIp}:${PORT}/upload`);
      });
      server80.on('error', (e: any) => {
        console.log('[Captive Portal] Port 80 redirector skipped (non-admin or port in use):', e.message);
      });
    } catch {
      // Ignore if cannot bind port 80
    }
  }
}

startServer().catch((err) => {
  console.error('[AQ DIGITAL FileDesk] Fatal startup error:', err);
});
