import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import { DIRS, PERSISTENT_CONFIG_DIR } from './storage';
import { Job, JobFile, FinalDocument, ChargeItem, ShopSettings, AuditLog } from '../src/types';

let dbInstance: Database | null = null;

export function getDbFilePath(): string {
  return path.join(PERSISTENT_CONFIG_DIR, 'aq_digital.sqlite');
}

export async function getDb(): Promise<Database> {
  if (dbInstance) return dbInstance;

  const SQL = await initSqlJs();
  const dbPath = getDbFilePath();

  // If new DB doesn't exist yet, check if legacy cwd location exists to migrate
  if (!fs.existsSync(dbPath)) {
    const legacyPath = path.join(process.cwd(), 'AQ-DIGITAL', 'Config', 'aq_digital.sqlite');
    if (fs.existsSync(legacyPath) && legacyPath !== dbPath) {
      try {
        const legacyBuffer = fs.readFileSync(legacyPath);
        const dbDir = path.dirname(dbPath);
        if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
        fs.writeFileSync(dbPath, legacyBuffer);
        console.log(`[AQ DIGITAL] Migrated SQLite database from ${legacyPath} to ${dbPath}`);
      } catch (err) {
        // ignore migration error
      }
    }
  }

  if (fs.existsSync(dbPath)) {
    try {
      const buffer = fs.readFileSync(dbPath);
      dbInstance = new SQL.Database(buffer);
    } catch (e) {
      console.error('Failed to read existing SQLite DB, creating fresh:', e);
      dbInstance = new SQL.Database();
    }
  } else {
    dbInstance = new SQL.Database();
  }

  initTables(dbInstance);
  saveDb();
  return dbInstance;
}

export function saveDb() {
  if (!dbInstance) return;
  try {
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    const dbPath = getDbFilePath();
    const dbDir = path.dirname(dbPath);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }
    fs.writeFileSync(dbPath, buffer);
  } catch (err) {
    console.error('Failed to write SQLite DB file:', err);
  }
}

export const DEFAULT_SHOP_SETTINGS: ShopSettings = {
  hotspotSsid: 'AQ-DIGITAL',
  hotspotPassword: '12345678',
  customerHostname: 'aqdigital',
  serverPort: 3000,
  preferredAdapter: 'Wi-Fi',
  maxFileSizeMb: 100,
  maxFilesPerJob: 20,
  maxTotalJobSizeMb: 500,
  allowedExtensions: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv', 'jpg', 'jpeg', 'png', 'webp', 'bmp', 'tiff', 'zip'],
  allowedReturnExtensions: ['pdf', 'jpg', 'jpeg', 'png', 'webp'],
  requireDefenderScan: true,
  blockDangerousTypes: true,
  allowEmergencyBypass: false,
  firewallProtection: true,
  incompleteRetention: '24h',
  rejectedRetention: '24h',
  completedRetention: '7d',
  finalDocRetention: '7d',
  storagePath: '',
  storageWarningPercent: 80,
  storageCriticalPercent: 90,
  operatorPinEnabled: false,
  startWithWindows: false,
  receivingPaused: false,
  autoRejectMinutes: 0, // 0 = disabled (jobs remain until accepted or dismissed)
};

function initTables(db: Database) {
  db.run(`
    CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY,
      public_job_id TEXT UNIQUE NOT NULL,
      secure_token TEXT UNIQUE NOT NULL,
      status TEXT NOT NULL,
      file_count INTEGER DEFAULT 0,
      total_size INTEGER DEFAULT 0,
      customer_name TEXT,
      notes TEXT,
      rejection_reason TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      accepted_at TEXT,
      completed_at TEXT,
      terminated_at TEXT,
      published_at TEXT
    );

    CREATE TABLE IF NOT EXISTS files (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      original_filename TEXT NOT NULL,
      safe_filename TEXT NOT NULL,
      extension TEXT NOT NULL,
      size INTEGER DEFAULT 0,
      mime_type TEXT,
      signature_type TEXT,
      storage_state TEXT NOT NULL,
      scan_status TEXT NOT NULL,
      threat_name TEXT,
      scan_timestamp TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (job_id) REFERENCES jobs(id)
    );

    CREATE TABLE IF NOT EXISTS final_documents (
      id TEXT PRIMARY KEY,
      job_id TEXT UNIQUE NOT NULL,
      original_source TEXT NOT NULL,
      generated_filename TEXT NOT NULL,
      file_size INTEGER DEFAULT 0,
      secure_document_token TEXT UNIQUE NOT NULL,
      created_at TEXT NOT NULL,
      published_at TEXT NOT NULL,
      FOREIGN KEY (job_id) REFERENCES jobs(id)
    );

    CREATE TABLE IF NOT EXISTS charges (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      description TEXT NOT NULL,
      amount REAL NOT NULL,
      FOREIGN KEY (job_id) REFERENCES jobs(id)
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      timestamp TEXT NOT NULL,
      level TEXT NOT NULL,
      category TEXT NOT NULL,
      message TEXT NOT NULL,
      details TEXT
    );
  `);

  // Seed default settings if not already present
  const res = db.exec("SELECT COUNT(*) FROM settings WHERE key = 'shop_config'");
  if (!res.length || !res[0].values.length || res[0].values[0][0] === 0) {
    db.run("INSERT INTO settings (key, value) VALUES ('shop_config', ?)", [JSON.stringify(DEFAULT_SHOP_SETTINGS)]);
  }
}

// Data Access Methods
export async function getShopSettings(): Promise<ShopSettings> {
  const db = await getDb();
  const stmt = db.prepare("SELECT value FROM settings WHERE key = 'shop_config'");
  if (stmt.step()) {
    const row = stmt.getAsObject();
    stmt.free();
    const parsed = JSON.parse(row.value as string);
    // Ensure default return extensions if missing from older DB
    if (!parsed.allowedReturnExtensions) {
      parsed.allowedReturnExtensions = DEFAULT_SHOP_SETTINGS.allowedReturnExtensions;
    }
    return parsed;
  }
  stmt.free();
  throw new Error('Settings not initialized');
}

export async function resetShopSettings(): Promise<ShopSettings> {
  const db = await getDb();
  db.run("INSERT OR REPLACE INTO settings (key, value) VALUES ('shop_config', ?)", [JSON.stringify(DEFAULT_SHOP_SETTINGS)]);
  saveDb();
  return DEFAULT_SHOP_SETTINGS;
}

export async function saveShopSettings(settings: Partial<ShopSettings>): Promise<ShopSettings> {
  const current = await getShopSettings();
  const updated = { ...current, ...settings };
  const db = await getDb();
  db.run("INSERT OR REPLACE INTO settings (key, value) VALUES ('shop_config', ?)", [JSON.stringify(updated)]);
  saveDb();
  return updated;
}

export async function createJob(job: Partial<Job>): Promise<Job> {
  const db = await getDb();
  const id = job.id || 'job_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const now = new Date().toISOString();
  
  // Format public job ID: AQD-YYYYMMDD-XXXX
  const todayStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const countStmt = db.prepare("SELECT COUNT(*) as c FROM jobs WHERE created_at LIKE ?");
  countStmt.bind([`${new Date().toISOString().slice(0, 10)}%`]);
  let seq = 1;
  if (countStmt.step()) {
    seq = (Number(countStmt.getAsObject().c) || 0) + 1;
  }
  countStmt.free();
  const seqStr = String(seq).padStart(4, '0');
  const publicJobId = job.public_job_id || `AQD-${todayStr}-${seqStr}`;
  const secureToken = job.secure_token || 'tok_' + Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2);

  db.run(`
    INSERT INTO jobs (id, public_job_id, secure_token, status, file_count, total_size, customer_name, notes, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    id,
    publicJobId,
    secureToken,
    job.status || 'NEW',
    job.file_count || 0,
    job.total_size || 0,
    job.customer_name || null,
    job.notes || null,
    now,
    now
  ]);

  saveDb();
  return (await getJobById(id))!;
}

export async function getJobById(id: string): Promise<Job | null> {
  const db = await getDb();
  const stmt = db.prepare("SELECT * FROM jobs WHERE id = ?");
  stmt.bind([id]);
  if (!stmt.step()) {
    stmt.free();
    return null;
  }
  const row = stmt.getAsObject() as unknown as Job;
  stmt.free();
  return hydrateJobDetails(db, row);
}

export async function getJobByToken(token: string): Promise<Job | null> {
  const db = await getDb();
  const stmt = db.prepare("SELECT * FROM jobs WHERE secure_token = ?");
  stmt.bind([token]);
  if (!stmt.step()) {
    stmt.free();
    return null;
  }
  const row = stmt.getAsObject() as unknown as Job;
  stmt.free();
  return hydrateJobDetails(db, row);
}

export async function getJobByPublicId(publicId: string): Promise<Job | null> {
  const db = await getDb();
  const stmt = db.prepare("SELECT * FROM jobs WHERE public_job_id = ?");
  stmt.bind([publicId]);
  if (!stmt.step()) {
    stmt.free();
    return null;
  }
  const row = stmt.getAsObject() as unknown as Job;
  stmt.free();
  return hydrateJobDetails(db, row);
}

function hydrateJobDetails(db: Database, job: Job): Job {
  const jobDir = path.join(DIRS.jobs, job.public_job_id);
  job.storage_dir = jobDir;

  if (job.status === 'WAITING_ACCEPTANCE') {
    const elapsed = Date.now() - new Date(job.updated_at).getTime();
    job.time_remaining_seconds = Math.max(0, Math.ceil((60000 - elapsed) / 1000));
  } else {
    job.time_remaining_seconds = null;
  }

  // Files
  const fileStmt = db.prepare("SELECT * FROM files WHERE job_id = ? ORDER BY created_at ASC");
  fileStmt.bind([job.id]);
  const files: JobFile[] = [];
  while (fileStmt.step()) {
    const fileObj = fileStmt.getAsObject() as unknown as JobFile;
    if (fileObj.storage_state === 'CLEAN') {
      fileObj.storage_path = path.join(jobDir, fileObj.safe_filename);
    } else if (fileObj.storage_state === 'QUARANTINE') {
      fileObj.storage_path = path.join(DIRS.quarantine, fileObj.safe_filename);
    } else if (fileObj.storage_state === 'REJECTED') {
      fileObj.storage_path = path.join(DIRS.rejected, fileObj.safe_filename);
    } else {
      fileObj.storage_path = path.join(DIRS.incoming, fileObj.safe_filename);
    }
    files.push(fileObj);
  }
  fileStmt.free();
  job.files = files;

  // Final document - search by both internal job.id and public_job_id, latest first
  const docStmt = db.prepare("SELECT * FROM final_documents WHERE job_id = ? OR job_id = ? ORDER BY created_at DESC LIMIT 1");
  docStmt.bind([job.id, job.public_job_id]);
  if (docStmt.step()) {
    job.final_document = docStmt.getAsObject() as unknown as FinalDocument;
  }
  docStmt.free();

  // If status is PUBLISHED but no final_document in DB yet, check DIRS.finalDocs as reliable fallback
  if (!job.final_document && job.status === 'PUBLISHED') {
    try {
      const safePublic = job.public_job_id.replace(/[^a-zA-Z0-9_-]/g, '_');
      if (fs.existsSync(DIRS.finalDocs)) {
        const match = fs.readdirSync(DIRS.finalDocs).find((f) => f.startsWith(safePublic));
        if (match) {
          const stat = fs.statSync(path.join(DIRS.finalDocs, match));
          const fallbackToken = 'dtok_' + safePublic;
          job.final_document = {
            id: 'doc_' + safePublic,
            job_id: job.id,
            original_source: 'PORTAL_AUTO',
            generated_filename: match,
            file_size: stat.size,
            secure_document_token: fallbackToken,
            created_at: job.published_at || job.updated_at || new Date().toISOString(),
            published_at: job.published_at || job.updated_at || new Date().toISOString(),
          };
        }
      }
    } catch {
      // ignore fallback error
    }
  }

  // Charges
  const chargeStmt = db.prepare("SELECT * FROM charges WHERE job_id = ?");
  chargeStmt.bind([job.id]);
  const charges: ChargeItem[] = [];
  while (chargeStmt.step()) {
    charges.push(chargeStmt.getAsObject() as unknown as ChargeItem);
  }
  chargeStmt.free();
  job.charges = charges;

  return job;
}

export async function getAllJobs(filterDate?: string, search?: string): Promise<Job[]> {
  const db = await getDb();
  let query = "SELECT * FROM jobs WHERE 1=1";
  const params: (string | number)[] = [];

  if (filterDate) {
    query += " AND created_at LIKE ?";
    params.push(`${filterDate}%`);
  }
  if (search) {
    query += " AND (public_job_id LIKE ? OR notes LIKE ? OR customer_name LIKE ?)";
    const s = `%${search}%`;
    params.push(s, s, s);
  }

  query += " ORDER BY created_at DESC";
  const stmt = db.prepare(query);
  if (params.length) {
    stmt.bind(params);
  }

  const jobs: Job[] = [];
  while (stmt.step()) {
    const row = stmt.getAsObject() as unknown as Job;
    jobs.push(row);
  }
  stmt.free();

  // Hydrate each
  return jobs.map((j) => hydrateJobDetails(db, j));
}

export async function updateJobStatus(id: string, status: Job['status'], additionalFields: Partial<Job> = {}): Promise<Job> {
  const db = await getDb();
  const now = new Date().toISOString();
  
  let updates = ["status = ?", "updated_at = ?"];
  const params: (string | number | null)[] = [status, now];

  if (status === 'ACCEPTED') {
    updates.push("accepted_at = ?");
    params.push(now);
  } else if (status === 'COMPLETED') {
    updates.push("completed_at = ?");
    params.push(now);
  } else if (status === 'TERMINATED') {
    updates.push("terminated_at = ?");
    params.push(now);
  } else if (status === 'PUBLISHED') {
    updates.push("published_at = ?");
    params.push(now);
  }

  if (additionalFields.rejection_reason !== undefined) {
    updates.push("rejection_reason = ?");
    params.push(additionalFields.rejection_reason);
  }
  if (additionalFields.notes !== undefined) {
    updates.push("notes = ?");
    params.push(additionalFields.notes);
  }
  if (additionalFields.file_count !== undefined) {
    updates.push("file_count = ?");
    params.push(additionalFields.file_count);
  }
  if (additionalFields.total_size !== undefined) {
    updates.push("total_size = ?");
    params.push(additionalFields.total_size);
  }

  params.push(id);
  db.run(`UPDATE jobs SET ${updates.join(', ')} WHERE id = ?`, params);
  saveDb();
  return (await getJobById(id))!;
}

export async function addJobFile(file: Partial<JobFile>): Promise<JobFile> {
  const db = await getDb();
  const id = file.id || 'file_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const now = new Date().toISOString();

  db.run(`
    INSERT INTO files (
      id, job_id, original_filename, safe_filename, extension, size,
      mime_type, signature_type, storage_state, scan_status, threat_name, scan_timestamp, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    id,
    file.job_id || '',
    file.original_filename || '',
    file.safe_filename || '',
    file.extension || '',
    file.size || 0,
    file.mime_type || 'application/octet-stream',
    file.signature_type || 'UNKNOWN',
    file.storage_state || 'INCOMING',
    file.scan_status || 'WAITING_FOR_SCAN',
    file.threat_name || null,
    file.scan_timestamp || null,
    now
  ]);

  // Update job file count and total size
  const jobId = file.job_id || '';
  db.run(`
    UPDATE jobs SET 
      file_count = (SELECT COUNT(*) FROM files WHERE job_id = ?),
      total_size = (SELECT COALESCE(SUM(size), 0) FROM files WHERE job_id = ?),
      updated_at = ?
    WHERE id = ?
  `, [jobId, jobId, now, jobId]);

  saveDb();
  const res = db.exec("SELECT * FROM files WHERE id = '" + id + "'");
  return res[0].values[0] as unknown as JobFile;
}

export async function updateFileScanStatus(
  fileId: string,
  scanStatus: JobFile['scan_status'],
  storageState: JobFile['storage_state'],
  threatName?: string
) {
  const db = await getDb();
  const now = new Date().toISOString();
  db.run(`
    UPDATE files SET 
      scan_status = ?,
      storage_state = ?,
      threat_name = ?,
      scan_timestamp = ?
    WHERE id = ?
  `, [scanStatus, storageState, threatName || null, now, fileId]);
  saveDb();
}

export async function saveFinalDocument(doc: Partial<FinalDocument>): Promise<FinalDocument> {
  const db = await getDb();
  const id = doc.id || 'doc_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const now = new Date().toISOString();
  const token = doc.secure_document_token || 'dtok_' + Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2);

  // Clean out any existing document record for this job to avoid conflicts
  if (doc.job_id) {
    db.run(`DELETE FROM final_documents WHERE job_id = ?`, [doc.job_id]);
  }

  db.run(`
    INSERT INTO final_documents (id, job_id, original_source, generated_filename, file_size, secure_document_token, created_at, published_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    id,
    doc.job_id || '',
    doc.original_source || '',
    doc.generated_filename || '',
    doc.file_size || 0,
    token,
    now,
    now
  ]);

  saveDb();
  return {
    id,
    job_id: doc.job_id!,
    original_source: doc.original_source!,
    generated_filename: doc.generated_filename!,
    file_size: doc.file_size || 0,
    secure_document_token: token,
    created_at: now,
    published_at: now
  };
}

export async function clearCompletedJobHistory(): Promise<{ deletedCount: number; deletedJobIds: string[] }> {
  const db = await getDb();
  // Find all finished / completed / rejected / terminated jobs
  const completedStatuses = ['COMPLETED', 'PUBLISHED', 'REJECTED', 'TERMINATED'];
  const placeholders = completedStatuses.map(() => '?').join(',');
  const stmt = db.prepare(`SELECT id, public_job_id FROM jobs WHERE status IN (${placeholders})`);
  stmt.bind(completedStatuses);

  const jobsToDelete: { id: string; public_job_id: string }[] = [];
  while (stmt.step()) {
    jobsToDelete.push(stmt.getAsObject() as { id: string; public_job_id: string });
  }
  stmt.free();

  if (jobsToDelete.length === 0) {
    return { deletedCount: 0, deletedJobIds: [] };
  }

  const ids = jobsToDelete.map((j) => j.id);
  const idPlaceholders = ids.map(() => '?').join(',');

  // Delete associated records from child tables
  db.run(`DELETE FROM final_documents WHERE job_id IN (${idPlaceholders})`, ids);
  db.run(`DELETE FROM charges WHERE job_id IN (${idPlaceholders})`, ids);
  db.run(`DELETE FROM files WHERE job_id IN (${idPlaceholders})`, ids);
  db.run(`DELETE FROM jobs WHERE id IN (${idPlaceholders})`, ids);
  saveDb();

  // Clean up completed disk files while leaving active jobs untouched
  for (const j of jobsToDelete) {
    try {
      const jobDir = path.join(DIRS.jobs, j.public_job_id);
      if (fs.existsSync(jobDir)) {
        fs.rmSync(jobDir, { recursive: true, force: true });
      }
      const safePublic = j.public_job_id.replace(/[^a-zA-Z0-9_-]/g, '_');
      if (fs.existsSync(DIRS.finalDocs)) {
        const docFiles = fs.readdirSync(DIRS.finalDocs).filter((f) => f.startsWith(safePublic));
        for (const df of docFiles) {
          try {
            fs.unlinkSync(path.join(DIRS.finalDocs, df));
          } catch {
            // ignore
          }
        }
      }
    } catch {
      // ignore individual folder deletion errors
    }
  }

  return {
    deletedCount: jobsToDelete.length,
    deletedJobIds: jobsToDelete.map((j) => j.public_job_id),
  };
}

export async function getFinalDocumentByToken(token: string): Promise<FinalDocument | null> {
  const db = await getDb();
  const stmt = db.prepare("SELECT * FROM final_documents WHERE secure_document_token = ?");
  stmt.bind([token]);
  if (!stmt.step()) {
    stmt.free();
    return null;
  }
  const row = stmt.getAsObject() as unknown as FinalDocument;
  stmt.free();
  return row;
}

export async function saveJobCharges(jobId: string, charges: { description: string; amount: number }[]) {
  const db = await getDb();
  db.run("DELETE FROM charges WHERE job_id = ?", [jobId]);
  for (const c of charges) {
    const id = 'chg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    db.run("INSERT INTO charges (id, job_id, description, amount) VALUES (?, ?, ?, ?)", [id, jobId, c.description, c.amount]);
  }
  saveDb();
}

export async function addAuditLog(level: AuditLog['level'], category: string, message: string, details?: string) {
  try {
    const db = await getDb();
    const id = 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const now = new Date().toISOString();
    db.run(
      "INSERT INTO audit_logs (id, timestamp, level, category, message, details) VALUES (?, ?, ?, ?, ?, ?)",
      [id, now, level, category, message, details || null]
    );
    saveDb();
  } catch (err) {
    console.error('Failed to log audit event:', err);
  }
}

export async function getAuditLogs(limit = 100): Promise<AuditLog[]> {
  const db = await getDb();
  const stmt = db.prepare("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT ?");
  stmt.bind([limit]);
  const logs: AuditLog[] = [];
  while (stmt.step()) {
    logs.push(stmt.getAsObject() as unknown as AuditLog);
  }
  stmt.free();
  return logs;
}
