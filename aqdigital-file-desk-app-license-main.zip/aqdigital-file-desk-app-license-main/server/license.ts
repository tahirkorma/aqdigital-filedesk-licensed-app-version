import fs from 'fs';
import path from 'path';
import os from 'os';
import crypto from 'crypto';
import { execSync } from 'child_process';
import { PERSISTENT_CONFIG_DIR } from './storage';
import { requestTrialFromServer, LICENSING_WORKER_URL } from './trial';
import { LicenseInfo, LicenseStatus } from '../src/types';

const VALIDATION_INTERVAL_MS = 24 * 60 * 60 * 1000; // 24 hours
const OFFLINE_GRACE_PERIOD_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

interface StoredLicenseData {
  deviceId: string;
  customerEmail?: string;
  licenseKey?: string;
  licenseType?: string;
  status: LicenseStatus;
  isTrial: boolean;
  trialDays?: number;
  trialStartAt?: string;
  trialExpiresAt?: string;
  expiresAt?: string;
  lastValidatedAt?: string;
  offlineGraceUntil?: string;
  lastError?: string;
}

/**
 * Returns the configurable support/sales contact email for customer inquiries.
 */
export function getLicensingSupportEmail(): string {
  return process.env.LICENSE_CONTACT_EMAIL || process.env.SUPPORT_EMAIL || 'support.aqdigitalsolutions@gmail.com';
}

let cachedDeviceId: string | null = null;

/**
 * Returns the path to the stored license data file.
 */
function getLicenseFilePath(): string {
  return path.join(PERSISTENT_CONFIG_DIR, 'license.json');
}

/**
 * Returns secondary persistent path for device ID on Windows (survives app reinstallation).
 */
function getWindowsProgramDataDeviceIdPath(): string | null {
  if (process.platform !== 'win32') return null;
  const programData = process.env.PROGRAMDATA || 'C:\\ProgramData';
  return path.join(programData, 'AQ-DIGITAL', 'device_id.txt');
}

/**
 * Deterministically calculates the machine-bound hardware Device ID.
 * On Windows: Uses MachineGuid from HKLM Cryptography + stable network MAC addresses + CPU model/arch.
 * On Linux: Uses /etc/machine-id or dbus machine-id + MAC addresses + CPU model/arch.
 * Formats a deterministic SHA-256 hash as AQD-XXXX-XXXX-XXXX-XXXX.
 * This calculated ID is the sole authority for device identity.
 */
export function calculateMachineDeviceId(): string {
  let hardwareSignature = '';

  // Network MAC addresses (sorted, excluding loopback and virtual zero addresses)
  try {
    const interfaces = os.networkInterfaces();
    const macs: string[] = [];
    for (const name of Object.keys(interfaces)) {
      const ifaceList = interfaces[name];
      if (ifaceList) {
        for (const iface of ifaceList) {
          if (!iface.internal && iface.mac && iface.mac !== '00:00:00:00:00:00') {
            macs.push(iface.mac.toLowerCase());
          }
        }
      }
    }
    macs.sort();
    hardwareSignature += macs.join('|');
  } catch {}

  // OS & CPU details
  hardwareSignature += `|${os.platform()}|${os.arch()}|${os.cpus()[0]?.model || ''}`;

  // Platform-specific stable machine GUID
  if (process.platform === 'win32') {
    try {
      const regOut = execSync(
        'reg query "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid',
        { encoding: 'utf8', timeout: 2000, stdio: ['ignore', 'pipe', 'ignore'] }
      );
      const match = regOut.match(/MachineGuid\s+REG_SZ\s+([a-fA-F0-9-]+)/i);
      if (match && match[1]) {
        hardwareSignature += `|win_guid:${match[1].trim()}`;
      } else {
        hardwareSignature += `|win_host:${os.hostname()}`;
      }
    } catch {
      hardwareSignature += `|win_host:${os.hostname()}`;
    }
  } else if (process.platform === 'linux') {
    try {
      if (fs.existsSync('/etc/machine-id')) {
        hardwareSignature += `|lin_mid:${fs.readFileSync('/etc/machine-id', 'utf8').trim()}`;
      } else if (fs.existsSync('/var/lib/dbus/machine-id')) {
        hardwareSignature += `|dbus_mid:${fs.readFileSync('/var/lib/dbus/machine-id', 'utf8').trim()}`;
      } else {
        hardwareSignature += `|lin_host:${os.hostname()}`;
      }
    } catch {
      hardwareSignature += `|lin_host:${os.hostname()}`;
    }
  } else {
    hardwareSignature += `|host:${os.hostname()}`;
  }

  // Generate SHA-256 hash and format as AQD-XXXX-XXXX-XXXX-XXXX
  const hash = crypto.createHash('sha256').update(hardwareSignature).digest('hex').toUpperCase();
  return `AQD-${hash.slice(0, 4)}-${hash.slice(4, 8)}-${hash.slice(8, 12)}-${hash.slice(12, 16)}`;
}

/**
 * Obtains the authoritative machine Device ID.
 * The deterministically calculated machine Device ID is the SOLE authority.
 * Any stored device_id.txt file is validated against the calculated ID:
 * if missing or mismatched (e.g. if tampered with), it is ignored and replaced with the authoritative ID.
 */
export function getDeviceId(): string {
  // 1. Authoritative deterministic machine identity calculation
  const authoritativeId = calculateMachineDeviceId();

  // 2. Validate and sync local persistent config cache
  const localIdPath = path.join(PERSISTENT_CONFIG_DIR, 'device_id.txt');
  try {
    let needsWrite = true;
    if (fs.existsSync(localIdPath)) {
      const stored = fs.readFileSync(localIdPath, 'utf8').trim();
      if (stored === authoritativeId) {
        needsWrite = false;
      }
    }
    if (needsWrite) {
      if (!fs.existsSync(PERSISTENT_CONFIG_DIR)) {
        fs.mkdirSync(PERSISTENT_CONFIG_DIR, { recursive: true });
      }
      fs.writeFileSync(localIdPath, authoritativeId, 'utf8');
    }
  } catch (err) {
    console.error('Could not sync authoritative device_id to local config:', err);
  }

  // 3. Validate and sync Windows ProgramData cache (if on Windows)
  const progDataIdPath = getWindowsProgramDataDeviceIdPath();
  if (progDataIdPath) {
    try {
      let needsWrite = true;
      if (fs.existsSync(progDataIdPath)) {
        const stored = fs.readFileSync(progDataIdPath, 'utf8').trim();
        if (stored === authoritativeId) {
          needsWrite = false;
        }
      }
      if (needsWrite) {
        const progDataDir = path.dirname(progDataIdPath);
        if (!fs.existsSync(progDataDir)) {
          fs.mkdirSync(progDataDir, { recursive: true });
        }
        fs.writeFileSync(progDataIdPath, authoritativeId, 'utf8');
      }
    } catch {}
  }

  cachedDeviceId = authoritativeId;
  return authoritativeId;
}

/**
 * Loads stored license data from disk.
 * Always ensures the deviceId corresponds to the authoritative calculated machine identity.
 */
function loadStoredLicense(): StoredLicenseData {
  const filePath = getLicenseFilePath();
  const deviceId = getDeviceId();

  if (fs.existsSync(filePath)) {
    try {
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      data.deviceId = deviceId;
      return {
        ...data,
        deviceId,
      };
    } catch {
      // corrupt or invalid JSON
    }
  }

  return {
    deviceId,
    status: 'unverified_offline',
    isTrial: true,
  };
}

/**
 * Saves license data to disk.
 */
function saveStoredLicense(data: StoredLicenseData) {
  try {
    const filePath = getLicenseFilePath();
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to save license data:', err);
  }
}

/**
 * Contacts Cloudflare licensing worker to validate a paid license key.
 */
async function validateLicenseWithServer(
  licenseKey: string,
  deviceId: string,
  timeoutMs: number = 8000
): Promise<{ success: boolean; valid?: boolean; license_type?: string; expires_at?: string; error?: string }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(LICENSING_WORKER_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({
        action: 'validate',
        license_key: licenseKey,
        device_id: deviceId,
      }),
      signal: controller.signal,
    });
    clearTimeout(timer);

    if (!res.ok) {
      const text = await res.text().catch(() => '');
      return { success: false, error: `Server error: HTTP ${res.status} ${text.slice(0, 80)}` };
    }

    const data = await res.json();
    return data;
  } catch (err: any) {
    clearTimeout(timer);
    const isAbort = err?.name === 'AbortError';
    return {
      success: false,
      error: isAbort ? 'Connection timed out' : (err?.message || 'Network unreachable'),
    };
  }
}

/**
 * Activates a paid license key with the Cloudflare Worker.
 */
export async function activateLicense(licenseKey: string): Promise<{ success: boolean; license: LicenseInfo; error?: string }> {
  const cleanKey = licenseKey.trim();
  if (!cleanKey) {
    return {
      success: false,
      license: await getLicenseStatus(),
      error: 'Please enter a valid license key.',
    };
  }

  const deviceId = getDeviceId();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);

  try {
    const res = await fetch(LICENSING_WORKER_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({
        action: 'activate',
        license_key: cleanKey,
        device_id: deviceId,
      }),
      signal: controller.signal,
    });
    clearTimeout(timer);

    const data = await res.json();

    if (data.success && data.valid) {
      const now = new Date().toISOString();
      const stored: StoredLicenseData = {
        deviceId,
        licenseKey: cleanKey,
        licenseType: data.license_type || 'paid',
        status: 'licensed',
        isTrial: false,
        expiresAt: data.expires_at || undefined,
        lastValidatedAt: now,
      };

      // Check if newly returned license is already expired
      if (stored.expiresAt) {
        const expTime = new Date(stored.expiresAt).getTime();
        if (!isNaN(expTime) && Date.now() >= expTime) {
          stored.status = 'expired';
          saveStoredLicense(stored);
          return {
            success: false,
            license: await getLicenseStatus(false),
            error: 'This license key has expired.',
          };
        }
      }

      saveStoredLicense(stored);

      return {
        success: true,
        license: await getLicenseStatus(false),
      };
    } else {
      return {
        success: false,
        license: await getLicenseStatus(false),
        error: data.error || 'License activation failed. Please check the key.',
      };
    }
  } catch (err: any) {
    clearTimeout(timer);
    const isAbort = err?.name === 'AbortError';
    const errorMsg = isAbort
      ? 'Activation timed out. Please check your internet connection.'
      : `Cannot reach licensing server: ${err?.message || 'Check network connection'}`;

    return {
      success: false,
      license: await getLicenseStatus(false),
      error: errorMsg,
    };
  }
}

/**
 * Returns the current license and trial status.
 * Handles:
 * - Deterministic machine identity binding
 * - 24-hour validation caching (does not contact server on every call)
 * - Strict expiration date enforcement (offline grace never extends expiration date)
 * - 7-day offline grace period for paid licenses that have not reached expiresAt
 * - Authoritative trial checks and offline trial enforcement up to trialExpiresAt
 */
export async function getLicenseStatus(forceOnline: boolean = false, customerEmailInput?: string): Promise<LicenseInfo> {
  const deviceId = getDeviceId();
  const stored = loadStoredLicense();
  const now = Date.now();
  const effectiveEmail = (customerEmailInput || stored.customerEmail || '').trim().toLowerCase() || undefined;

  // ==========================================
  // CASE 1: ACTIVATED PAID LICENSE
  // ==========================================
  if (stored.licenseKey && !stored.isTrial) {
    const lastValidatedTime = stored.lastValidatedAt ? new Date(stored.lastValidatedAt).getTime() : 0;
    const timeSinceValidation = now - lastValidatedTime;

    // 1. Strict expiration check:
    // If expiresAt exists and current local time is at or after expiresAt, return status "expired" and canAccessDesk: false
    if (stored.expiresAt) {
      const expTime = new Date(stored.expiresAt).getTime();
      if (!isNaN(expTime) && now >= expTime) {
        stored.status = 'expired';
        saveStoredLicense(stored);
        return {
          deviceId,
          isLicensed: false,
          isTrial: false,
          status: 'expired',
          canAccessDesk: false,
          needsEmailForTrial: false,
          customerEmail: stored.customerEmail,
          supportEmail: getLicensingSupportEmail(),
          licenseKey: stored.licenseKey,
          licenseType: stored.licenseType,
          expiresAt: stored.expiresAt,
          lastValidatedAt: stored.lastValidatedAt,
          daysRemaining: 0,
          error: 'Your license expired on ' + new Date(stored.expiresAt).toLocaleDateString() + '. Please renew your license key.',
        };
      }
    }

    // 2. Check if within 24-hour online validation interval and previously licensed
    if (!forceOnline && lastValidatedTime > 0 && timeSinceValidation < VALIDATION_INTERVAL_MS && stored.status === 'licensed') {
      let daysRemaining: number | undefined;
      if (stored.expiresAt) {
        const expTime = new Date(stored.expiresAt).getTime();
        if (!isNaN(expTime)) {
          if (now >= expTime) {
            stored.status = 'expired';
            saveStoredLicense(stored);
            return {
              deviceId,
              isLicensed: false,
              isTrial: false,
              status: 'expired',
              canAccessDesk: false,
              needsEmailForTrial: false,
              customerEmail: stored.customerEmail,
              supportEmail: getLicensingSupportEmail(),
              licenseKey: stored.licenseKey,
              licenseType: stored.licenseType,
              expiresAt: stored.expiresAt,
              lastValidatedAt: stored.lastValidatedAt,
              daysRemaining: 0,
              error: 'Your license has expired. Please renew your license key.',
            };
          }
          daysRemaining = Math.max(0, Math.ceil((expTime - now) / (24 * 60 * 60 * 1000)));
        }
      }

      return {
        deviceId,
        isLicensed: true,
        isTrial: false,
        status: 'licensed',
        canAccessDesk: true,
        needsEmailForTrial: false,
        customerEmail: stored.customerEmail,
        supportEmail: getLicensingSupportEmail(),
        licenseKey: stored.licenseKey,
        licenseType: stored.licenseType || 'paid',
        expiresAt: stored.expiresAt,
        lastValidatedAt: stored.lastValidatedAt,
        daysRemaining,
      };
    }

    // 3. Time to validate with server (or forceOnline was requested)
    const serverResult = await validateLicenseWithServer(stored.licenseKey, deviceId);

    if (serverResult.success && serverResult.valid) {
      // Server confirmed license is valid
      const validatedIso = new Date().toISOString();
      const updatedExpiresAt = serverResult.expires_at || stored.expiresAt;
      stored.status = 'licensed';
      stored.lastValidatedAt = validatedIso;
      stored.expiresAt = updatedExpiresAt;
      stored.licenseType = serverResult.license_type || stored.licenseType || 'paid';
      stored.lastError = undefined;

      // Check if license expiration date has been reached
      if (updatedExpiresAt) {
        const expTime = new Date(updatedExpiresAt).getTime();
        if (!isNaN(expTime) && now >= expTime) {
          stored.status = 'expired';
          saveStoredLicense(stored);
          return {
            deviceId,
            isLicensed: false,
            isTrial: false,
            status: 'expired',
            canAccessDesk: false,
            needsEmailForTrial: false,
            customerEmail: stored.customerEmail,
            supportEmail: getLicensingSupportEmail(),
            licenseKey: stored.licenseKey,
            licenseType: stored.licenseType,
            expiresAt: updatedExpiresAt,
            lastValidatedAt: validatedIso,
            daysRemaining: 0,
            error: 'Your license expired on ' + new Date(updatedExpiresAt).toLocaleDateString() + '. Please renew your license key.',
          };
        }
      }

      saveStoredLicense(stored);

      let daysRemaining: number | undefined;
      if (stored.expiresAt) {
        const expTime = new Date(stored.expiresAt).getTime();
        daysRemaining = Math.max(0, Math.ceil((expTime - now) / (24 * 60 * 60 * 1000)));
      }

      return {
        deviceId,
        isLicensed: true,
        isTrial: false,
        status: 'licensed',
        canAccessDesk: true,
        needsEmailForTrial: false,
        customerEmail: stored.customerEmail,
        supportEmail: getLicensingSupportEmail(),
        licenseKey: stored.licenseKey,
        licenseType: stored.licenseType,
        expiresAt: stored.expiresAt,
        lastValidatedAt: validatedIso,
        daysRemaining,
      };
    } else if (serverResult.success && serverResult.valid === false) {
      // Server explicitly rejected or reported license expired/disabled
      const errLower = (serverResult.error || '').toLowerCase();
      let newStatus: LicenseStatus = 'disabled';
      if (errLower.includes('expired')) {
        newStatus = 'expired';
      } else if (errLower.includes('disabled')) {
        newStatus = 'disabled';
      }

      stored.status = newStatus;
      stored.lastError = serverResult.error;
      saveStoredLicense(stored);

      return {
        deviceId,
        isLicensed: false,
        isTrial: false,
        status: newStatus,
        canAccessDesk: false,
        needsEmailForTrial: false,
        customerEmail: stored.customerEmail,
        supportEmail: getLicensingSupportEmail(),
        licenseKey: stored.licenseKey,
        licenseType: stored.licenseType,
        expiresAt: stored.expiresAt,
        lastValidatedAt: stored.lastValidatedAt,
        error: serverResult.error || 'License is invalid or has expired',
      };
    } else {
      // Server unreachable / network offline

      // Rule: Offline grace period must NOT extend the actual license expiration date.
      // If expiresAt exists and current local time is at or after expiresAt, return status "expired" and canAccessDesk: false.
      if (stored.expiresAt) {
        const expTime = new Date(stored.expiresAt).getTime();
        if (!isNaN(expTime) && now >= expTime) {
          stored.status = 'expired';
          saveStoredLicense(stored);
          return {
            deviceId,
            isLicensed: false,
            isTrial: false,
            status: 'expired',
            canAccessDesk: false,
            needsEmailForTrial: false,
            customerEmail: stored.customerEmail,
            supportEmail: getLicensingSupportEmail(),
            licenseKey: stored.licenseKey,
            licenseType: stored.licenseType,
            expiresAt: stored.expiresAt,
            lastValidatedAt: stored.lastValidatedAt,
            daysRemaining: 0,
            error: 'Your license has expired. Please connect to the internet to renew your license.',
          };
        }
      }

      // Rule: Only allow 7-day offline grace period when the license has not yet reached its stored expiration date.
      if (lastValidatedTime > 0 && timeSinceValidation <= OFFLINE_GRACE_PERIOD_MS) {
        let maxGraceMs = OFFLINE_GRACE_PERIOD_MS - timeSinceValidation;
        if (stored.expiresAt) {
          const expTime = new Date(stored.expiresAt).getTime();
          if (!isNaN(expTime)) {
            const timeUntilExpiry = expTime - now;
            // Cap grace period so it never exceeds license expiration date
            maxGraceMs = Math.min(maxGraceMs, timeUntilExpiry);
          }
        }

        const graceDaysLeft = Math.max(1, Math.ceil(maxGraceMs / (24 * 60 * 60 * 1000)));

        return {
          deviceId,
          isLicensed: true,
          isTrial: false,
          status: 'grace_period',
          canAccessDesk: true,
          needsEmailForTrial: false,
          customerEmail: stored.customerEmail,
          supportEmail: getLicensingSupportEmail(),
          licenseKey: stored.licenseKey,
          licenseType: stored.licenseType,
          expiresAt: stored.expiresAt,
          lastValidatedAt: stored.lastValidatedAt,
          graceDaysRemaining: graceDaysLeft,
          message: `Offline grace period active (${graceDaysLeft} day${graceDaysLeft === 1 ? '' : 's'} remaining). Connect to internet to validate.`,
        };
      } else {
        // Offline for more than 7 days
        return {
          deviceId,
          isLicensed: false,
          isTrial: false,
          status: 'unverified_offline',
          canAccessDesk: false,
          needsEmailForTrial: false,
          customerEmail: stored.customerEmail,
          supportEmail: getLicensingSupportEmail(),
          licenseKey: stored.licenseKey,
          licenseType: stored.licenseType,
          lastValidatedAt: stored.lastValidatedAt,
          error: 'License verification required: you have been offline for more than 7 days. Please connect to the internet to validate your license.',
        };
      }
    }
  }

  // ==========================================
  // CASE 2: TRIAL MODE
  // ==========================================
  const lastValidatedTime = stored.lastValidatedAt ? new Date(stored.lastValidatedAt).getTime() : 0;
  const timeSinceValidation = now - lastValidatedTime;

  // 1. If brand-new PC and trial has not been initiated with customer email:
  if (!stored.trialExpiresAt) {
    return {
      deviceId,
      isLicensed: false,
      isTrial: true,
      status: 'unverified_offline',
      canAccessDesk: false,
      needsEmailForTrial: true,
      customerEmail: stored.customerEmail,
      supportEmail: getLicensingSupportEmail(),
      error: 'Please enter your email address to start your free trial.',
    };
  }

  // 2. If local record indicates trial is already expired:
  if (stored.trialExpiresAt) {
    const expTime = new Date(stored.trialExpiresAt).getTime();
    if (!isNaN(expTime) && now >= expTime) {
      stored.status = 'trial_expired';
      saveStoredLicense(stored);
      return {
        deviceId,
        isLicensed: false,
        isTrial: true,
        status: 'trial_expired',
        canAccessDesk: false,
        needsEmailForTrial: false,
        customerEmail: stored.customerEmail,
        supportEmail: getLicensingSupportEmail(),
        trialDays: stored.trialDays || 14,
        trialStartAt: stored.trialStartAt,
        trialExpiresAt: stored.trialExpiresAt,
        daysRemaining: 0,
        error: 'Your trial has expired. Please enter a license key to continue using AQ DIGITAL FileDesk.',
      };
    }
  }

  // 3. If we already validated online recently (within 24 hours) and trial is active:
  if (!forceOnline && lastValidatedTime > 0 && timeSinceValidation < VALIDATION_INTERVAL_MS && stored.status === 'trial_active' && stored.trialExpiresAt) {
    const expTime = new Date(stored.trialExpiresAt).getTime();
    if (!isNaN(expTime)) {
      if (now >= expTime) {
        stored.status = 'trial_expired';
        saveStoredLicense(stored);
        return {
          deviceId,
          isLicensed: false,
          isTrial: true,
          status: 'trial_expired',
          canAccessDesk: false,
          needsEmailForTrial: false,
          customerEmail: stored.customerEmail,
          supportEmail: getLicensingSupportEmail(),
          trialDays: stored.trialDays || 14,
          trialStartAt: stored.trialStartAt,
          trialExpiresAt: stored.trialExpiresAt,
          daysRemaining: 0,
          error: 'Your trial has expired. Please enter a license key to continue using AQ DIGITAL FileDesk.',
        };
      }
      const daysLeft = Math.max(0, Math.ceil((expTime - now) / (24 * 60 * 60 * 1000)));
      if (daysLeft > 0) {
        return {
          deviceId,
          isLicensed: false,
          isTrial: true,
          status: 'trial_active',
          canAccessDesk: true,
          needsEmailForTrial: false,
          customerEmail: stored.customerEmail,
          supportEmail: getLicensingSupportEmail(),
          trialDays: stored.trialDays || 14,
          trialStartAt: stored.trialStartAt,
          trialExpiresAt: stored.trialExpiresAt,
          lastValidatedAt: stored.lastValidatedAt,
          daysRemaining: daysLeft,
        };
      }
    }
  }

  // 4. Contact Cloudflare Worker for authoritative trial check
  const trialResult = await requestTrialFromServer(deviceId, effectiveEmail);

  if (trialResult.success) {
    const validatedIso = new Date().toISOString();
    const isExpired = trialResult.trial_expired === true || trialResult.trial_active === false;

    stored.isTrial = true;
    stored.trialDays = trialResult.trial_days || stored.trialDays || 14;
    stored.trialStartAt = trialResult.trial_start_at || stored.trialStartAt;
    stored.trialExpiresAt = trialResult.trial_expires_at || stored.trialExpiresAt;
    if (trialResult.customer_email || effectiveEmail) {
      stored.customerEmail = trialResult.customer_email || effectiveEmail || stored.customerEmail;
    }
    stored.lastValidatedAt = validatedIso;
    stored.status = isExpired ? 'trial_expired' : 'trial_active';
    stored.lastError = undefined;

    let daysLeft = 0;
    if (stored.trialExpiresAt) {
      const expTime = new Date(stored.trialExpiresAt).getTime();
      if (!isNaN(expTime)) {
        if (now >= expTime) {
          stored.status = 'trial_expired';
        } else {
          daysLeft = Math.max(0, Math.ceil((expTime - now) / (24 * 60 * 60 * 1000)));
        }
      }
    }

    saveStoredLicense(stored);

    if (stored.status === 'trial_expired' || daysLeft <= 0) {
      return {
        deviceId,
        isLicensed: false,
        isTrial: true,
        status: 'trial_expired',
        canAccessDesk: false,
        needsEmailForTrial: false,
        customerEmail: stored.customerEmail,
        supportEmail: getLicensingSupportEmail(),
        trialDays: stored.trialDays,
        trialStartAt: stored.trialStartAt,
        trialExpiresAt: stored.trialExpiresAt,
        lastValidatedAt: validatedIso,
        daysRemaining: 0,
        error: 'Your trial has expired. Please enter a license key to continue using AQ DIGITAL FileDesk.',
      };
    }

    return {
      deviceId,
      isLicensed: false,
      isTrial: true,
      status: 'trial_active',
      canAccessDesk: true,
      needsEmailForTrial: false,
      customerEmail: stored.customerEmail,
      supportEmail: getLicensingSupportEmail(),
      trialDays: stored.trialDays,
      trialStartAt: stored.trialStartAt,
      trialExpiresAt: stored.trialExpiresAt,
      lastValidatedAt: validatedIso,
      daysRemaining: daysLeft,
    };
  } else {
    // 5. Worker could not be reached (offline)
    // For an already-established trial, offline operation may continue ONLY until the locally stored trial expiration date:
    if (stored.trialExpiresAt) {
      const expTime = new Date(stored.trialExpiresAt).getTime();
      if (!isNaN(expTime)) {
        const daysLeft = Math.max(0, Math.ceil((expTime - now) / (24 * 60 * 60 * 1000)));

        if (daysLeft > 0 && now < expTime) {
          return {
            deviceId,
            isLicensed: false,
            isTrial: true,
            status: 'trial_active',
            canAccessDesk: true,
            needsEmailForTrial: false,
            customerEmail: stored.customerEmail,
            supportEmail: getLicensingSupportEmail(),
            trialDays: stored.trialDays || 14,
            trialStartAt: stored.trialStartAt,
            trialExpiresAt: stored.trialExpiresAt,
            lastValidatedAt: stored.lastValidatedAt,
            daysRemaining: daysLeft,
            message: 'Trial running in offline mode.',
          };
        } else {
          stored.status = 'trial_expired';
          saveStoredLicense(stored);
          return {
            deviceId,
            isLicensed: false,
            isTrial: true,
            status: 'trial_expired',
            canAccessDesk: false,
            needsEmailForTrial: false,
            customerEmail: stored.customerEmail,
            supportEmail: getLicensingSupportEmail(),
            trialDays: stored.trialDays || 14,
            trialStartAt: stored.trialStartAt,
            trialExpiresAt: stored.trialExpiresAt,
            daysRemaining: 0,
            error: 'Your trial has expired. Please enter a license key to continue using AQ DIGITAL FileDesk.',
          };
        }
      }
    }

    // Brand-new install and offline: Cannot silently grant a trial without initial server handshake
    return {
      deviceId,
      isLicensed: false,
      isTrial: true,
      status: 'unverified_offline',
      canAccessDesk: false,
      needsEmailForTrial: true,
      supportEmail: getLicensingSupportEmail(),
      error: 'An internet connection is required to verify and activate your trial. Please connect to the internet and click Retry.',
    };
  }
}

/**
 * Initiates the 14-day evaluation trial with the customer's email address.
 * Requirements:
 * - Email is required and must be a valid email format.
 * - Device ID remains the sole technical identity.
 * - Customer email is sent together with Device ID to Cloudflare licensing Worker and saved to D1.
 * - If the same Device ID has already initiated a trial, the existing trial is preserved without resetting.
 */
export async function startTrialWithEmail(email: string): Promise<{ success: boolean; license: LicenseInfo; error?: string }> {
  const cleanEmail = (email || '').trim().toLowerCase();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!cleanEmail || !emailRegex.test(cleanEmail)) {
    return {
      success: false,
      license: await getLicenseStatus(false),
      error: 'Please enter a valid email address to start your free trial.',
    };
  }

  const deviceId = getDeviceId();
  const stored = loadStoredLicense();

  // If already paid licensed, keep license
  if (stored.licenseKey && !stored.isTrial && stored.status === 'licensed') {
    return {
      success: true,
      license: await getLicenseStatus(false),
    };
  }

  try {
    const trialResult = await requestTrialFromServer(deviceId, cleanEmail);

    if (trialResult.success) {
      const validatedIso = new Date().toISOString();
      const isExpired = trialResult.trial_expired === true || trialResult.trial_active === false;

      stored.isTrial = true;
      stored.customerEmail = cleanEmail;
      stored.trialDays = trialResult.trial_days || stored.trialDays || 14;
      stored.trialStartAt = trialResult.trial_start_at || stored.trialStartAt || validatedIso;
      stored.trialExpiresAt = trialResult.trial_expires_at || stored.trialExpiresAt;
      stored.lastValidatedAt = validatedIso;
      stored.status = isExpired ? 'trial_expired' : 'trial_active';
      stored.lastError = undefined;
      saveStoredLicense(stored);

      return {
        success: true,
        license: await getLicenseStatus(false),
      };
    } else {
      return {
        success: false,
        license: await getLicenseStatus(false),
        error: trialResult.error || 'Could not connect to the licensing server. Please check your internet connection and try again.',
      };
    }
  } catch (err: any) {
    return {
      success: false,
      license: await getLicenseStatus(false),
      error: 'Could not connect to the licensing server. Please check your internet connection and try again.',
    };
  }
}
