import os from 'os';
import { exec } from 'child_process';
import { promisify } from 'util';
import QRCode from 'qrcode';
import { NetworkStatus, StorageStatus } from '../src/types';
import { getShopSettings } from './db';
import { getStorageUsage } from './storage';

const execAsync = promisify(exec);

// In-memory cache for generated QR codes to eliminate redundant CPU re-renders on network polls
const qrCodeCache = new Map<string, string>();

async function getCachedQrCode(payload: string): Promise<string> {
  const cached = qrCodeCache.get(payload);
  if (cached) return cached;

  const dataUrl = await QRCode.toDataURL(payload, {
    width: 280,
    margin: 2,
    color: {
      dark: '#0f172a',
      light: '#ffffff'
    }
  });

  // Limit cache size to avoid unbounded memory
  if (qrCodeCache.size > 50) qrCodeCache.clear();
  qrCodeCache.set(payload, dataUrl);
  return dataUrl;
}

export function getReachableIp(): string {
  const interfaces = os.networkInterfaces();
  const candidates: string[] = [];

  for (const name of Object.keys(interfaces)) {
    for (const net of interfaces[name] || []) {
      if (net.family === 'IPv4' && !net.internal) {
        // Direct Windows Hotspot default IP check
        if (net.address === '192.168.137.1') {
          return '192.168.137.1';
        }
        // Exclude link-local APIPA (169.254.x.x) and loopback
        if (!net.address.startsWith('169.254.') && !net.address.startsWith('127.')) {
          // Prioritize standard local private subnets
          if (
            net.address.startsWith('192.168.') ||
            net.address.startsWith('10.') ||
            /^172\.(1[6-9]|2\d|3[0-1])\./.test(net.address)
          ) {
            candidates.unshift(net.address);
          } else {
            candidates.push(net.address);
          }
        }
      }
    }
  }

  if (candidates.length > 0) {
    return candidates[0];
  }

  if (process.platform === 'win32') {
    return '192.168.137.1';
  }

  return '127.0.0.1';
}

export async function getNetworkStatus(req?: any): Promise<NetworkStatus> {
  const settings = await getShopSettings();
  const isWindows = process.platform === 'win32';

  // Find best reachable non-internal IPv4 address
  const localIp = getReachableIp();

  let hotspotStatus: NetworkStatus['hotspotStatus'] = 'STOPPED';
  let internetSharingStatus: NetworkStatus['internetSharingStatus'] = 'OFF';
  let firewallStatus: NetworkStatus['firewallStatus'] = 'PROTECTED';
  let customerNetworkStatus: NetworkStatus['customerNetworkStatus'] = 'LOCAL ONLY';
  let defenderStatus: NetworkStatus['defenderStatus'] = 'ACTIVE';

  if (isWindows) {
    // 1. Check Hotspot / Hosted Network on Windows
    try {
      const { stdout } = await execAsync('netsh wlan show hostednetwork');
      if (stdout.includes('Status                 : Started') || stdout.includes('State                  : Started')) {
        hotspotStatus = 'RUNNING';
      } else {
        hotspotStatus = 'STOPPED';
      }
    } catch {
      hotspotStatus = 'UNAVAILABLE';
    }

    // 2. Check Internet Connection Sharing (ICS) state
    try {
      const { stdout } = await execAsync('reg query "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters" /v ScopeAddressBackup');
      // If SharedAccess is enabled/scoped, ICS might be active
      if (stdout.includes('ScopeAddressBackup')) {
        internetSharingStatus = 'ON';
        customerNetworkStatus = 'BRIDGED_WARNING';
      } else {
        internetSharingStatus = 'OFF';
        customerNetworkStatus = 'LOCAL ONLY';
      }
    } catch {
      internetSharingStatus = 'OFF';
      customerNetworkStatus = 'LOCAL ONLY';
    }

    // 3. Check Windows Firewall
    try {
      const { stdout } = await execAsync('netsh advfirewall firewall show rule name="AQ DIGITAL Local Server"');
      if (stdout.includes('Enabled:                              Yes')) {
        firewallStatus = 'PROTECTED';
      } else {
        firewallStatus = 'WARNING';
      }
    } catch {
      firewallStatus = 'WARNING';
    }

    // 4. Check Windows Defender
    try {
      const { stdout } = await execAsync('powershell -Command "Get-MpComputerStatus | Select-Object -ExpandProperty RealTimeProtectionEnabled"');
      if (stdout.trim().toLowerCase() === 'true') {
        defenderStatus = 'ACTIVE';
      } else {
        defenderStatus = 'UNAVAILABLE';
      }
    } catch {
      defenderStatus = 'UNAVAILABLE';
    }
  } else {
    // Non-Windows environment (e.g. Linux container development server)
    hotspotStatus = 'RUNNING';
    internetSharingStatus = 'OFF';
    firewallStatus = 'PROTECTED';
    customerNetworkStatus = 'LOCAL ONLY';
    defenderStatus = settings.allowEmergencyBypass ? 'ACTIVE' : 'HOLD_MODE';
  }

  // Determine accessible Customer URL
  let customerUrl = '';
  let fallbackUrl = '';

  const forwardedHost = req?.headers?.['x-forwarded-host'] as string | undefined;
  const hostHeader = (forwardedHost || req?.headers?.host || '').split(',')[0].trim();
  const forwardedProto = (req?.headers?.['x-forwarded-proto'] as string | undefined)?.split(',')[0].trim();
  const proto = forwardedProto || (req?.protocol === 'https' ? 'https' : 'http');

  const isWebEnvironment = hostHeader &&
    !hostHeader.startsWith('172.17.') &&
    !hostHeader.startsWith('127.0.0.1') &&
    !hostHeader.startsWith('localhost') &&
    !hostHeader.startsWith('192.168.');

  if (isWebEnvironment && !isWindows) {
    // Cloud preview, online deployment or external domain
    customerUrl = `${proto}://${hostHeader}/upload`;
    fallbackUrl = `${proto}://${hostHeader}/upload`;
  } else {
    // Standard Local Windows PC Hotspot deployment
    const portSuffix = settings.serverPort === 80 ? '' : `:${settings.serverPort}`;
    customerUrl = `http://${localIp}${portSuffix}/upload`;
    fallbackUrl = `http://${settings.customerHostname || 'aqdigital'}${portSuffix}/upload`;
  }

  // Wi-Fi QR Code string: standard MEBKM / Wi-Fi QR standard
  // WIFI:S:<SSID>;T:WPA;P:<PASSWORD>;;
  const wifiPayload = `WIFI:S:${settings.hotspotSsid};T:WPA;P:${settings.hotspotPassword};;`;
  const qrWifi = await getCachedQrCode(wifiPayload);

  // URL QR Code: direct customer URL (/upload) scannable by phone camera
  const qrUrl = await getCachedQrCode(customerUrl);

  const storage: StorageStatus = getStorageUsage(settings.storageWarningPercent, settings.storageCriticalPercent);

  return {
    hotspotStatus,
    hotspotSsid: settings.hotspotSsid,
    serverStatus: 'RUNNING',
    customerUrl,
    fallbackUrl,
    localIp,
    internetSharingStatus,
    firewallStatus,
    customerNetworkStatus,
    defenderStatus,
    qrWifi,
    qrUrl,
    storage
  };
}
