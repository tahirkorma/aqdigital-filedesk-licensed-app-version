import fs from 'fs';
import path from 'path';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { DIRS } from './storage';
import { ChargeItem } from '../src/types';

export interface PdfEditOptions {
  crop?: {
    top: number;
    bottom: number;
    left: number;
    right: number;
  };
  stampText?: string;
  stampPosition?: 'TOP' | 'BOTTOM' | 'STAMP';
  customTexts?: Array<{
    text: string;
    x?: number;
    y?: number;
    size?: number;
    color?: string;
  }>;
  charges?: Array<{
    description: string;
    amount: number;
  }>;
  showChargesBox?: boolean;
}

/**
 * Sanitizes any string for pdf-lib's built-in WinAnsi standard font encoding.
 * Converts rupee signs, bullets, smart quotes, and dashes to safe representations
 * so drawText will never throw 'WinAnsi cannot encode'.
 */
export function sanitizeForPdf(text: string): string {
  if (!text) return '';
  return text
    .replace(/\u20B9/g, 'Rs. ') // ₹
    .replace(/[•●]/g, '-')
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2013\u2014]/g, '-')
    .replace(/[\u2026]/g, '...')
    .replace(/[^\x20-\x7E\xA0-\xFF]/g, ' ') // restrict to ASCII / Latin-1 printable
    .trim();
}

export async function processAndSaveFinalPdf(
  originalPdfPath: string,
  publicJobId: string,
  options?: PdfEditOptions
): Promise<{ finalFilePath: string; filename: string; size: number }> {
  if (!fs.existsSync(originalPdfPath)) {
    throw new Error('Original portal PDF not found at ' + originalPdfPath);
  }

  const originalBytes = fs.readFileSync(originalPdfPath);
  const ext = path.extname(originalPdfPath).toLowerCase();
  const isImage = ['.png', '.jpg', '.jpeg', '.webp', '.bmp'].includes(ext);

  let pdfDoc: PDFDocument;

  if (isImage) {
    // If the input was an image uploaded by the operator, embed it into a fresh PDF
    pdfDoc = await PDFDocument.create();
    let embeddedImage;
    if (ext === '.png') {
      embeddedImage = await pdfDoc.embedPng(originalBytes);
    } else {
      // JPEG or default fallback
      embeddedImage = await pdfDoc.embedJpg(originalBytes);
    }
    const page = pdfDoc.addPage([embeddedImage.width, embeddedImage.height]);
    page.drawImage(embeddedImage, {
      x: 0,
      y: 0,
      width: embeddedImage.width,
      height: embeddedImage.height,
    });
  } else {
    // Load existing PDF document
    pdfDoc = await PDFDocument.load(originalBytes, { ignoreEncryption: true });
  }

  const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  const pages = pdfDoc.getPages();
  if (pages.length === 0) {
    pdfDoc.addPage([595, 842]);
  }
  const targetPage = pages[0];

  const origBox = targetPage.getMediaBox() || { x: 0, y: 0, width: targetPage.getWidth() || 595, height: targetPage.getHeight() || 842 };
  const origWidth = origBox.width || targetPage.getWidth() || 595;
  const origHeight = origBox.height || targetPage.getHeight() || 842;
  const origX = origBox.x || 0;
  const origY = origBox.y || 0;

  const topCrop = Math.max(0, Number(options?.crop?.top) || 0);
  const bottomCrop = Math.max(0, Number(options?.crop?.bottom) || 0);
  const leftCrop = Math.max(0, Number(options?.crop?.left) || 0);
  const rightCrop = Math.max(0, Number(options?.crop?.right) || 0);
  const hasCrop = topCrop > 0 || bottomCrop > 0 || leftCrop > 0 || rightCrop > 0;

  // 1. Apply Crop Page Margins and Remove Unwanted Portal Bars across all pages
  for (const page of pages) {
    const box = page.getMediaBox() || { x: 0, y: 0, width: page.getWidth(), height: page.getHeight() };
    const pWidth = box.width || page.getWidth();
    const pHeight = box.height || page.getHeight();
    const pX = box.x || 0;
    const pY = box.y || 0;

    if (hasCrop) {
      // Blank out unwanted portal bars (headers, footers, URLs, watermark bars) with white masks
      if (topCrop > 0) {
        page.drawRectangle({
          x: pX,
          y: pY + pHeight - topCrop,
          width: pWidth,
          height: topCrop,
          color: rgb(1, 1, 1),
        });
      }
      if (bottomCrop > 0) {
        page.drawRectangle({
          x: pX,
          y: pY,
          width: pWidth,
          height: bottomCrop,
          color: rgb(1, 1, 1),
        });
      }
      if (leftCrop > 0) {
        page.drawRectangle({
          x: pX,
          y: pY,
          width: leftCrop,
          height: pHeight,
          color: rgb(1, 1, 1),
        });
      }
      if (rightCrop > 0) {
        page.drawRectangle({
          x: pX + pWidth - rightCrop,
          y: pY,
          width: rightCrop,
          height: pHeight,
          color: rgb(1, 1, 1),
        });
      }

      // Adjust both CropBox and MediaBox so all PDF viewers and printers respect the cropped boundaries
      const newCropW = Math.max(50, pWidth - leftCrop - rightCrop);
      const newCropH = Math.max(50, pHeight - topCrop - bottomCrop);
      page.setCropBox(pX + leftCrop, pY + bottomCrop, newCropW, newCropH);
      page.setMediaBox(pX + leftCrop, pY + bottomCrop, newCropW, newCropH);
    }
  }

  // Target first page for custom text and charges stamps - compute visible coordinates accurately
  const visibleX = origX + leftCrop;
  const visibleY = origY + bottomCrop;
  const visibleWidth = Math.max(50, origWidth - leftCrop - rightCrop);
  const visibleHeight = Math.max(50, origHeight - topCrop - bottomCrop);

  // 2. Additional Text / Shop Stamp
  const stampText =
    options?.stampText ||
    (options as any)?.additionalText ||
    (options?.customTexts && options.customTexts[0]?.text);
  const stampPosition = options?.stampPosition || 'BOTTOM';

  if (stampText && stampText.trim()) {
    const safeText = sanitizeForPdf(stampText);
    const fontSize = 10;
    const textWidth = helveticaBold.widthOfTextAtSize(safeText, fontSize);

    if (stampPosition === 'TOP') {
      // Header banner at top of visible cropped area
      const bannerHeight = 22;
      const bannerY = visibleY + visibleHeight - bannerHeight - 6;
      targetPage.drawRectangle({
        x: visibleX + 10,
        y: bannerY,
        width: visibleWidth - 20,
        height: bannerHeight,
        color: rgb(0.96, 0.97, 0.99),
        borderColor: rgb(0.75, 0.82, 0.9),
        borderWidth: 0.75,
      });
      targetPage.drawText(safeText, {
        x: visibleX + Math.max(15, (visibleWidth - textWidth) / 2),
        y: bannerY + 6,
        size: fontSize,
        font: helveticaBold,
        color: rgb(0.12, 0.23, 0.45),
      });
    } else if (stampPosition === 'STAMP') {
      // Centered official badge/stamp
      const badgeWidth = Math.min(visibleWidth - 30, textWidth + 30);
      const badgeHeight = 28;
      const badgeX = visibleX + Math.max(10, (visibleWidth - badgeWidth) / 2);
      const badgeY = visibleY + Math.max(10, (visibleHeight - badgeHeight) / 2);
      targetPage.drawRectangle({
        x: badgeX,
        y: badgeY,
        width: badgeWidth,
        height: badgeHeight,
        color: rgb(0.98, 0.99, 1),
        borderColor: rgb(0.15, 0.38, 0.85),
        borderWidth: 1.5,
      });
      targetPage.drawText(safeText, {
        x: badgeX + Math.max(8, (badgeWidth - textWidth) / 2),
        y: badgeY + 8,
        size: fontSize,
        font: helveticaBold,
        color: rgb(0.15, 0.38, 0.85),
      });
    } else {
      // Footer at bottom of visible cropped area
      const footerY = visibleY + 8;
      targetPage.drawText(safeText, {
        x: visibleX + 15,
        y: footerY,
        size: 9,
        font: helveticaFont,
        color: rgb(0.35, 0.4, 0.45),
      });
    }
  }

  // Any other custom texts if provided
  if (options?.customTexts && options.customTexts.length > 1) {
    for (let i = 1; i < options.customTexts.length; i++) {
      const item = options.customTexts[i];
      if (!item.text) continue;
      const safeText = sanitizeForPdf(item.text);
      const posX = item.x !== undefined ? Math.max(visibleX, Math.min(visibleX + visibleWidth - 50, item.x)) : visibleX + 20;
      const posY = item.y !== undefined ? Math.max(visibleY, Math.min(visibleY + visibleHeight - 20, item.y)) : visibleY + 30;
      targetPage.drawText(safeText, {
        x: posX,
        y: posY,
        size: item.size || 10,
        font: helveticaFont,
        color: rgb(0.1, 0.1, 0.1),
      });
    }
  }

  // 3. Itemized Additional Charges Box Stamped onto Document
  const validCharges = (options?.charges || []).filter(
    (c) => c && c.description && c.description.trim() && !isNaN(Number(c.amount))
  );

  if (options?.showChargesBox && validCharges.length > 0) {
    const boxWidth = Math.min(230, visibleWidth - 30);
    const rowHeight = 15;
    const headerHeight = 22;
    const totalRowHeight = 20;
    const boxHeight = headerHeight + validCharges.length * rowHeight + totalRowHeight + 8;

    // Position box inside visible cropped area at bottom-right
    const boxX = visibleX + visibleWidth - boxWidth - 12;
    const boxY = visibleY + 12;

    // Background rectangle
    targetPage.drawRectangle({
      x: boxX,
      y: boxY,
      width: boxWidth,
      height: boxHeight,
      color: rgb(0.98, 0.99, 1.0),
      borderColor: rgb(0.2, 0.35, 0.5),
      borderWidth: 1,
    });

    // Header
    targetPage.drawText('AQ DIGITAL CHARGES', {
      x: boxX + 10,
      y: boxY + boxHeight - 16,
      size: 9.5,
      font: helveticaBold,
      color: rgb(0.08, 0.15, 0.28),
    });

    let currentY = boxY + boxHeight - 32;
    let total = 0;

    for (const charge of validCharges) {
      const desc = sanitizeForPdf(charge.description).substring(0, 24);
      targetPage.drawText(desc, {
        x: boxX + 10,
        y: currentY,
        size: 8.5,
        font: helveticaFont,
        color: rgb(0.22, 0.28, 0.35),
      });

      const amountStr = `Rs. ${Number(charge.amount).toFixed(2)}`;
      targetPage.drawText(amountStr, {
        x: boxX + boxWidth - 65,
        y: currentY,
        size: 8.5,
        font: helveticaFont,
        color: rgb(0.1, 0.1, 0.1),
      });

      total += Number(charge.amount);
      currentY -= rowHeight;
    }

    // Divider
    targetPage.drawLine({
      start: { x: boxX + 10, y: currentY + 3 },
      end: { x: boxX + boxWidth - 10, y: currentY + 3 },
      thickness: 0.75,
      color: rgb(0.75, 0.8, 0.85),
    });

    // Total Payable Row
    targetPage.drawText('TOTAL PAYABLE:', {
      x: boxX + 10,
      y: currentY - 10,
      size: 9.5,
      font: helveticaBold,
      color: rgb(0.08, 0.15, 0.28),
    });

    targetPage.drawText(`Rs. ${total.toFixed(2)}`, {
      x: boxX + boxWidth - 65,
      y: currentY - 10,
      size: 9.5,
      font: helveticaBold,
      color: rgb(0.05, 0.5, 0.25),
    });
  }

  // Save new PDF into FinalDocuments/
  const finalPdfBytes = await pdfDoc.save();
  const safeJobId = publicJobId.replace(/[^a-zA-Z0-9_-]/g, '_');
  const filename = `${safeJobId}_final.pdf`;
  if (!fs.existsSync(DIRS.finalDocs)) {
    fs.mkdirSync(DIRS.finalDocs, { recursive: true });
  }
  const finalFilePath = path.join(DIRS.finalDocs, filename);

  fs.writeFileSync(finalFilePath, finalPdfBytes);

  return {
    finalFilePath,
    filename,
    size: finalPdfBytes.byteLength,
  };
}

export async function saveDirectPortalPdf(
  originalPdfPath: string,
  publicJobId: string,
  originalFilename?: string
): Promise<{ finalFilePath: string; filename: string; size: number }> {
  if (!fs.existsSync(originalPdfPath)) {
    throw new Error('Original file does not exist at ' + originalPdfPath);
  }

  const ext = originalFilename
    ? path.extname(originalFilename).toLowerCase().replace('.', '') || 'pdf'
    : path.extname(originalPdfPath).toLowerCase().replace('.', '') || 'pdf';

  const safeJobId = publicJobId.replace(/[^a-zA-Z0-9_-]/g, '_');
  const filename = `${safeJobId}_final.${ext}`;
  if (!fs.existsSync(DIRS.finalDocs)) {
    fs.mkdirSync(DIRS.finalDocs, { recursive: true });
  }
  const finalFilePath = path.join(DIRS.finalDocs, filename);

  // Copy without modifying original
  fs.copyFileSync(originalPdfPath, finalFilePath);
  const stat = fs.statSync(finalFilePath);

  return {
    finalFilePath,
    filename,
    size: stat.size,
  };
}
