import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';
import { ScanStatus } from '../src/types';

const execAsync = promisify(exec);

// Dangerous extensions blocklist
export const DANGEROUS_EXTENSIONS = new Set([
  'exe', 'com', 'scr', 'bat', 'cmd', 'msi', 'msp',
  'ps1', 'psm1', 'vbs', 'vbe', 'js', 'jse', 'wsf', 'wsh',
  'hta', 'dll', 'sys', 'cpl', 'reg', 'lnk', 'url', 'pif', 'scr'
]);

// Windows reserved device names
const RESERVED_DEVICE_NAMES = new Set([
  'con', 'prn', 'aux', 'nul',
  'com1', 'com2', 'com3', 'com4', 'com5', 'com6', 'com7', 'com8', 'com9',
  'lpt1', 'lpt2', 'lpt3', 'lpt4', 'lpt5', 'lpt6', 'lpt7', 'lpt8', 'lpt9'
]);

export function sanitizeFilename(filename: string): { safeName: string; extension: string } {
  // Strip null bytes and control characters
  let clean = filename.replace(/[\x00-\x1f\x7f]/g, '');
  
  // Strip path traversal characters and directory separators
  clean = clean.replace(/\\/g, '/');
  clean = path.basename(clean);
  clean = clean.replace(/(\.\.[\/\\])+/g, '').replace(/[\/\\]/g, '');

  // Extract extension
  const extMatch = clean.match(/\.([a-zA-Z0-9]+)$/);
  const extension = extMatch ? extMatch[1].toLowerCase() : '';
  const baseWithoutExt = extMatch ? clean.slice(0, -extMatch[0].length) : clean;

  // Sanitize base: replace illegal Windows characters <>:"/\|?* with underscore
  let safeBase = baseWithoutExt.replace(/[<>:"/\\|?*]/g, '_').trim();
  if (!safeBase || RESERVED_DEVICE_NAMES.has(safeBase.toLowerCase())) {
    safeBase = `document_${Date.now()}`;
  }

  // Bound length to max 100 characters
  if (safeBase.length > 80) {
    safeBase = safeBase.slice(0, 80);
  }

  const safeName = extension ? `${safeBase}.${extension}` : safeBase;
  return { safeName, extension };
}

export interface SignatureValidationResult {
  isValid: boolean;
  detectedType: string;
  isExecutable: boolean;
  isThreat: boolean;
  reason?: string;
}

export function validateFileSignature(filePath: string, claimedExt: string): SignatureValidationResult {
  if (!fs.existsSync(filePath)) {
    return { isValid: false, detectedType: 'NOT_FOUND', isExecutable: false, isThreat: true, reason: 'File does not exist' };
  }

  const fd = fs.openSync(filePath, 'r');
  const buffer = Buffer.alloc(1024);
  const bytesRead = fs.readSync(fd, buffer, 0, 1024, 0);
  fs.closeSync(fd);

  if (bytesRead === 0) {
    return { isValid: false, detectedType: 'EMPTY', isExecutable: false, isThreat: false, reason: 'Empty file' };
  }

  // 1. Detect DOS/Windows MZ Header ('MZ' = 0x4D 0x5A) -> Disguised Executable
  if (bytesRead >= 2 && buffer[0] === 0x4D && buffer[1] === 0x5A) {
    return {
      isValid: false,
      detectedType: 'DOS_PE_EXECUTABLE',
      isExecutable: true,
      isThreat: true,
      reason: 'File contains Windows PE/DOS executable binary signature (MZ header). Disguised executable detected!'
    };
  }

  // 2. Detect ELF (Linux executable)
  if (bytesRead >= 4 && buffer[0] === 0x7F && buffer[1] === 0x45 && buffer[2] === 0x4C && buffer[3] === 0x46) {
    return {
      isValid: false,
      detectedType: 'ELF_EXECUTABLE',
      isExecutable: true,
      isThreat: true,
      reason: 'File contains Linux ELF binary signature. Executables are forbidden.'
    };
  }

  // 3. Detect PDF: starts with %PDF (0x25 0x50 0x44 0x46)
  if (bytesRead >= 4 && buffer.toString('utf-8', 0, 4) === '%PDF') {
    return {
      isValid: claimedExt === 'pdf',
      detectedType: 'PDF',
      isExecutable: false,
      isThreat: claimedExt !== 'pdf',
      reason: claimedExt !== 'pdf' ? `File is a PDF but has extension .${claimedExt}` : undefined
    };
  }

  // 4. Detect JPEG: 0xFF 0xD8 0xFF
  if (bytesRead >= 3 && buffer[0] === 0xFF && buffer[1] === 0xD8 && buffer[2] === 0xFF) {
    return {
      isValid: claimedExt === 'jpg' || claimedExt === 'jpeg',
      detectedType: 'JPEG',
      isExecutable: false,
      isThreat: false
    };
  }

  // 5. Detect PNG: 0x89 0x50 0x4E 0x47 0x0D 0x0A 0x1A 0x0A
  if (
    bytesRead >= 8 &&
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4E &&
    buffer[3] === 0x47 &&
    buffer[4] === 0x0D &&
    buffer[5] === 0x0A &&
    buffer[6] === 0x1A &&
    buffer[7] === 0x0A
  ) {
    return {
      isValid: claimedExt === 'png',
      detectedType: 'PNG',
      isExecutable: false,
      isThreat: false
    };
  }

  // 6. Detect WEBP: RIFF....WEBP
  if (bytesRead >= 12 && buffer.toString('utf-8', 0, 4) === 'RIFF' && buffer.toString('utf-8', 8, 12) === 'WEBP') {
    return {
      isValid: claimedExt === 'webp',
      detectedType: 'WEBP',
      isExecutable: false,
      isThreat: false
    };
  }

  // 7. Detect BMP: 'BM'
  if (bytesRead >= 2 && buffer[0] === 0x42 && buffer[1] === 0x4D) {
    return {
      isValid: claimedExt === 'bmp',
      detectedType: 'BMP',
      isExecutable: false,
      isThreat: false
    };
  }

  // 8. Detect ZIP / Office OpenXML (DOCX, XLSX, PPTX): 'PK\x03\x04'
  if (bytesRead >= 4 && buffer[0] === 0x50 && buffer[1] === 0x4B && buffer[2] === 0x03 && buffer[3] === 0x04) {
    const isOffice = ['docx', 'xlsx', 'pptx', 'zip'].includes(claimedExt);
    return {
      isValid: isOffice,
      detectedType: 'ZIP_ARCHIVE_OR_OPENXML',
      isExecutable: false,
      isThreat: false,
      reason: !isOffice ? 'ZIP package does not match claimed non-office extension' : undefined
    };
  }

  // 9. Detect OLE Compound File (Legacy DOC, XLS, PPT): 0xD0 0xCF 0x11 0xE0
  if (bytesRead >= 4 && buffer[0] === 0xD0 && buffer[1] === 0xCF && buffer[2] === 0x11 && buffer[3] === 0xE0) {
    const isLegacyOffice = ['doc', 'xls', 'ppt'].includes(claimedExt);
    return {
      isValid: isLegacyOffice,
      detectedType: 'OLE_COMPOUND_DOCUMENT',
      isExecutable: false,
      isThreat: false
    };
  }

  // 10. Check Plain Text / CSV
  if (['txt', 'csv'].includes(claimedExt)) {
    // Check if buffer contains control codes (other than newline, tab, cr)
    let isText = true;
    for (let i = 0; i < bytesRead; i++) {
      const b = buffer[i];
      if (b === 0 || (b < 7 && b !== 0) || (b > 13 && b < 32 && b !== 27)) {
        isText = false;
        break;
      }
    }
    return {
      isValid: isText,
      detectedType: isText ? 'PLAIN_TEXT' : 'BINARY',
      isExecutable: false,
      isThreat: !isText,
      reason: !isText ? 'Binary bytes found in text/csv document' : undefined
    };
  }

  // Fallback for other accepted extensions
  return {
    isValid: true,
    detectedType: 'GENERIC_BINARY',
    isExecutable: false,
    isThreat: false
  };
}

export async function scanFileWithDefender(filePath: string, allowBypass = false): Promise<{
  status: ScanStatus;
  threatName?: string;
  details: string;
}> {
  // Check for EICAR standard antivirus test string (safe standardized test mechanism for AVs)
  try {
    const content = fs.readFileSync(filePath, { encoding: 'utf-8', flag: 'r' });
    if (content.includes('EICAR-STANDARD-ANTIVIRUS-TEST-FILE')) {
      return {
        status: 'THREAT_DETECTED',
        threatName: 'Virus:DOS/EICAR_Test_File',
        details: 'Microsoft Defender / AV Test verification signature detected threat'
      };
    }
  } catch {
    // binary file or unreadable as utf-8, continue
  }

  // Detect Windows MpCmdRun.exe location
  const isWindows = process.platform === 'win32';
  if (isWindows) {
    const candidatePaths = [
      'C:\\Program Files\\Windows Defender\\MpCmdRun.exe',
      'C:\\ProgramData\\Microsoft\\Windows Defender\\Platform\\MpCmdRun.exe',
    ];

    let defenderExe: string | null = null;
    for (const p of candidatePaths) {
      if (fs.existsSync(p)) {
        defenderExe = p;
        break;
      }
    }

    // Also check through 'where MpCmdRun.exe'
    if (!defenderExe) {
      try {
        const { stdout } = await execAsync('where MpCmdRun.exe');
        if (stdout && stdout.trim()) {
          defenderExe = stdout.trim().split('\r\n')[0];
        }
      } catch {
        // not in PATH
      }
    }

    if (defenderExe) {
      try {
        // Run actual Defender scan
        // MpCmdRun.exe -Scan -ScanType 3 -File "<filePath>" -DisableRemediation
        const cmd = `"${defenderExe}" -Scan -ScanType 3 -File "${filePath}" -DisableRemediation`;
        await execAsync(cmd);
        return {
          status: 'CLEAN',
          details: 'Microsoft Defender scanned file. No threats detected.'
        };
      } catch (err: any) {
        // MpCmdRun returns code 2 if threat is detected
        if (err && err.code === 2) {
          return {
            status: 'THREAT_DETECTED',
            threatName: 'Threat detected by Microsoft Defender',
            details: err.stdout || err.message || 'Threat identified by Defender'
          };
        }
        return {
          status: 'SCAN_ERROR',
          details: `Defender execution error: ${err.message || 'Unknown error'}`
        };
      }
    }
  }

  // If not on Windows or Defender unavailable:
  if (allowBypass) {
    return {
      status: 'CLEAN',
      details: 'Emergency operator bypass applied. Note: Real Microsoft Defender requires Windows environment.'
    };
  }

  // Section 21 requirement:
  // "If Defender is unavailable: DO NOT automatically mark the file CLEAN.
  // Default secure behavior: SCAN UNAVAILABLE - File held until a successful security scan is available."
  return {
    status: 'SCAN_UNAVAILABLE',
    details: 'Microsoft Defender is not available in this environment. File held in quarantine in accordance with shop security policy.'
  };
}
