import fs from 'fs';
import path from 'path';
import os from 'os';

/**
 * Returns the default base directory for writable AQ-DIGITAL data.
 * When running as an installed application on Windows (e.g. from C:\Program Files\AQ-DIGITAL),
 * Program Files is read-only for standard users, so writable data must default to a
 * user-writable location such as %LOCALAPPDATA%\AQ-DIGITAL.
 */
export function getDefaultDataDir(): string {
  // 1. Explicit override via environment variable
  if (process.env.AQ_DATA_DIR && process.env.AQ_DATA_DIR.trim()) {
    return path.resolve(process.env.AQ_DATA_DIR.trim());
  }

  // 2. Windows: Standard user-writable application data folder (%LOCALAPPDATA%\AQ-DIGITAL)
  if (process.env.LOCALAPPDATA && process.env.LOCALAPPDATA.trim()) {
    return path.join(process.env.LOCALAPPDATA.trim(), 'AQ-DIGITAL');
  }

  if (process.platform === 'win32') {
    if (process.env.APPDATA && process.env.APPDATA.trim()) {
      return path.join(process.env.APPDATA.trim(), 'AQ-DIGITAL');
    }
    const home = os.homedir();
    if (home) {
      return path.join(home, 'AppData', 'Local', 'AQ-DIGITAL');
    }
  }

  // 3. Fallback for development / non-Windows environments
  return path.join(process.cwd(), 'AQ-DIGITAL');
}

const DEFAULT_DATA_DIR = getDefaultDataDir();

// Application configuration is independent from the operator's chosen file-storage folder.
// Keep the SQLite settings database permanently under the user's AQ-DIGITAL app-data folder.
export const PERSISTENT_CONFIG_DIR = path.join(DEFAULT_DATA_DIR, 'Config');

let currentDataDir = DEFAULT_DATA_DIR;

export const DIRS = {
  root: currentDataDir,
  jobs: path.join(currentDataDir, 'Jobs'),
  incoming: path.join(currentDataDir, 'Incoming'),
  quarantine: path.join(currentDataDir, 'Quarantine'),
  rejected: path.join(currentDataDir, 'Rejected'),
  finalDocs: path.join(currentDataDir, 'FinalDocuments'),
  logs: path.join(currentDataDir, 'Logs'),
  config: path.join(currentDataDir, 'Config'),
  temp: path.join(currentDataDir, 'Temp'),
  backups: path.join(currentDataDir, 'Backups'),
};

export function updateDirs() {
  DIRS.root = currentDataDir;
  DIRS.jobs = path.join(currentDataDir, 'Jobs');
  DIRS.incoming = path.join(currentDataDir, 'Incoming');
  DIRS.quarantine = path.join(currentDataDir, 'Quarantine');
  DIRS.rejected = path.join(currentDataDir, 'Rejected');
  DIRS.finalDocs = path.join(currentDataDir, 'FinalDocuments');
  DIRS.logs = path.join(currentDataDir, 'Logs');
  DIRS.config = path.join(currentDataDir, 'Config');
  DIRS.temp = path.join(currentDataDir, 'Temp');
  DIRS.backups = path.join(currentDataDir, 'Backups');
}

export function getBaseDataDir(): string {
  return currentDataDir;
}

export function setBaseDataDir(newDir: string) {
  if (!newDir || !newDir.trim()) return;
  currentDataDir = path.resolve(newDir.trim());
  updateDirs();
  initStorageDirectories();
}

export const BASE_DATA_DIR = currentDataDir;

export function initStorageDirectories() {
  Object.values(DIRS).forEach((dir) => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  });

  // Seamless legacy data migration: if running from a directory with existing AQ-DIGITAL files
  // (e.g. previous install or dev files in process.cwd()), migrate non-empty folders if target is fresh
  const legacyDir = path.join(process.cwd(), 'AQ-DIGITAL');
  if (legacyDir !== currentDataDir && fs.existsSync(legacyDir)) {
    try {
      const legacyConfig = path.join(legacyDir, 'Config');
      const targetConfig = DIRS.config;
      if (fs.existsSync(legacyConfig)) {
        const files = fs.readdirSync(legacyConfig);
        for (const file of files) {
          const srcFile = path.join(legacyConfig, file);
          const destFile = path.join(targetConfig, file);
          if (!fs.existsSync(destFile) && fs.existsSync(srcFile)) {
            try {
              fs.copyFileSync(srcFile, destFile);
            } catch {
              // ignore copy failure
            }
          }
        }
      }
    } catch {
      // ignore migration error
    }
  }
}

export function getStorageUsage(warningPercent = 80, criticalPercent = 90) {
  try {
    let totalBytes = 500 * 1024 * 1024 * 1024; // 500 GB fallback
    let freeBytes = 450 * 1024 * 1024 * 1024;
    let usedBytes = 0;

    // Measure actual usage of AQ-DIGITAL directory
    function getDirSize(dirPath: string): number {
      let size = 0;
      if (!fs.existsSync(dirPath)) return 0;
      const files = fs.readdirSync(dirPath);
      for (const file of files) {
        const full = path.join(dirPath, file);
        try {
          const stat = fs.statSync(full);
          if (stat.isDirectory()) {
            size += getDirSize(full);
          } else {
            size += stat.size;
          }
        } catch {
          // ignore unreadable
        }
      }
      return size;
    }

    usedBytes = getDirSize(currentDataDir);

    // If on linux or node supports statfs
    if (typeof fs.statfsSync === 'function') {
      try {
        const stats = fs.statfsSync(currentDataDir);
        totalBytes = stats.bsize * stats.blocks;
        freeBytes = stats.bsize * stats.bavail;
      } catch {
        // use defaults
      }
    }

    const usedPercent = totalBytes > 0 ? Math.round(((totalBytes - freeBytes) / totalBytes) * 100) : 10;
    let status: 'OK' | 'WARNING' | 'CRITICAL' = 'OK';
    if (usedPercent >= criticalPercent) {
      status = 'CRITICAL';
    } else if (usedPercent >= warningPercent) {
      status = 'WARNING';
    }

    return {
      totalBytes,
      usedBytes,
      freeBytes,
      usedPercent,
      status,
    };
  } catch (err) {
    return {
      totalBytes: 500 * 1024 * 1024 * 1024,
      usedBytes: 1024 * 1024 * 10,
      freeBytes: 490 * 1024 * 1024 * 1024,
      usedPercent: 2,
      status: 'OK' as const,
    };
  }
}
