export const LICENSING_WORKER_URL =
  'https://aq-digital-file-desk-licensing.burhanidigitalsolutions.workers.dev/';

export interface TrialServerResponse {
  success: boolean;
  trial_active?: boolean;
  trial_expired?: boolean;
  trial_days?: number;
  trial_start_at?: string;
  trial_expires_at?: string;
  customer_email?: string;
  error?: string;
}

/**
 * Contacts the Cloudflare licensing Worker to check or initiate a trial for the given device ID.
 * The Cloudflare Worker is the authority for trial start and expiration dates.
 * Stores and associates customer_email with the device ID record.
 */
export async function requestTrialFromServer(
  deviceId: string,
  customerEmail?: string,
  timeoutMs: number = 8000
): Promise<TrialServerResponse> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  const cleanEmail = customerEmail?.trim() || undefined;

  try {
    const res = await fetch(LICENSING_WORKER_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({
        action: 'trial',
        device_id: deviceId,
        deviceId: deviceId,
        customer_email: cleanEmail,
        customerEmail: cleanEmail,
        email: cleanEmail,
      }),
      signal: controller.signal,
    });

    clearTimeout(timer);

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      return {
        success: false,
        error: `Server responded with HTTP ${res.status}: ${errText.slice(0, 100)}`,
      };
    }

    const data = (await res.json()) as any;
    return {
      success: !!data.success,
      trial_active: data.trial_active,
      trial_expired: data.trial_expired,
      trial_days: data.trial_days,
      trial_start_at: data.trial_start_at,
      trial_expires_at: data.trial_expires_at,
      customer_email: data.customer_email || data.customerEmail || data.email || cleanEmail,
      error: data.error,
    };
  } catch (err: any) {
    clearTimeout(timer);
    const isAbort = err?.name === 'AbortError';
    return {
      success: false,
      error: isAbort ? 'Connection to licensing server timed out' : (err?.message || 'Network error connecting to licensing server'),
    };
  }
}
