import React, { useState } from 'react';
import {
  QrCode,
  Wifi,
  Globe,
  Copy,
  Check,
  Printer,
  Maximize2,
  ShieldCheck,
  Smartphone,
  ExternalLink,
  Info
} from 'lucide-react';
import { NetworkStatus } from '../types';

interface CustomerConnectionProps {
  network: NetworkStatus | null;
  onOpenMobileView: () => void;
}

export const CustomerConnectionView: React.FC<CustomerConnectionProps> = ({
  network,
  onOpenMobileView,
}) => {
  const [activeQrType, setActiveQrType] = useState<'SINGLE' | 'BOTH' | 'WIFI' | 'URL'>('SINGLE');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [showFullscreenQr, setShowFullscreenQr] = useState(false);

  const effectiveCustomerUrl = React.useMemo(() => {
    if (typeof window !== 'undefined') {
      const isCloudOrWeb = window.location.hostname !== 'localhost' &&
        window.location.hostname !== '127.0.0.1' &&
        !window.location.hostname.startsWith('192.168.') &&
        window.location.hostname !== 'aqdigital';
      if (isCloudOrWeb) {
        return `${window.location.origin}/upload`;
      }
    }
    return network?.customerUrl || 'http://aqdigital/upload';
  }, [network?.customerUrl]);

  const handleCopyUrl = () => {
    if (!effectiveCustomerUrl) return;
    navigator.clipboard.writeText(effectiveCustomerUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handlePrintCard = () => {
    window.print();
  };

  return (
    <div id="connection-qr-view" className="space-y-6">
      {/* Network Security Status Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
              <h2 className="text-base font-bold text-slate-900">
                AQ DIGITAL Customer Network
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Option A: Single-scan Wi-Fi hotspot with automatic Captive Portal upload prompt.
            </p>
          </div>

          <div className="flex flex-wrap gap-2 text-xs">
            <div className="bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 flex items-center gap-1.5">
              <Wifi className="w-4 h-4 text-blue-600" />
              <span className="text-slate-500">SSID:</span>
              <span className="font-mono font-bold text-slate-800">{network?.hotspotSsid || 'AQ-DIGITAL'}</span>
            </div>

            <div className="bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-emerald-600" />
              <span className="text-slate-500">Host:</span>
              <a
                href={effectiveCustomerUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono font-bold text-emerald-700 hover:text-emerald-800 underline inline-flex items-center gap-1"
                title="Click to open customer portal"
              >
                <span>{effectiveCustomerUrl}</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <div className="bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 flex items-center gap-1.5 text-emerald-800 font-semibold">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>{network?.customerNetworkStatus || 'LOCAL ONLY'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main QR Display Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* QR Showcase Cards */}
        <div className="lg:col-span-8 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col items-center text-center">
          {/* QR Type Selector */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold mb-6 flex-wrap gap-1">
            <button
              id="tab-qr-single"
              onClick={() => setActiveQrType('SINGLE')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeQrType === 'SINGLE' ? 'bg-blue-600 text-white shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              ⭐ Option A: Single Scan (Auto-Open)
            </button>
            <button
              id="tab-qr-both"
              onClick={() => setActiveQrType('BOTH')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeQrType === 'BOTH' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Dual Placard (Wi-Fi + URL)
            </button>
            <button
              id="tab-qr-wifi"
              onClick={() => setActiveQrType('WIFI')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeQrType === 'WIFI' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Wi-Fi QR Only
            </button>
            <button
              id="tab-qr-url"
              onClick={() => setActiveQrType('URL')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeQrType === 'URL' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Web URL QR Only
            </button>
          </div>

          {/* QR Code Images */}
          {activeQrType === 'SINGLE' ? (
            <div className="bg-gradient-to-b from-blue-50/50 to-slate-50 p-6 rounded-2xl border-2 border-blue-200 flex flex-col items-center my-2 max-w-md w-full shadow-xs">
              <div className="flex items-center gap-2 bg-blue-600 text-white text-[11px] font-bold px-3 py-1 rounded-full mb-3 shadow-xs">
                <span>ONE SCAN ONLY • CONNECTS & AUTO-OPENS DESK</span>
              </div>

              {network?.qrWifi ? (
                <img
                  src={network.qrWifi}
                  alt="Option A Single-Scan QR Code"
                  className="w-64 h-64 rounded-2xl shadow-md border-2 border-white bg-white p-3"
                />
              ) : (
                <div className="w-64 h-64 flex items-center justify-center text-slate-300 bg-white rounded-2xl border">
                  <QrCode className="w-16 h-16" />
                </div>
              )}

              <div className="mt-4 text-center space-y-1">
                <p className="font-extrabold text-base text-slate-900">
                  Network: <span className="font-mono text-blue-700">{network?.hotspotSsid}</span>
                </p>
                <p className="text-xs text-slate-600 max-w-xs font-medium">
                  Customer points camera here &rarr; taps <b>"Join"</b> &rarr; phone automatically slides up the upload desk!
                </p>
              </div>

              <div className="mt-4 w-full bg-blue-100/70 rounded-xl p-3 text-[11px] text-blue-950 flex items-center justify-between">
                <span className="font-semibold">Captive Auto-Open:</span>
                <span className="font-bold text-emerald-700 bg-white px-2 py-0.5 rounded-md border border-blue-200">
                  ACTIVE (iOS CNA & Android)
                </span>
              </div>

              {/* Immediate Fallback if phone didn't auto-open */}
              <div className="mt-4 w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-left">
                <div className="flex items-center justify-between">
                  <p className="text-[11px] font-bold text-slate-700">
                    If upload didn't pop up on phone:
                  </p>
                  <button
                    type="button"
                    onClick={() => setActiveQrType('BOTH')}
                    className="text-[11px] text-blue-600 font-semibold hover:underline"
                  >
                    View Dual QR &rarr;
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Open phone browser & type:
                </p>
                <div className="mt-1 flex items-center justify-between bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 font-mono text-xs text-blue-700 font-bold">
                  <span className="truncate">{network?.customerUrl}</span>
                  <button
                    type="button"
                    onClick={handleCopyUrl}
                    className="ml-2 text-slate-500 hover:text-slate-900 shrink-0"
                    title="Copy URL"
                  >
                    {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          ) : activeQrType === 'BOTH' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 w-full max-w-xl my-2">
              {/* Wi-Fi QR */}
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 flex flex-col items-center">
                <span className="text-[11px] font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full mb-2">
                  STEP 1: CONNECT WI-FI
                </span>
                {network?.qrWifi ? (
                  <img
                    src={network.qrWifi}
                    alt="Wi-Fi QR Code"
                    className="w-48 h-48 rounded-xl shadow-xs border border-slate-200 bg-white p-2"
                  />
                ) : (
                  <div className="w-48 h-48 flex items-center justify-center text-slate-300">
                    <QrCode className="w-12 h-12" />
                  </div>
                )}
                <p className="font-mono text-xs font-bold text-slate-800 mt-2">
                  SSID: {network?.hotspotSsid}
                </p>
                <p className="text-[11px] text-slate-400">Scan to join hotspot</p>
              </div>

              {/* URL QR */}
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 flex flex-col items-center">
                <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full mb-2">
                  STEP 2: OPEN DESK
                </span>
                {network?.qrUrl ? (
                  <img
                    src={network.qrUrl}
                    alt="Customer URL QR Code"
                    className="w-48 h-48 rounded-xl shadow-xs border border-slate-200 bg-white p-2"
                  />
                ) : (
                  <div className="w-48 h-48 flex items-center justify-center text-slate-300">
                    <QrCode className="w-12 h-12" />
                  </div>
                )}
                <p className="font-mono text-xs font-bold text-emerald-700 mt-2 truncate max-w-[200px]">
                  {effectiveCustomerUrl}
                </p>
                <p className="text-[11px] text-slate-400">Scan to upload documents</p>
              </div>
            </div>
          ) : activeQrType === 'WIFI' ? (
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col items-center my-2">
              <span className="text-xs font-bold text-blue-700 bg-blue-50 px-3 py-1 rounded-full mb-3">
                WI-FI QUICK-CONNECT QR
              </span>
              {network?.qrWifi && (
                <img
                  src={network.qrWifi}
                  alt="Wi-Fi QR Code"
                  className="w-64 h-64 rounded-xl shadow-md border border-slate-200 bg-white p-3"
                />
              )}
              <div className="mt-4 text-center">
                <p className="font-bold text-sm text-slate-900">Network: {network?.hotspotSsid}</p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Point phone camera here to join the Wi-Fi without typing password
                </p>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col items-center my-2">
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full mb-3">
                CUSTOMER WEBPAGE URL QR
              </span>
              {network?.qrUrl && (
                <img
                  src={network.qrUrl}
                  alt="Customer URL QR Code"
                  className="w-64 h-64 rounded-xl shadow-md border border-slate-200 bg-white p-3"
                />
              )}
              <div className="mt-4 text-center">
                <p className="font-bold text-sm text-slate-900 font-mono text-emerald-700">
                  {effectiveCustomerUrl}
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Scan once connected to open the instant upload page
                </p>
              </div>
            </div>
          )}

          {/* Quick Actions Row */}
          <div className="flex flex-wrap items-center justify-center gap-3 mt-6 pt-4 border-t border-slate-100 w-full">
            <a
              id="btn-open-customer-tab-direct"
              href={effectiveCustomerUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors"
              title="Open customer upload page directly in a new browser tab"
            >
              <ExternalLink className="w-4 h-4" />
              Open Customer Page (New Tab)
            </a>

            <button
              id="btn-copy-customer-url"
              onClick={handleCopyUrl}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors"
            >
              {copiedUrl ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              {copiedUrl ? 'Copied URL!' : 'Copy Customer URL'}
            </button>

            <button
              id="btn-fullscreen-qr"
              onClick={() => setShowFullscreenQr(true)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors"
            >
              <Maximize2 className="w-4 h-4" />
              Show Fullscreen QR
            </button>

            <button
              id="btn-print-qr-card"
              onClick={handlePrintCard}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Printer className="w-4 h-4" />
              Print Counter Sign
            </button>
          </div>
        </div>

        {/* Instructions & Guidelines Panel */}
        <div className="lg:col-span-4 space-y-4">
          {/* Quick Run / Test Guide */}
          <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-4 text-xs space-y-3 shadow-xs">
            <div className="flex items-center gap-2 text-emerald-900 font-bold">
              <Globe className="w-4 h-4 text-emerald-600" />
              <span>How to Run Customer Upload Page</span>
            </div>
            <p className="text-slate-600 text-[11.5px] leading-relaxed">
              You can test or run the customer upload page right now using any of these methods:
            </p>
            <div className="space-y-2">
              <a
                href={effectiveCustomerUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center justify-center gap-1.5 transition-colors shadow-xs text-xs"
              >
                <ExternalLink className="w-4 h-4" />
                Open Customer Page (New Tab)
              </a>
              <button
                onClick={onOpenMobileView}
                className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-semibold flex items-center justify-center gap-1.5 transition-colors text-xs"
              >
                <Smartphone className="w-4 h-4 text-blue-400" />
                Launch Phone Simulator
              </button>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-blue-600" />
              Customer Quick Steps
            </h3>

            <div className="space-y-3 text-xs text-slate-600">
              <div className="flex items-start space-x-2.5">
                <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <p className="font-semibold text-slate-800">Scan QR Code</p>
                  <p className="text-slate-500 mt-0.5">
                    Customer points Android or iPhone camera at the QR sign on your desk.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-2.5">
                <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <p className="font-semibold text-slate-800">Tap "Join AQ-DIGITAL"</p>
                  <p className="text-slate-500 mt-0.5">
                    Phone connects instantly to local Wi-Fi without needing Internet data.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-2.5">
                <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
                  3
                </span>
                <div>
                  <p className="font-semibold text-slate-800">Select & Upload</p>
                  <p className="text-slate-500 mt-0.5">
                    Customer picks files and keeps the browser page open for return documents.
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100">
              <button
                id="btn-test-customer-view"
                onClick={onOpenMobileView}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <Smartphone className="w-4 h-4 text-blue-400" />
                Launch Customer Test View
              </button>
            </div>
          </div>

          <div className="bg-blue-50/60 rounded-2xl p-4 border border-blue-100 text-xs text-slate-600 space-y-1.5">
            <p className="font-bold text-blue-900">Why Local Transfer?</p>
            <p className="text-slate-600">
              • Zero WhatsApp compression for crisp 300+ DPI prints.
            </p>
            <p className="text-slate-600">
              • Protected from USB pendrive viruses.
            </p>
            <p className="text-slate-600">
              • Operates 100% offline even during broadband outages.
            </p>
          </div>
        </div>
      </div>

      {/* Fullscreen QR Modal */}
      {showFullscreenQr && (
        <div
          id="modal-fullscreen-qr"
          onClick={() => setShowFullscreenQr(false)}
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-6 cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl p-8 max-w-md w-full text-center space-y-4 shadow-2xl border border-slate-200"
          >
            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
              AQ DIGITAL FILE DESK
            </h2>
            <p className="text-xs text-slate-500">Scan to connect phone and upload</p>

            <div className="flex justify-center">
              {network?.qrWifi && (
                <img
                  src={network.qrWifi}
                  alt="Large Wi-Fi QR"
                  className="w-72 h-72 rounded-2xl shadow-md border border-slate-100 p-2"
                />
              )}
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs font-mono">
              <p className="font-bold text-slate-800">Wi-Fi: {network?.hotspotSsid}</p>
              <p className="text-emerald-700 mt-0.5">{network?.customerUrl}</p>
            </div>

            <button
              onClick={() => setShowFullscreenQr(false)}
              className="px-6 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
