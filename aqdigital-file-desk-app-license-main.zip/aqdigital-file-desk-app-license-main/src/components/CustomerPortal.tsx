import React, { useState, useEffect, useRef } from 'react';
import {
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  Clock,
  Download,
  ShieldCheck,
  Smartphone,
  X,
  RefreshCw
} from 'lucide-react';
import { JobStatus } from '../types';

interface FileUploadItem {
  file: File;
  name: string;
  size: number;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
  error?: string;
}

export const CustomerPortal: React.FC<{
  initialToken?: string;
}> = ({ initialToken }) => {
  // Retrieve token from props, URL query parameter, or browser storage
  const getInitialToken = () => {
    if (initialToken) return initialToken;
    if (typeof window !== 'undefined') {
      const urlToken = new URLSearchParams(window.location.search).get('token');
      if (urlToken) return urlToken;
      const stored = sessionStorage.getItem('aq_customer_token') || localStorage.getItem('aq_customer_token');
      if (stored) {
        try {
          const dismissed = JSON.parse(sessionStorage.getItem('aq_dismissed_tokens') || '[]');
          if (dismissed.includes(stored)) return null;
        } catch {
          // silent
        }
        return stored;
      }
    }
    return null;
  };

  const [showOpenInBrowser, setShowOpenInBrowser] = useState(true);

  const [selectedFiles, setSelectedFiles] = useState<FileUploadItem[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [notes, setNotes] = useState('');
  const [jobId, setJobId] = useState<string | null>(null);
  const [jobToken, setJobToken] = useState<string | null>(getInitialToken);
  const [jobStatus, setJobStatus] = useState<JobStatus | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadPercent, setUploadPercent] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState<string | null>(null);
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [customerCharges, setCustomerCharges] = useState<Array<{ description: string; amount: number }>>([]);
  const [totalCharges, setTotalCharges] = useState(0);
  const [finalDoc, setFinalDoc] = useState<{
    filename: string;
    size: number;
    download_url: string;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const pollAbortControllerRef = useRef<AbortController | null>(null);
  const CHUNK_SIZE = 1024 * 1024; // 1 MB chunks

  // Sync token to browser storage and URL
  const saveToken = (token: string | null) => {
    setJobToken(token);
    if (typeof window !== 'undefined') {
      if (token) {
        sessionStorage.setItem('aq_customer_token', token);
        localStorage.setItem('aq_customer_token', token);
        const url = new URL(window.location.href);
        if (url.searchParams.get('token') !== token) {
          url.searchParams.set('token', token);
          window.history.replaceState(null, '', url.pathname + url.search);
        }
      } else {
        sessionStorage.removeItem('aq_customer_token');
        localStorage.removeItem('aq_customer_token');
        const url = new URL(window.location.href);
        url.searchParams.delete('token');
        window.history.replaceState(null, '', url.pathname + (url.search || ''));
      }
    }
  };

  // Auto-discover active session if customer opened /upload without an explicit token
  useEffect(() => {

  const ua = navigator.userAgent || "";

  const isAndroid = /Android/i.test(ua);

  const isChrome = /Chrome\//i.test(ua) && !/Edg\//i.test(ua) && !/OPR\//i.test(ua);

  const isWebView = isAndroid && (/; wv\)/i.test(ua) || /Version\/4\.0/i.test(ua) || /\bwv\b/i.test(ua));

  setShowOpenInBrowser(!(isChrome && !isWebView));

  }, []);

useEffect(() => {
    if (jobToken) return;
    if (typeof window !== 'undefined') {
      if (sessionStorage.getItem('aq_dismiss_active_session') === 'true') {
        return;
      }
    }
    const fetchActiveSession = async () => {
      try {
        const res = await fetch('/api/customer/active-session', { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          if (data.hasActiveSession && data.secure_token) {
            let isDismissed = false;
            try {
              const dismissed = JSON.parse(sessionStorage.getItem('aq_dismissed_tokens') || '[]');
              const localDismissed = JSON.parse(localStorage.getItem('aq_dismissed_tokens') || '[]');
              if (dismissed.includes(data.secure_token) || localDismissed.includes(data.secure_token)) {
                isDismissed = true;
              }
            } catch {
              // silent
            }
            if (!isDismissed) {
              setJobId(data.public_job_id);
              setJobStatus(data.status);
              saveToken(data.secure_token);
            }
          }
        }
      } catch {
        // silent
      }
    };
    fetchActiveSession();
  }, [jobToken]);

  // Robust polling for job status updates once token is available
  useEffect(() => {
    if (!jobToken) return;

    // Abort previous polling controller if any
    pollAbortControllerRef.current?.abort();
    const abortController = new AbortController();
    pollAbortControllerRef.current = abortController;

    let isMounted = true;
    const checkStatus = async () => {
      try {
        if (!isMounted || abortController.signal.aborted) return;
        const res = await fetch(`/api/customer/jobs/${jobToken}/status?_t=${Date.now()}`, {
          cache: 'no-store',
          signal: abortController.signal,
          headers: {
            'Cache-Control': 'no-store',
            Pragma: 'no-cache',
          },
        });
        if (!res.ok || !isMounted || abortController.signal.aborted) return;
        const data = await res.json();
        if (!isMounted || abortController.signal.aborted) return;

        if (data.public_job_id) {
          setJobId(data.public_job_id);
        }
        if (data.status) {
          setJobStatus(data.status);
        }
        if (data.time_remaining_seconds !== undefined) {
          setTimeRemaining(data.time_remaining_seconds);
        }
        if (data.rejection_reason) {
          setRejectionReason(data.rejection_reason);
        }
        if (data.charges) {
          setCustomerCharges(data.charges);
          setTotalCharges(data.total_charges || 0);
        }
        // Immediate detection of return document when published
        if (data.has_final_document && data.final_document) {
          setFinalDoc(data.final_document);
        } else if (data.status === 'PUBLISHED' && data.final_document) {
          setFinalDoc(data.final_document);
        }
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          console.warn('Status check error:', err);
        }
      }
    };

    checkStatus();
    const interval = setInterval(checkStatus, 1500);
    return () => {
      isMounted = false;
      abortController.abort();
      clearInterval(interval);
    };
  }, [jobToken]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const filesArray = Array.from(e.target.files).map((file) => ({
      file,
      name: file.name,
      size: file.size,
      progress: 0,
      status: 'pending' as const,
    }));
    setSelectedFiles((prev) => [...prev, ...filesArray]);
    setErrorMessage(null);
  };

  const removeFile = (index: number) => {
    if (isUploading) return;
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleOpenUploadMore = () => {
    setSelectedFiles([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    setErrorMessage(null);
    setUploadPercent(0);
    setIsUploading(false);
    setShowUploadForm(true);
  };

  const startUpload = async () => {
    if (selectedFiles.length === 0) return;
    setIsUploading(true);
    setErrorMessage(null);
    setUploadPercent(0);

    const totalBytes = selectedFiles.reduce((acc, f) => acc + f.size, 0);
    let uploadedBytes = 0;

    try {
      if (typeof window !== 'undefined') {
        sessionStorage.removeItem('aq_dismiss_active_session');
        localStorage.removeItem('aq_dismiss_active_session');
      }

      // 1. Initialize or append to existing session
      const initRes = await fetch('/api/customer/jobs/init', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: customerName.trim() || undefined,
          notes: notes.trim() || undefined,
          fileCount: selectedFiles.length,
          totalSize: totalBytes,
          existingToken: jobToken || undefined,
        }),
      });

      if (!initRes.ok) {
        const errData = await initRes.json();
        throw new Error(errData.message || 'Failed to start upload job.');
      }

      const initData = await initRes.json();
      setJobId(initData.public_job_id);
      saveToken(initData.secure_token);

      // 2. Upload each file in 1MB chunks
      for (let fileIdx = 0; fileIdx < selectedFiles.length; fileIdx++) {
        const item = selectedFiles[fileIdx];
        const file = item.file;
        const totalChunks = Math.max(1, Math.ceil(file.size / CHUNK_SIZE));

        for (let chunkIdx = 0; chunkIdx < totalChunks; chunkIdx++) {
          const start = chunkIdx * CHUNK_SIZE;
          const end = Math.min(file.size, start + CHUNK_SIZE);
          const chunkBlob = file.slice(start, end);

          // Convert chunk to base64
          const chunkArrayBuffer = await chunkBlob.arrayBuffer();
          const chunkBase64 = btoa(
            new Uint8Array(chunkArrayBuffer).reduce(
              (data, byte) => data + String.fromCharCode(byte),
              ''
            )
          );

          const chunkRes = await fetch(`/api/customer/jobs/${initData.secure_token}/upload-chunk`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fileName: file.name,
              fileIndex: fileIdx,
              totalFiles: selectedFiles.length,
              chunkIndex: chunkIdx,
              totalChunks,
              chunkBase64,
            }),
          });

          if (!chunkRes.ok) {
            const chunkErr = await chunkRes.json();
            throw new Error(chunkErr.message || 'Chunk upload failed');
          }

          uploadedBytes += chunkBlob.size;
          const overallPercent = Math.min(99, Math.round((uploadedBytes / totalBytes) * 100));
          setUploadPercent(overallPercent);
        }
      }

      setUploadPercent(100);
      setIsUploading(false);
      setShowUploadForm(false);
      setJobStatus('UPLOAD_COMPLETE');
    } catch (err: any) {
      console.warn('Upload failed:', err);
      setIsUploading(false);
      setErrorMessage(err.message || 'Upload failed. Please try again.');
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const handleResetForNewUpload = () => {
    // 1. Immediately abort any in-flight polling request
    pollAbortControllerRef.current?.abort();

    // 2. Record current token as dismissed so auto-reconnect does not re-latch onto it
    if (jobToken) {
      try {
        const dismissed = JSON.parse(sessionStorage.getItem('aq_dismissed_tokens') || '[]');
        if (!dismissed.includes(jobToken)) dismissed.push(jobToken);
        sessionStorage.setItem('aq_dismissed_tokens', JSON.stringify(dismissed));

        const localDismissed = JSON.parse(localStorage.getItem('aq_dismissed_tokens') || '[]');
        if (!localDismissed.includes(jobToken)) localDismissed.push(jobToken);
        localStorage.setItem('aq_dismissed_tokens', JSON.stringify(localDismissed));
      } catch {
        // silent
      }
    }

    if (typeof window !== 'undefined') {
      sessionStorage.setItem('aq_dismiss_active_session', 'true');
      localStorage.setItem('aq_dismiss_active_session', 'true');
    }

    // 3. Clear all completed job and document state to immediately open upload interface
    setSelectedFiles([]);
    setCustomerName('');
    setNotes('');
    setJobId(null);
    saveToken(null);
    setJobStatus(null);
    setFinalDoc(null);
    setCustomerCharges([]);
    setTotalCharges(0);
    setShowUploadForm(true);
    setErrorMessage(null);
    setRejectionReason(null);
    setTimeRemaining(null);
    setIsUploading(false);
    setUploadPercent(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div id="customer-portal-container" className="min-h-screen bg-slate-50 text-slate-900 flex flex-col justify-between">
      {/* Top Header */}
      <header id="customer-header" className="bg-white border-b border-slate-200 px-4 py-4 sticky top-0 z-10 shadow-xs">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-base shadow-xs">
              AQ
            </div>
            <div>
              <h1 className="font-bold text-base tracking-tight text-slate-900 leading-tight">
                AQ DIGITAL
              </h1>
              <p className="text-xs text-slate-500 font-medium">Local Document Desk</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              Local Wi-Fi
            </span>
          </div>
        </div>
      </header>

      {/* Main Customer Content */}
      <main id="customer-main" className="flex-1 max-w-md w-full mx-auto p-4 flex flex-col justify-center">
        {/* If final return document is ready */}
        {finalDoc ? (
          <div id="customer-ready-box" className="bg-white rounded-2xl p-6 border border-emerald-200 shadow-sm text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">
                Work Finished
              </span>
              <h2 className="text-xl font-extrabold text-slate-900 mt-2">
                Your Document Is Ready!
              </h2>
              <p className="text-xs text-slate-600 mt-1">
                The operator has processed your request and published your finished file.
              </p>
            </div>

            <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200 text-left flex items-center justify-between">
              <div className="flex items-center space-x-3 overflow-hidden">
                <FileText className="w-8 h-8 text-blue-600 shrink-0" />
                <div className="truncate">
                  <p className="text-sm font-semibold text-slate-800 truncate">
                    {finalDoc.filename}
                  </p>
                  <p className="text-xs text-slate-500">{formatBytes(finalDoc.size)}</p>
                </div>
              </div>
            </div>

            {/* Display Itemized Service Charges if applied */}
            {customerCharges && customerCharges.length > 0 && (
              <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200 text-left space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                  <span>Service Charges</span>
                  <span className="text-emerald-700 font-extrabold text-sm">
                    ₹{totalCharges.toFixed(2)}
                  </span>
                </div>
                <div className="divide-y divide-slate-200 text-xs text-slate-600 pt-1">
                  {customerCharges.map((c, i) => (
                    <div key={i} className="py-1 flex justify-between">
                      <span className="truncate pr-2">{c.description}</span>
                      <span className="font-semibold shrink-0">₹{Number(c.amount).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <a
              id="btn-customer-download"
              href={finalDoc.download_url}
              download={finalDoc.filename}
              className="w-full inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold py-3.5 px-6 rounded-xl shadow-md transition-colors text-base"
            >
              <Download className="w-5 h-5" />
              Download Document
            </a>

            <button
              id="btn-upload-another"
              data-testid="btn-upload-another"
              onClick={handleResetForNewUpload}
              className="text-xs text-slate-500 hover:text-slate-800 font-semibold underline block mx-auto pt-2 cursor-pointer"
            >
              Upload Another Document
            </button>
          </div>
        ) : jobId && !showUploadForm ? (
          /* Active Job Waiting / Progress State */
          <div id="customer-status-box" className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-5 text-center">
            {jobStatus === 'REJECTED' ? (
              <div className="space-y-3">
                <div className="w-14 h-14 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto">
                  <AlertCircle className="w-8 h-8" />
                </div>
                <h2 className="text-lg font-bold text-slate-900">Upload Rejected</h2>
                <p className="text-xs text-red-600 bg-red-50 p-2.5 rounded-lg border border-red-200">
                  {rejectionReason || 'The upload did not meet security or document criteria.'}
                </p>
                <button
                  id="btn-rejected-try-again"
                  onClick={handleResetForNewUpload}
                  className="mt-2 text-xs bg-slate-900 text-white font-semibold py-2 px-4 rounded-lg cursor-pointer"
                >
                  Try Again
                </button>
              </div>
            ) : jobStatus === 'TERMINATED' ? (
              <div className="space-y-3">
                <div className="w-14 h-14 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto">
                  <AlertCircle className="w-8 h-8" />
                </div>
                <h2 className="text-lg font-bold text-slate-900">Upload Stopped</h2>
                <p className="text-xs text-slate-600">
                  The upload was cancelled or terminated by the shop operator.
                </p>
                <button
                  id="btn-terminated-start-new"
                  onClick={handleResetForNewUpload}
                  className="mt-2 text-xs bg-slate-900 text-white font-semibold py-2 px-4 rounded-lg cursor-pointer"
                >
                  Start New Upload
                </button>
              </div>
            ) : isUploading ? (
              /* Active Uploading in Progress */
              <div className="space-y-4">
                <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto">
                  <Upload className="w-7 h-7 animate-bounce" />
                </div>

                <div>
                  <span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
                    Job ID: {jobId}
                  </span>
                  <h2 className="text-lg font-extrabold text-slate-900 mt-3">
                    Transferring Documents...
                  </h2>
                  <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                    Uploading directly over AQ DIGITAL Wi-Fi network
                  </p>
                </div>

                {/* Progress bar */}
                <div className="space-y-1.5 text-left">
                  <div className="flex justify-between text-xs font-semibold text-slate-700">
                    <span>Upload Progress</span>
                    <span>{uploadPercent}%</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="bg-blue-600 h-2.5 rounded-full transition-all duration-300"
                      style={{ width: `${uploadPercent}%` }}
                    ></div>
                  </div>
                </div>

                <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 text-xs text-slate-600 flex items-center gap-2 text-left">
                  <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span>Direct local encrypted channel. No internet data consumed.</span>
                </div>
              </div>
            ) : (
              /* Upload Finished -> Show Completed with Upload More Files button */
              <div className="space-y-4">
                <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border-2 border-emerald-200 shadow-xs">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600" />
                </div>

                <div>
                  <span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
                    Job ID: {jobId}
                  </span>
                  <h2 className="text-xl font-extrabold text-slate-900 mt-2.5">
                    Completed
                  </h2>
                  <p className="text-xs text-slate-600 mt-1.5 max-w-xs mx-auto">
                    {jobStatus === 'ACCEPTED' || jobStatus === 'PROCESSING'
                      ? 'The operator accepted your files and is preparing your document.'
                      : 'Your files were uploaded successfully and received by the shop operator.'}
                  </p>
                </div>

                {/* Upload More Files Button */}
                <div className="pt-1">
                  <button
                    id="btn-upload-more"
                    onClick={handleOpenUploadMore}
                    className="w-full inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold py-3.5 px-4 rounded-xl shadow-xs transition-colors text-sm cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    Upload More Files
                  </button>
                </div>

                {notes && (
                  <div className="bg-blue-50/70 p-3 rounded-xl border border-blue-200 text-left text-xs">
                    <span className="font-bold text-blue-900 block mb-0.5">Your Instructions to Admin:</span>
                    <p className="text-slate-700">{notes}</p>
                  </div>
                )}

                {/* Security Verification Badge */}
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 text-xs text-slate-600 flex items-center gap-2 text-left">
                  <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span>
                    Direct local encrypted channel. No internet data consumed.
                  </span>
                </div>

                <div className="pt-1">
                  <p className="text-xs text-slate-400 font-medium">
                    Auto-refreshes when document is ready...
                  </p>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* New Upload Selection Form */
          <div id="customer-upload-card" className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
            {jobId && (
              <div className="flex items-center justify-between pb-1">
                <span className="text-[11px] font-mono font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200">
                  Adding to Session: {jobId}
                </span>
                <button
                  type="button"
                  onClick={() => setShowUploadForm(false)}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  &larr; Back to Status
                </button>
              </div>
            )}
            <div className="text-center space-y-1">
              <h2 className="text-lg font-extrabold text-slate-900">
                SEND YOUR DOCUMENTS
              </h2>
              <p className="text-xs text-slate-500">
                {jobId ? 'Select additional files to attach to this job' : 'Select PDFs, photos, or documents to send to the operator'}
              </p>
            </div>

            {errorMessage && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Drop / Select Area */}
            <input
              type="file"
              ref={fileInputRef}
              multiple
              onChange={handleFileSelect}
              className="hidden"
              id="customer-file-input"
            />

            {showOpenInBrowser && (
<button
              type="button"
              onClick={() => {
                window.location.href =
                  "intent://192.168.137.1:3000/upload#Intent;scheme=http;package=com.android.chrome;end";
              }}
              className="w-full mb-4 rounded-lg bg-blue-600 px-4 py-3 text-sm font-bold text-white"
            >
              Open in Browser
            </button>
)}

            <div
              id="customer-dropzone"
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-300 hover:border-blue-500 bg-slate-50/70 hover:bg-blue-50/30 rounded-xl p-6 text-center cursor-pointer transition-colors"
            >
              <div className="w-12 h-12 bg-white rounded-full shadow-xs flex items-center justify-center mx-auto text-blue-600 mb-2">
                <Upload className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-slate-800">
                Tap to Select Files
              </p>
              <p className="text-xs text-slate-500 mt-0.5">
                PDF, DOCX, JPG, PNG, TXT (up to 100 MB)
              </p>
            </div>

            {/* Optional Customer Name / Note */}
            <div className="space-y-2">
              <input
                id="input-customer-name"
                type="text"
                placeholder="Your Name (optional)"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-white"
              />
              <input
                id="input-customer-note"
                type="text"
                placeholder="Instructions e.g., 2 color prints, B&W (optional)"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-white"
              />
            </div>

            {/* Selected Files List */}
            {selectedFiles.length > 0 && (
              <div id="customer-selected-files" className="space-y-2 pt-1">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-700">
                  <span>Selected ({selectedFiles.length} file{selectedFiles.length > 1 ? 's' : ''})</span>
                  <span>{formatBytes(selectedFiles.reduce((a, b) => a + b.size, 0))}</span>
                </div>

                <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
                  {selectedFiles.map((f, i) => (
                    <div
                      key={i}
                      className="bg-slate-50 p-2 rounded-lg border border-slate-200 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center space-x-2 truncate pr-2">
                        <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                        <span className="truncate font-medium text-slate-800">{f.name}</span>
                        <span className="text-slate-400 text-[10px] shrink-0">
                          ({formatBytes(f.size)})
                        </span>
                      </div>
                      <button
                        onClick={() => removeFile(i)}
                        className="text-slate-400 hover:text-red-600 p-0.5 rounded-sm"
                        title="Remove"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Upload Button */}
            <button
              id="btn-customer-upload-submit"
              disabled={selectedFiles.length === 0 || isUploading}
              onClick={startUpload}
              className={`w-full font-bold py-3.5 px-4 rounded-xl text-sm transition-all shadow-xs flex items-center justify-center gap-2 ${
                selectedFiles.length > 0 && !isUploading
                  ? 'bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white cursor-pointer'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <Upload className="w-4 h-4" />
              Upload {selectedFiles.length > 0 ? `(${selectedFiles.length})` : ''}
            </button>
          </div>
        )}
      </main>

      {/* Mobile Footer */}
      <footer id="customer-footer" className="p-4 text-center text-xs text-slate-400 border-t border-slate-100 bg-white">
        <p className="font-semibold text-slate-500">AQ DIGITAL FileDesk</p>
        <p className="text-[11px] text-slate-400 mt-0.5">
          Local Direct Transfer • No Internet Cloud Required
        </p>
      </footer>
    </div>
  );
};
