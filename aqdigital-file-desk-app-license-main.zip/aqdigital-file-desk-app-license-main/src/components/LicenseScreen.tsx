import React, { useState } from 'react';
import {
  Shield,
  Key,
  Clock,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Lock,
  WifiOff,
  X,
  Mail,
  Sparkles
} from 'lucide-react';
import { LicenseInfo } from '../types';

interface LicenseScreenProps {
  license: LicenseInfo | null;
  onRefresh: () => Promise<void>;
  onActivated?: () => void;
  onClose?: () => void;
  isModal?: boolean;
}

export const LicenseScreen: React.FC<LicenseScreenProps> = ({
  license,
  onRefresh,
  onActivated,
  onClose,
  isModal = false,
}) => {
  const [emailInput, setEmailInput] = useState(license?.customerEmail || '');
  const [licenseKeyInput, setLicenseKeyInput] = useState('');
  const [isStartingTrial, setIsStartingTrial] = useState(false);
  const [isActivating, setIsActivating] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleStartTrial = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = emailInput.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!cleanEmail || !emailRegex.test(cleanEmail)) {
      setErrorMessage('Please enter your email address to start your free trial.');
      return;
    }

    setIsStartingTrial(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const res = await fetch('/api/operator/license/start-trial', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, customer_email: cleanEmail }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSuccessMessage('Your 14-day free trial has been activated!');
        await onRefresh();
        if (onActivated) {
          setTimeout(() => onActivated(), 1200);
        }
      } else {
        setErrorMessage(data.error || 'Please enter a valid email address to start your free trial.');
      }
    } catch (err: any) {
      setErrorMessage('Could not connect to licensing server. Please check your internet connection and try again.');
    } finally {
      setIsStartingTrial(false);
    }
  };

  const handleActivate = async (e: React.FormEvent) => {
    e.preventDefault();
    const key = licenseKeyInput.trim();
    if (!key) {
      setErrorMessage('Please enter your license key.');
      return;
    }

    setIsActivating(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const res = await fetch('/api/operator/license/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ licenseKey: key }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSuccessMessage('License activated successfully! Full access granted.');
        setLicenseKeyInput('');
        await onRefresh();
        if (onActivated) {
          setTimeout(() => onActivated(), 1200);
        }
      } else {
        setErrorMessage(data.error || 'Activation failed. Please check your key.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Network error contacting licensing server.');
    } finally {
      setIsActivating(false);
    }
  };

  const handleManualCheck = async () => {
    setIsChecking(true);
    setErrorMessage(null);
    try {
      const cleanEmail = emailInput.trim() || undefined;
      const res = await fetch('/api/operator/license/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, customer_email: cleanEmail }),
      });
      const data = await res.json();
      if (!data.canAccessDesk && data.error) {
        setErrorMessage(data.error);
      } else if (data.canAccessDesk) {
        setSuccessMessage('Status updated successfully.');
      }
      await onRefresh();
    } catch (err: any) {
      setErrorMessage('Could not connect to licensing server: ' + err.message);
    } finally {
      setIsChecking(false);
    }
  };

  const isExpired = license?.status === 'trial_expired' || license?.status === 'expired';
  const isDisabled = license?.status === 'disabled';
  const isOfflineUnverified = license?.status === 'unverified_offline';
  const isGracePeriod = license?.status === 'grace_period';
  const isTrialActive = license?.status === 'trial_active';
  const isLicensed = license?.status === 'licensed';
  const needsTrialActivation = !isLicensed && !isExpired && (license?.needsEmailForTrial || (!license?.trialExpiresAt && !isTrialActive));
  const contactEmail = license?.supportEmail || 'support.aqdigitalsolutions@gmail.com';

  const formatIsoDate = (isoStr?: string) => {
    if (!isoStr) return 'N/A';
    try {
      return new Date(isoStr).toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return isoStr;
    }
  };

  return (
    <div
      className={
        isModal
          ? 'fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-xs'
          : 'min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-center items-center p-4'
      }
    >
      {/* Subtle lock-in animation keyframes with pulse and subtle shake effect */}
      <style>{`
        @keyframes lock-in {
          0% {
            transform: scale(0.96) translateY(6px);
            opacity: 0.85;
          }
          20% {
            transform: scale(1.02) translateY(0);
            opacity: 1;
            box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.35), 0 20px 25px -5px rgba(0, 0, 0, 0.2);
          }
          35% {
            transform: scale(1.02) translateX(-5px);
          }
          50% {
            transform: scale(1.01) translateX(5px);
          }
          65% {
            transform: scale(1.005) translateX(-3px);
          }
          80% {
            transform: scale(1.002) translateX(2px);
          }
          100% {
            transform: scale(1) translateX(0);
            opacity: 1;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
          }
        }
        @keyframes lockShieldPulse {
          0%, 100% {
            transform: scale(1);
            filter: drop-shadow(0 0 0 rgba(59, 130, 246, 0));
          }
          50% {
            transform: scale(1.06);
            filter: drop-shadow(0 0 6px rgba(59, 130, 246, 0.45));
          }
        }
        .animate-lock-in {
          animation: lock-in 0.65s cubic-bezier(0.25, 1, 0.5, 1) both;
        }
        .animate-lock-shield {
          animation: lockShieldPulse 2.8s ease-in-out infinite;
        }
      `}</style>

      <div className="w-full max-w-xl bg-white text-slate-900 rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col animate-lock-in">
        {/* Header */}
        <div className="bg-slate-950 text-white px-6 py-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 animate-lock-shield">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-white text-base">AQ DIGITAL</span>
                <span className="text-slate-400 text-sm">| FileDesk</span>
              </div>
              <p className="text-xs text-slate-400">License &amp; Trial Management</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {isModal && onClose && (
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          {/* Status Alert Banner */}
          {needsTrialActivation && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start space-x-3">
              <Clock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs">
                <p className="font-bold text-blue-900 text-sm">Start Your 14-Day Free Trial</p>
                <p className="text-blue-700 mt-0.5">
                  Please enter your email address to start your free trial.
                </p>
              </div>
            </div>
          )}

          {isTrialActive && !needsTrialActivation && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start space-x-3">
              <Clock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs">
                <p className="font-bold text-blue-900 text-sm">Free Trial Active</p>
                <p className="text-blue-700 mt-0.5">
                  You have <span className="font-bold">{license?.daysRemaining ?? '14'} day(s)</span> remaining in your evaluation trial.
                  {license?.trialExpiresAt && ` Expires on ${formatIsoDate(license.trialExpiresAt)}.`}
                </p>
              </div>
            </div>
          )}

          {isLicensed && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-start space-x-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs">
                <p className="font-bold text-emerald-900 text-sm">Full License Activated</p>
                <p className="text-emerald-700 mt-0.5">
                  AQ DIGITAL FileDesk is fully registered and licensed for this device.
                  {license?.expiresAt && ` Valid until ${formatIsoDate(license.expiresAt)}.`}
                </p>
              </div>
            </div>
          )}

          {isGracePeriod && (
            <div className="bg-amber-50 border border-amber-300 rounded-xl p-4 flex items-start space-x-3">
              <WifiOff className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs">
                <p className="font-bold text-amber-900 text-sm">Offline Grace Period Active</p>
                <p className="text-amber-800 mt-0.5">
                  Operating offline. You have <span className="font-bold">{license?.graceDaysRemaining ?? 7} day(s)</span> remaining before online validation is required.
                </p>
              </div>
            </div>
          )}

          {isExpired && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs">
                <p className="font-bold text-red-900 text-sm">
                  {license?.status === 'trial_expired' ? 'Free Trial Expired' : 'License Expired'}
                </p>
                <p className="text-red-700 mt-0.5">
                  {license?.status === 'trial_expired'
                    ? 'Your evaluation period has ended. Enter a license key below to unlock the operator desk.'
                    : 'Your software license has expired. Please renew your key or enter a new license.'}
                </p>
              </div>
            </div>
          )}

          {isDisabled && (
            <div className="bg-red-50 border border-red-300 rounded-xl p-4 flex items-start space-x-3">
              <Lock className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs">
                <p className="font-bold text-red-900 text-sm">License Disabled</p>
                <p className="text-red-700 mt-0.5">
                  {license?.error || 'This license key has been disabled by the administrator.'}
                </p>
              </div>
            </div>
          )}

          {isOfflineUnverified && !needsTrialActivation && (
            <div className="bg-amber-50 border border-amber-300 rounded-xl p-4 flex items-start space-x-3">
              <WifiOff className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs">
                <p className="font-bold text-amber-900 text-sm">Internet Connection Required</p>
                <p className="text-amber-800 mt-0.5">
                  {license?.error || 'Please connect your PC to the internet and click Retry Validation to verify your license.'}
                </p>
              </div>
            </div>
          )}

          {/* First-time Trial Email Form */}
          {needsTrialActivation && (
            <form onSubmit={handleStartTrial} className="space-y-3 bg-slate-50 border border-slate-200 rounded-xl p-4">
              <div>
                <label htmlFor="input-trial-email" className="block text-xs font-bold text-slate-700 mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    id="input-trial-email"
                    type="email"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="e.g. name@example.com"
                    className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isStartingTrial || !emailInput.trim()}
                className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-2 shadow-sm transition-colors cursor-pointer"
              >
                {isStartingTrial ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Starting Trial...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Start 14-Day Free Trial</span>
                  </>
                )}
              </button>
            </form>
          )}

          {needsTrialActivation && (
            <div className="relative my-1 flex items-center justify-center">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200"></div>
              </div>
              <span className="relative bg-white px-3 text-[11px] font-medium text-slate-400 uppercase tracking-wider">
                Or enter a license key
              </span>
            </div>
          )}

          {/* License Activation Form */}
          <form onSubmit={handleActivate} className="space-y-3">
            <div>
              <label htmlFor="input-license-key" className="block text-xs font-bold text-slate-700 mb-1.5">
                {isLicensed ? 'Update / Change License Key' : 'Enter License Key'}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Key className="w-4 h-4" />
                </div>
                <input
                  id="input-license-key"
                  type="text"
                  value={licenseKeyInput}
                  onChange={(e) => setLicenseKeyInput(e.target.value)}
                  placeholder="e.g. AQD-PRO-XXXX-XXXX-XXXX"
                  className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all uppercase"
                />
              </div>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg p-3 flex items-start space-x-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Success Message */}
            {successMessage && (
              <div className="text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
                <span>{successMessage}</span>
              </div>
            )}

            <div className="flex items-center space-x-3 pt-1">
              <button
                type="submit"
                disabled={isActivating || !licenseKeyInput.trim()}
                className="flex-1 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-2 shadow-sm transition-colors cursor-pointer"
              >
                {isActivating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Activating with Server...</span>
                  </>
                ) : (
                  <>
                    <Key className="w-4 h-4" />
                    <span>Activate License</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleManualCheck}
                disabled={isChecking}
                className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-slate-700 font-semibold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-300 transition-colors cursor-pointer"
                title="Verify license status with licensing server"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
                <span>{isChecking ? 'Checking...' : 'Check Status'}</span>
              </button>
            </div>
          </form>

          {/* Simple Contact Section */}
          <div className="rounded-xl border border-slate-200 bg-slate-50/80 p-3.5 text-xs text-slate-600">
            <p className="font-semibold text-slate-800">Need a license after your trial?</p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Contact:{' '}
              <a
                href={`mailto:${contactEmail}`}
                className="text-blue-600 hover:text-blue-800 hover:underline font-medium"
              >
                {contactEmail}
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
