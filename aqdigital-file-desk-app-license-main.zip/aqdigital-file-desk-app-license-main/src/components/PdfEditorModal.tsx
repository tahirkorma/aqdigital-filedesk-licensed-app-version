import React, { useState, useRef } from 'react';
import {
  FileText,
  Send,
  Crop,
  Type,
  Receipt,
  Plus,
  Trash2,
  CheckCircle2,
  Printer,
  Download,
  AlertCircle,
  Eye,
  ArrowRight,
  Copy,
  Check,
  Folder,
  Image as ImageIcon
} from 'lucide-react';
import { Job, ChargeItem } from '../types';

interface PdfEditorModalProps {
  job: Job;
  onClose: () => void;
  onSuccess: () => void;
}

export const PdfEditorModal: React.FC<PdfEditorModalProps> = ({
  job,
  onClose,
  onSuccess,
}) => {
  const [activeMode, setActiveMode] = useState<'SELECT' | 'DIRECT' | 'EDIT'>('SELECT');
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [pdfBase64, setPdfBase64] = useState<string | null>(null);
  const [tempPath, setTempPath] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedReturnPath, setCopiedReturnPath] = useState(false);

  // Edit Options
  const [cropTop, setCropTop] = useState(0);
  const [cropBottom, setCropBottom] = useState(0);
  const [cropLeft, setCropLeft] = useState(0);
  const [cropRight, setCropRight] = useState(0);

  const [stampText, setStampText] = useState('AQ DIGITAL • OFFICIAL RECEIPT');
  const [stampPosition, setStampPosition] = useState<'TOP' | 'BOTTOM' | 'STAMP'>('BOTTOM');

  // Charges
  const [charges, setCharges] = useState<Array<{ description: string; amount: number }>>([
    { description: 'Typing & Formatting', amount: 50 },
    { description: 'Laser Printout (B&W)', amount: 20 },
  ]);
  const [showChargesBox, setShowChargesBox] = useState(true);

  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  // Staged file from customer upload
  const [isStagingCustomerFile, setIsStagingCustomerFile] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Allow one-click staging of customer's uploaded files for return editing
  const handleStageCustomerFile = async (fileId: string) => {
    setIsStagingCustomerFile(true);
    setErrorMessage(null);
    try {
      const res = await fetch('/api/operator/portal-pdf/stage-job-file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobId: job.id,
          fileId,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to stage customer file');
      }

      const data = await res.json();
      setTempPath(data.tempPath);
      setPreviewUrl(data.dataUrl);
      setPdfFile(new File([], data.filename, { type: data.isImage ? 'image/jpeg' : 'application/pdf' }));
      if (activeMode === 'SELECT') {
        setActiveMode('EDIT');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to stage customer file');
    } finally {
      setIsStagingCustomerFile(false);
    }
  };

  const handlePdfUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/bmp'];
    const allowedExts = ['pdf', 'png', 'jpg', 'jpeg', 'webp', 'bmp'];
    if (!allowedTypes.includes(file.type) && !allowedExts.includes(ext)) {
      setErrorMessage('Please select a valid PDF or Image file (.pdf, .png, .jpg, .jpeg, .webp, .bmp).');
      return;
    }

    setPdfFile(file);
    const reader = new FileReader();
    reader.onload = async () => {
      const b64 = (reader.result as string).split(',')[1];
      setPdfBase64(b64);
      setPreviewUrl(reader.result as string);

      // Upload to server temp storage
      try {
        const res = await fetch('/api/operator/portal-pdf/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            jobId: job.id,
            base64Pdf: b64,
            originalFilename: file.name,
          }),
        });
        if (!res.ok) throw new Error('Failed to stage return file on server');
        const data = await res.json();
        setTempPath(data.tempPath);
        setErrorMessage(null);
      } catch (err: any) {
        setErrorMessage(err.message || 'Failed to stage file');
      }
    };
    reader.readAsDataURL(file);
  };

  const addChargeRow = (desc = 'Service Fee', amt = 20) => {
    setCharges((prev) => [...prev, { description: desc, amount: amt }]);
  };

  const removeChargeRow = (index: number) => {
    setCharges((prev) => prev.filter((_, i) => i !== index));
  };

  const updateCharge = (index: number, desc: string, amt: number) => {
    setCharges((prev) => {
      const copy = [...prev];
      copy[index] = { description: desc, amount: amt };
      return copy;
    });
  };

  const totalCharges = charges.reduce((sum, c) => sum + (Number(c.amount) || 0), 0);

  // Send directly without modification
  const handleSendDirect = async () => {
    if (!tempPath) {
      setErrorMessage('Please select a PDF file first.');
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);
    try {
      const res = await fetch('/api/operator/portal-pdf/send-direct', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobId: job.id,
          tempPath,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to publish direct PDF');
      }

      setIsProcessing(false);
      onSuccess();
    } catch (err: any) {
      setIsProcessing(false);
      setErrorMessage(err.message || 'Failed to send PDF');
    }
  };

  // Process edits (crop, text, charges) and publish
  const handleProcessAndSend = async () => {
    if (!tempPath) {
      setErrorMessage('Please select a PDF file first.');
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/operator/portal-pdf/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobId: job.id,
          tempPath,
          editOptions: {
            crop: {
              top: cropTop,
              bottom: cropBottom,
              left: cropLeft,
              right: cropRight,
            },
            stampText: stampText.trim() || undefined,
            additionalText: stampText.trim() || undefined,
            stampPosition,
            showChargesBox,
            charges,
          },
          charges,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to process and publish PDF');
      }

      setIsProcessing(false);
      onSuccess();
    } catch (err: any) {
      setIsProcessing(false);
      setErrorMessage(err.message || 'Failed to process and publish PDF');
    }
  };

  return (
    <div id="modal-pdf-studio" className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-blue-400" />
            <div>
              <h2 className="font-bold text-sm tracking-wide">
                Customer Return Document Studio
              </h2>
              <p className="text-[11px] text-slate-400">
                Target Job: <span className="font-mono text-emerald-400 font-bold">{job.public_job_id}</span> ({job.customer_name || 'Walk-in Customer'})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-sm text-sm"
          >
            ✕
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* 1. PDF Selection Box */}
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Step 1: Import Finished Document or Image (PDF / PNG / JPG / WEBP)
                </span>
                <p className="text-xs text-slate-600 mt-0.5">
                  Select the completed government portal receipt, certificate, edited photo, or PDF form.
                </p>
              </div>

              <input
                type="file"
                ref={fileInputRef}
                accept=".pdf,.png,.jpg,.jpeg,.webp,.bmp,application/pdf,image/*"
                onChange={handlePdfUpload}
                className="hidden"
                id="portal-pdf-input"
              />

              <button
                id="btn-choose-portal-pdf"
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 shrink-0"
              >
                {pdfFile?.type.startsWith('image/') || pdfFile?.name.match(/\.(png|jpg|jpeg|webp|bmp)$/i) ? (
                  <ImageIcon className="w-4 h-4" />
                ) : (
                  <FileText className="w-4 h-4" />
                )}
                {pdfFile ? 'Change File' : 'Select Return File (PDF / Image)'}
              </button>
            </div>

            {/* Customer's uploaded files quick picker */}
            {job.files && job.files.filter((f) => f.storage_state === 'CLEAN').length > 0 && (
              <div className="pt-2 border-t border-slate-200">
                <span className="text-[11px] font-semibold text-slate-500 block mb-1.5">
                  Or use customer's uploaded file for this job:
                </span>
                <div className="flex flex-wrap gap-2">
                  {job.files
                    .filter((f) => f.storage_state === 'CLEAN')
                    .map((f) => (
                      <button
                        key={f.id}
                        id={`btn-stage-file-${f.id}`}
                        type="button"
                        disabled={isStagingCustomerFile}
                        onClick={() => handleStageCustomerFile(f.id)}
                        className="text-xs bg-white hover:bg-blue-50 border border-slate-300 hover:border-blue-400 text-slate-800 font-medium px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
                      >
                        <FileText className="w-3.5 h-3.5 text-blue-600" />
                        <span className="truncate max-w-[180px]">{f.original_filename}</span>
                      </button>
                    ))}
                </div>
              </div>
            )}

            {pdfFile && (
              <div className="space-y-2">
                <div className="p-2.5 bg-white rounded-lg border border-slate-200 flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-2 truncate">
                    {pdfFile.type.startsWith('image/') || pdfFile.name.match(/\.(png|jpg|jpeg|webp|bmp)$/i) ? (
                      <ImageIcon className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                    )}
                    <span className="font-semibold text-slate-800 truncate">
                      {pdfFile.name} ({(pdfFile.size / 1024).toFixed(1)} KB)
                    </span>
                  </div>
                  <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-sm border border-emerald-200 text-[11px] shrink-0">
                    Ready to Publish
                  </span>
                </div>

                {/* File storage location details */}
                <div className="flex items-center justify-between gap-2 bg-slate-900 text-slate-200 px-3 py-2 rounded-lg text-[11px] font-mono">
                  <div className="truncate">
                    <span className="text-slate-400 block text-[10px] uppercase font-sans font-semibold">Will be saved to Host Disk:</span>
                    <span className="text-emerald-400 select-all truncate block">
                      storage/final_docs/{job.public_job_id}_return.{pdfFile.name.split('.').pop()?.toLowerCase() || 'pdf'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const ext = pdfFile.name.split('.').pop()?.toLowerCase() || 'pdf';
                      navigator.clipboard.writeText(`storage/final_docs/${job.public_job_id}_return.${ext}`);
                      setCopiedReturnPath(true);
                      setTimeout(() => setCopiedReturnPath(false), 2000);
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-sans font-semibold shrink-0"
                  >
                    {copiedReturnPath ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    {copiedReturnPath ? 'Copied' : 'Copy Path'}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 2. Choose Workflow Mode */}
          {pdfFile && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div
                  onClick={() => setActiveMode('DIRECT')}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                    activeMode === 'DIRECT'
                      ? 'border-blue-600 bg-blue-50/50 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Send className="w-5 h-5 text-blue-600" />
                    <h3 className="font-bold text-sm text-slate-900">Send Directly</h3>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Send the original portal PDF immediately to customer phone without any changes.
                  </p>
                </div>

                <div
                  onClick={() => setActiveMode('EDIT')}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                    activeMode === 'EDIT'
                      ? 'border-blue-600 bg-blue-50/50 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Crop className="w-5 h-5 text-purple-600" />
                    <h3 className="font-bold text-sm text-slate-900">Edit & Send</h3>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Crop margins, add text/stamp, and calculate itemized shop charges.
                  </p>
                </div>
              </div>

              {/* Edit Controls (if EDIT mode) */}
              {activeMode === 'EDIT' && (
                <div className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  {/* A. Crop Margins */}
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5 mb-2">
                      <Crop className="w-4 h-4 text-purple-600" />
                      Crop Page Margins (Remove Unwanted Portal Bars)
                    </h4>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      <div>
                        <label className="text-slate-500 block mb-0.5">Top Crop (pts)</label>
                        <input
                          id="input-crop-top"
                          type="number"
                          value={cropTop}
                          onChange={(e) => setCropTop(Number(e.target.value))}
                          className="w-full px-2 py-1 rounded-sm border border-slate-200 bg-white"
                        />
                      </div>
                      <div>
                        <label className="text-slate-500 block mb-0.5">Bottom Crop (pts)</label>
                        <input
                          id="input-crop-bottom"
                          type="number"
                          value={cropBottom}
                          onChange={(e) => setCropBottom(Number(e.target.value))}
                          className="w-full px-2 py-1 rounded-sm border border-slate-200 bg-white"
                        />
                      </div>
                      <div>
                        <label className="text-slate-500 block mb-0.5">Left Crop (pts)</label>
                        <input
                          id="input-crop-left"
                          type="number"
                          value={cropLeft}
                          onChange={(e) => setCropLeft(Number(e.target.value))}
                          className="w-full px-2 py-1 rounded-sm border border-slate-200 bg-white"
                        />
                      </div>
                      <div>
                        <label className="text-slate-500 block mb-0.5">Right Crop (pts)</label>
                        <input
                          id="input-crop-right"
                          type="number"
                          value={cropRight}
                          onChange={(e) => setCropRight(Number(e.target.value))}
                          className="w-full px-2 py-1 rounded-sm border border-slate-200 bg-white"
                        />
                      </div>
                    </div>

                    {/* Quick Portal Bar Crop Presets */}
                    <div className="flex flex-wrap gap-1.5 mt-2.5">
                      <span className="text-[11px] text-slate-400 py-0.5">Quick Remove:</span>
                      <button
                        id="btn-crop-header-preset"
                        type="button"
                        onClick={() => setCropTop((prev) => (prev > 0 ? prev : 45))}
                        className="text-[11px] bg-white hover:bg-slate-100 text-purple-700 font-medium px-2 py-0.5 rounded border border-purple-200 cursor-pointer"
                      >
                        +Header Bar (Top 45pt)
                      </button>
                      <button
                        id="btn-crop-footer-preset"
                        type="button"
                        onClick={() => setCropBottom((prev) => (prev > 0 ? prev : 45))}
                        className="text-[11px] bg-white hover:bg-slate-100 text-purple-700 font-medium px-2 py-0.5 rounded border border-purple-200 cursor-pointer"
                      >
                        +Footer Bar (Bottom 45pt)
                      </button>
                      <button
                        id="btn-crop-both-preset"
                        type="button"
                        onClick={() => {
                          setCropTop(45);
                          setCropBottom(45);
                        }}
                        className="text-[11px] bg-white hover:bg-slate-100 text-purple-700 font-medium px-2 py-0.5 rounded border border-purple-200 cursor-pointer"
                      >
                        +Both Portal Bars (45pt)
                      </button>
                      <button
                        id="btn-crop-reset"
                        type="button"
                        onClick={() => {
                          setCropTop(0);
                          setCropBottom(0);
                          setCropLeft(0);
                          setCropRight(0);
                        }}
                        className="text-[11px] bg-white hover:bg-slate-100 text-slate-500 font-medium px-2 py-0.5 rounded border border-slate-200 cursor-pointer"
                      >
                        Reset Margins (0pt)
                      </button>
                    </div>
                  </div>

                  {/* B. Custom Text / Stamp */}
                  <div className="pt-2 border-t border-slate-200">
                    <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5 mb-2">
                      <Type className="w-4 h-4 text-blue-600" />
                      Additional Text / Shop Stamp
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                      <div className="sm:col-span-2">
                        <input
                          id="input-additional-text"
                          name="additionalText"
                          data-testid="input-additional-text"
                          type="text"
                          value={stampText}
                          onChange={(e) => setStampText(e.target.value)}
                          placeholder="e.g., AQ DIGITAL • APPROVED (or custom text)"
                          className="w-full px-3 py-1.5 rounded-sm border border-slate-200 bg-white"
                        />
                      </div>
                      <div>
                        <select
                          id="select-stamp-position"
                          value={stampPosition}
                          onChange={(e) => setStampPosition(e.target.value as any)}
                          className="w-full px-2 py-1.5 rounded-sm border border-slate-200 bg-white cursor-pointer"
                        >
                          <option value="BOTTOM">Bottom Footer</option>
                          <option value="TOP">Top Header</option>
                          <option value="STAMP">Center Stamp</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* C. Additional Service Charges */}
                  <div className="pt-2 border-t border-slate-200">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <Receipt className="w-4 h-4 text-emerald-600" />
                        Additional Service Charges
                      </h4>
                      <label className="flex items-center space-x-1.5 text-xs text-slate-600 cursor-pointer">
                        <input
                          id="checkbox-stamp-charges"
                          type="checkbox"
                          checked={showChargesBox}
                          onChange={(e) => setShowChargesBox(e.target.checked)}
                          className="rounded-sm text-emerald-600 cursor-pointer"
                        />
                        <span>Stamp Charges Box onto Document</span>
                      </label>
                    </div>

                    {/* Quick Presets */}
                    <div className="flex flex-wrap gap-1.5 mb-2.5">
                      <span className="text-[11px] text-slate-400 py-0.5">Quick Add:</span>
                      {[
                        { name: 'Typing', amt: 50 },
                        { name: 'Printing', amt: 20 },
                        { name: 'Scanning', amt: 10 },
                        { name: 'Online Form', amt: 100 },
                        { name: 'Lamination', amt: 30 },
                      ].map((item) => (
                        <button
                          key={item.name}
                          type="button"
                          onClick={() => addChargeRow(item.name, item.amt)}
                          className="text-[11px] bg-white hover:bg-slate-100 text-slate-700 font-medium px-2 py-0.5 rounded-sm border border-slate-200 cursor-pointer"
                        >
                          +{item.name} (₹{item.amt})
                        </button>
                      ))}
                    </div>

                    {/* Charges List */}
                    <div className="space-y-1.5">
                      {charges.map((c, i) => (
                        <div key={i} className="flex items-center space-x-2 text-xs">
                          <input
                            id={`input-charge-desc-${i}`}
                            type="text"
                            value={c.description}
                            onChange={(e) => updateCharge(i, e.target.value, c.amount)}
                            placeholder="Service description"
                            className="flex-1 px-2.5 py-1 rounded-sm border border-slate-200 bg-white"
                          />
                          <div className="flex items-center space-x-1 w-28">
                            <span className="text-slate-400 font-bold">₹</span>
                            <input
                              id={`input-charge-amount-${i}`}
                              type="number"
                              value={c.amount}
                              onChange={(e) => updateCharge(i, c.description, Number(e.target.value))}
                              className="w-full px-2 py-1 rounded-sm border border-slate-200 bg-white text-right"
                            />
                          </div>
                          <button
                            type="button"
                            onClick={() => removeChargeRow(i)}
                            className="text-slate-400 hover:text-red-600 p-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}

                      <div className="flex justify-between items-center pt-2 text-xs">
                        <button
                          type="button"
                          onClick={() => addChargeRow()}
                          className="text-blue-600 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          Add Custom Line
                        </button>
                        <div id="text-total-charges" className="font-bold text-sm text-slate-900 bg-white px-3 py-1 rounded-md border border-slate-200">
                          TOTAL: <span className="text-emerald-600">₹{totalCharges.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Preview Box */}
              {previewUrl && (
                <div className="p-3 bg-white rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-2">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5" />
                      Document Live View
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Original preserved • Safe copy generated
                    </span>
                  </div>
                  <iframe
                    src={previewUrl}
                    className="w-full h-48 sm:h-64 rounded-lg border border-slate-100"
                    title="PDF Preview"
                  />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            Cancel
          </button>

          <div className="flex items-center space-x-2">
            {activeMode === 'DIRECT' ? (
              <button
                id="btn-confirm-send-direct"
                disabled={isProcessing || !tempPath}
                onClick={handleSendDirect}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                {isProcessing ? 'Sending...' : 'Send Document Directly'}
              </button>
            ) : activeMode === 'EDIT' ? (
              <button
                id="btn-send-document"
                data-testid="btn-confirm-process-edit"
                disabled={isProcessing || !tempPath}
                onClick={handleProcessAndSend}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-2 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                {isProcessing ? 'Sending Document...' : 'Send Document'}
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};
