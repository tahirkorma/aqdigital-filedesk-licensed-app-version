export type JobStatus =
  | 'NEW'
  | 'UPLOADING'
  | 'UPLOAD_COMPLETE'
  | 'SCANNING'
  | 'CLEAN'
  | 'WAITING_ACCEPTANCE'
  | 'REJECTED'
  | 'PAUSED'
  | 'ACCEPTED'
  | 'PROCESSING'
  | 'COMPLETED'
  | 'PUBLISHED'
  | 'TERMINATED'
  | 'EXPIRED';

export type ScanStatus =
  | 'WAITING_FOR_SCAN'
  | 'SCANNING'
  | 'CLEAN'
  | 'THREAT_DETECTED'
  | 'SCAN_ERROR'
  | 'SCAN_UNAVAILABLE'
  | 'REJECTED';

export interface JobFile {
  id: string;
  job_id: string;
  original_filename: string;
  safe_filename: string;
  extension: string;
  size: number;
  mime_type: string;
  signature_type: string;
  storage_state: 'INCOMING' | 'QUARANTINE' | 'CLEAN' | 'REJECTED';
  scan_status: ScanStatus;
  threat_name?: string;
  scan_timestamp?: string;
  created_at: string;
  storage_path?: string;
}

export interface Job {
  id: string;
  public_job_id: string;
  secure_token: string;
  status: JobStatus;
  file_count: number;
  total_size: number;
  customer_name?: string;
  notes?: string;
  rejection_reason?: string;
  created_at: string;
  updated_at: string;
  accepted_at?: string;
  completed_at?: string;
  terminated_at?: string;
  published_at?: string;
  files?: JobFile[];
  final_document?: FinalDocument;
  charges?: ChargeItem[];
  storage_dir?: string;
  time_remaining_seconds?: number | null;
}

export interface FinalDocument {
  id: string;
  job_id: string;
  original_source: string;
  generated_filename: string;
  file_size: number;
  secure_document_token: string;
  created_at: string;
  published_at: string;
}

export interface ChargeItem {
  id: string;
  job_id: string;
  description: string;
  amount: number;
}

export type RetentionPeriod =
  | '30m'
  | '1h'
  | '6h'
  | '24h'
  | '7d'
  | '30d'
  | 'Never';

export interface ShopSettings {
  // Hotspot
  hotspotSsid: string;
  hotspotPassword: string;
  customerHostname: string;
  serverPort: number;
  preferredAdapter: string;

  // Upload limits
  maxFileSizeMb: number;
  maxFilesPerJob: number;
  maxTotalJobSizeMb: number;
  allowedExtensions: string[];
  allowedReturnExtensions: string[];

  // Security
  requireDefenderScan: boolean;
  blockDangerousTypes: boolean;
  allowEmergencyBypass: boolean;
  firewallProtection: boolean;

  // Cleanup
  incompleteRetention: RetentionPeriod;
  rejectedRetention: RetentionPeriod;
  completedRetention: RetentionPeriod;
  finalDocRetention: RetentionPeriod;

  // Storage
  storagePath?: string;
  storageWarningPercent: number;
  storageCriticalPercent: number;

  // App
  operatorPinEnabled: boolean;
  operatorPinHash?: string;
  startWithWindows: boolean;
  receivingPaused: boolean;
  autoRejectMinutes?: number;
}

export interface NetworkStatus {
  hotspotStatus: 'RUNNING' | 'STOPPED' | 'UNAVAILABLE';
  hotspotSsid: string;
  serverStatus: 'RUNNING' | 'STOPPED';
  customerUrl: string;
  fallbackUrl: string;
  localIp: string;
  internetSharingStatus: 'OFF' | 'ON' | 'UNKNOWN';
  firewallStatus: 'PROTECTED' | 'WARNING' | 'DISABLED' | 'UNKNOWN';
  customerNetworkStatus: 'LOCAL ONLY' | 'BRIDGED_WARNING' | 'UNVERIFIED';
  defenderStatus: 'ACTIVE' | 'UNAVAILABLE' | 'HOLD_MODE';
  qrWifi: string;
  qrUrl: string;
  storage: StorageStatus;
}

export interface StorageStatus {
  totalBytes: number;
  usedBytes: number;
  freeBytes: number;
  usedPercent: number;
  status: 'OK' | 'WARNING' | 'CRITICAL';
}

export interface DashboardStats {
  todayJobsCount: number;
  filesReceivedCount: number;
  pendingCount: number;
  completedCount: number;
  rejectedCount: number;
  terminatedCount: number;
  todayRevenue: number;
  storage: StorageStatus;
  receivingPaused: boolean;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'SECURITY';
  category: string;
  message: string;
  details?: string;
}

export interface EnvironmentReport {
  os: string;
  platform: string;
  arch: string;
  nodeVersion: string;
  pythonVersion: string;
  gitVersion: string;
  isWindows: boolean;
  defenderAvailable: boolean;
  firewallAvailable: boolean;
  wifiAdapterAvailable: boolean;
  hotspotSupported: boolean;
  isAdmin: boolean;
  diskFreeGb: number;
  diskTotalGb: number;
  canBuildWindowsExe: boolean;
  packagingTools: string[];
}

export type LicenseStatus =
  | 'licensed'
  | 'grace_period'
  | 'trial_active'
  | 'trial_expired'
  | 'expired'
  | 'disabled'
  | 'unverified_offline'
  | 'error';

export interface LicenseInfo {
  deviceId: string;
  isLicensed: boolean;
  isTrial: boolean;
  status: LicenseStatus;
  canAccessDesk: boolean;
  needsEmailForTrial?: boolean;
  customerEmail?: string;
  supportEmail?: string;
  licenseKey?: string;
  licenseType?: string;
  trialDays?: number;
  trialStartAt?: string;
  trialExpiresAt?: string;
  expiresAt?: string;
  lastValidatedAt?: string;
  daysRemaining?: number;
  graceDaysRemaining?: number;
  message?: string;
  error?: string;
}

